# Jarves 4.0 • Tablet Server Edition

Jarves 4.0 turns the Android tablet into the Jarves endpoint **and local LAN server**. A PC is not required for the local server mode and Firebase is not used.

## Architecture
- Android tablet: HUD, microphone, wake word, TTS, local SQLite, customer/task/memory data, calendar, SMS/WhatsApp connectors, accessibility bridge, activity watch.
- Local HTTP server: `http://<TABLET-IP>:8787` while the Jarves server service is running.
- Protected API: all endpoints except `/api/health` require `Authorization: Bearer <local server token>`.
- Local agent: remote `/api/chat` requests execute through Jarves on the tablet. If a Gemini API key is configured, the tablet can use Gemini directly; otherwise deterministic local functions remain available.
- Optional cloud server remains in `cloud/server/`, but is no longer required for the tablet-server architecture.

## Main API
- `GET /api/health`
- `GET /api/info`
- `GET /api/dashboard`
- `GET /api/customers`
- `GET /api/tasks`
- `GET /api/memory`
- `GET /api/activities`
- `POST /api/chat` `{ "message": "..." }`
- `POST /api/customer`
- `POST /api/task`
- `POST /api/memory`

## Design principles
- No Firebase.
- No PC required for local operation.
- No passwords stored by Jarves.
- Externally visible actions remain confirmation-gated unless explicitly enabled.
- Unknown technical/business values are not invented; missing information is surfaced.
- LAN server is token protected. Do not expose port 8787 directly to the public internet without an authenticated reverse proxy/VPN.

## Build
GitHub Actions builds the Android APK with Java 17 / Android SDK 35.
