import express from 'express';
import cors from 'cors';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 8080);
const GEMINI_KEY = process.env.GEMINI_API_KEY || '';
const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash-lite';
const DATA_DIR = process.env.JARVES_DATA_DIR || path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'jarves.json');
fs.mkdirSync(DATA_DIR, { recursive: true });

const empty = { customers: [], tasks: [], memory: [], activities: [], sessions: {}, priceRules: [], quotes: [], inbox: [] };
function load(){ try { const d=JSON.parse(fs.readFileSync(DATA_FILE,'utf8')); for(const k of Object.keys(empty)) if(!(k in d)) d[k]=structuredClone(empty[k]); return d; } catch { fs.writeFileSync(DATA_FILE, JSON.stringify(empty,null,2)); return structuredClone(empty); } }
let db = load();
function save(){ fs.writeFileSync(DATA_FILE, JSON.stringify(db,null,2)); }
function id(){ return crypto.randomUUID(); }
function now(){ return Date.now(); }

const app = express();
app.use(cors());
app.use(express.json({limit:'1mb'}));
app.use(express.static(path.join(__dirname,'public')));

const SYSTEM = `Du bist Jarves, ein persönlicher deutschsprachiger KI-Assistent und Büroagent. Arbeite wie eine zuverlässige Büroassistenz: erkenne Kundenanfragen, Aufträge, Terminwünsche, Maße, Mengen, Materialien, Ausführungen und fehlende Angaben. Nutze gespeicherte Preisregeln für Vorab-Angebote. Erfinde niemals fehlende technische oder geschäftliche Daten. Wenn Informationen aus E-Mails, Bildern oder PDFs erkannt werden, kennzeichne Unsicherheiten und frage bei kritischen Unklarheiten nach. Vorläufige Angebote sind Entwürfe und dürfen nicht automatisch versendet werden. Nutze die Google-Suche bei aktuellen oder unsicheren Informationen. Erfinde niemals aktuelle Fakten. Arbeite mit Kunden, Aufgaben, Memory, Preisregeln und Angeboten aus den Jarves-Funktionen. Für Aktionen auf dem Android-Gerät (Kalender, SMS, WhatsApp, Apps, Accessibility, Gerätestatus) gib eine device_action zurück; das Gerät führt sie aus. Destruktive oder extern sichtbare Aktionen nur nach ausdrücklicher Nutzeranweisung. Bei Terminplanung zuerst prüfen und vor dem endgültigen Eintrag bestätigen. Keine Passwörter speichern.`;

function tools(){
  const s=(name,description,properties,required=[])=>({name,description,parameters:{type:'OBJECT',properties,required}});
  return [{functionDeclarations:[
    s('save_customer','Kunden in der Cloud speichern.',{name:{type:'STRING'},phone:{type:'STRING'},email:{type:'STRING'},notes:{type:'STRING'},address:{type:'STRING'}},['name']),
    s('search_customers','Kunden nach Name, Telefon, E-Mail oder Notizen suchen.',{query:{type:'STRING'}},['query']),
    s('list_customers','Alle Kunden auflisten.',{}),
    s('remember','Eine stabile Information im Jarves-Gedächtnis speichern.',{note:{type:'STRING'}},['note']),
    s('search_memory','Im Jarves-Gedächtnis suchen.',{query:{type:'STRING'}},['query']),
    s('create_task','Eine Aufgabe erstellen.',{title:{type:'STRING'},due_iso:{type:'STRING'}},['title']),
    s('list_tasks','Offene und erledigte Aufgaben auflisten.',{}),
    s('complete_task','Eine Aufgabe erledigen.',{id:{type:'STRING'}},['id']),
    s('log_business_activity','Geschäftliche Aktivität speichern.',{category:{type:'STRING'},title:{type:'STRING'},body:{type:'STRING'}},['title']),
    s('list_price_rules','Hinterlegte Firmenpreise und Preisregeln lesen.',{},[]),
    s('create_quote_draft','Vorläufiges Angebot aus erkannten Positionen und den hinterlegten Preisen berechnen. Niemals versenden.',{customer:{type:'STRING'},items:{type:'ARRAY',items:{type:'OBJECT',properties:{product:{type:'STRING'},price_key:{type:'STRING'},quantity:{type:'NUMBER'},unit:{type:'STRING'},unit_price:{type:'NUMBER'} } }},notes:{type:'STRING'}},['items']),
    s('list_quotes','Vorläufige und freigegebene Angebote auflisten.',{},[]),
    s('device_action','Eine lokale Android-Aktion anfordern. Aktionen: get_calendar, create_calendar_event, launch_app, open_url, get_device_status, send_sms, send_whatsapp, schedule_followup, android_control, get_last_message.',{action:{type:'STRING'},args:{type:'OBJECT'}},['action','args'])
  ]}];
}

function fnResult(name,args){
  if(name==='save_customer'){
    const c={id:id(),name:String(args.name||''),phone:String(args.phone||''),email:String(args.email||''),notes:String(args.notes||''),address:String(args.address||''),created:now(),updated:now()};
    db.customers.push(c); save(); return `Kunde gespeichert: ${c.name}`;
  }
  if(name==='search_customers'){
    const q=String(args.query||'').toLowerCase();
    return JSON.stringify(db.customers.filter(c=>JSON.stringify(c).toLowerCase().includes(q)).slice(0,20));
  }
  if(name==='list_customers') return JSON.stringify(db.customers.slice(-100).reverse());
  if(name==='remember'){ db.memory.push({id:id(),note:String(args.note||''),created:now()}); save(); return 'Gespeichert.'; }
  if(name==='search_memory'){
    const q=String(args.query||'').toLowerCase(); return JSON.stringify(db.memory.filter(x=>x.note.toLowerCase().includes(q)).slice(-50).reverse());
  }
  if(name==='create_task'){
    const t={id:id(),title:String(args.title||''),due_iso:String(args.due_iso||''),done:false,created:now(),updated:now()}; db.tasks.push(t); save(); return `Aufgabe gespeichert: ${t.title}`;
  }
  if(name==='list_tasks') return JSON.stringify(db.tasks.slice(-100).reverse());
  if(name==='complete_task'){
    const t=db.tasks.find(x=>x.id===String(args.id)); if(!t) return 'Aufgabe nicht gefunden.'; t.done=true;t.updated=now();save();return 'Aufgabe erledigt.';
  }
  if(name==='log_business_activity'){db.activities.push({id:id(),category:String(args.category||'eingang'),title:String(args.title||''),body:String(args.body||''),created:now()});save();return 'Geschäftsaktivität gespeichert.';}
  if(name==='list_price_rules') return JSON.stringify(db.priceRules.slice(-200));
  if(name==='create_quote_draft'){
    const items=Array.isArray(args.items)?args.items:[]; let subtotal=0; const priced=[];
    for(const raw of items){ const qty=Number(raw.quantity||1); const unit=String(raw.unit||''); const key=String(raw.price_key||raw.product||'').toLowerCase();
      let rule=db.priceRules.find(r=>String(r.key||r.name||'').toLowerCase()===key);
      if(!rule) rule=db.priceRules.find(r=>String(r.name||'').toLowerCase().includes(key)||key.includes(String(r.name||'').toLowerCase()));
      const unitPrice=rule?Number(rule.unit_price||0):Number(raw.unit_price||0); const line=qty*unitPrice; subtotal+=line;
      priced.push({...raw,quantity:qty,unit_price:unitPrice,line_total:line,price_source:rule?'company_price':'missing'});
    }
    const q={id:id(),status:'DRAFT',customer:String(args.customer||''),items:priced,subtotal,notes:String(args.notes||''),created:now(),updated:now()}; db.quotes.push(q); save();
    return JSON.stringify(q);
  }
  if(name==='list_quotes') return JSON.stringify(db.quotes.slice(-100).reverse());
  if(name==='device_action') return JSON.stringify({device_action:true,action:String(args.action||''),args:args.args||{}});
  return 'Unbekannte Funktion.';
}

async function gemini(contents){
  if(!GEMINI_KEY) throw new Error('GEMINI_API_KEY fehlt auf dem Cloud-Server.');
  const url=`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent?key=${encodeURIComponent(GEMINI_KEY)}`;
  const body={contents,systemInstruction:{parts:[{text:SYSTEM}]},tools:[{google_search:{}},...tools()],generationConfig:{temperature:0.3}};
  const r=await fetch(url,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});
  const text=await r.text(); if(!r.ok) throw new Error(`Gemini HTTP ${r.status}: ${text.slice(0,500)}`); return JSON.parse(text);
}

function textOf(resp){ return (resp?.candidates||[]).flatMap(c=>c?.content?.parts||[]).filter(p=>p.text).map(p=>p.text).join(''); }
function callsOf(resp){ return (resp?.candidates||[]).flatMap(c=>c?.content?.parts||[]).filter(p=>p.functionCall).map(p=>p.functionCall); }


function requireJsonBody(req){ return req.body && typeof req.body==='object' ? req.body : {}; }
async function analyzeInquiry(payload){
  if(!GEMINI_KEY) throw new Error('GEMINI_API_KEY fehlt auf dem Cloud-Server.');
  const parts=[{text:`Analysiere diese Geschäftsanfrage für Jarves. Extrahiere ausschließlich tatsächlich erkennbare Angaben. Erfinde nichts. Erkenne Kunde, Produkte/Leistungen, Menge, Maße, Material, Ausführung, Lieferwunsch und fehlende Angaben. Bei Bildern/PDFs: lies sichtbare Maße und Beschreibungen, kennzeichne unsichere Erkennung. Gib ausschließlich valides JSON zurück mit customer, summary, items (product,quantity,unit,width_mm,height_mm,length_mm,material,price_key), missing, uncertainties, confidence.`}];
  if(payload.from) parts.push({text:`Absender: ${payload.from}`});
  if(payload.subject) parts.push({text:`Betreff: ${payload.subject}`});
  if(payload.text) parts.push({text:`E-Mail-Text:
${String(payload.text).slice(0,20000)}`});
  for(const a of (payload.attachments||[]).slice(0,5)) if(a.base64 && a.mimeType) parts.push({inlineData:{mimeType:a.mimeType,data:a.base64}});
  const url=`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent?key=${encodeURIComponent(GEMINI_KEY)}`;
  const body={contents:[{role:'user',parts}],generationConfig:{temperature:0.1,responseMimeType:'application/json'}};
  const r=await fetch(url,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)}); const text=await r.text(); if(!r.ok) throw new Error(`Gemini HTTP ${r.status}: ${text.slice(0,500)}`);
  const j=JSON.parse(text); const raw=(j?.candidates||[]).flatMap(c=>c?.content?.parts||[]).map(p=>p.text||'').join(''); return JSON.parse(raw);
}
app.post('/api/inbox/analyze',async(req,res)=>{ try{ const payload=requireJsonBody(req); const analysis=await analyzeInquiry(payload); let quote=null; const missing=Array.isArray(analysis.missing)?analysis.missing:[]; const items=Array.isArray(analysis.items)?analysis.items:[]; const priced=items.length>0 && missing.length===0 && items.every(x=>{const k=String(x.price_key||x.product||'').toLowerCase();return db.priceRules.some(r=>String(r.key||r.name||'').toLowerCase()===k || String(r.name||'').toLowerCase()===k)}); if(priced){ let subtotal=0; const lines=items.map(x=>{const k=String(x.price_key||x.product||'').toLowerCase();const r=db.priceRules.find(r=>String(r.key||r.name||'').toLowerCase()===k || String(r.name||'').toLowerCase()===k);const qty=Number(x.quantity||1), up=Number(r.unit_price||0), total=qty*up;subtotal+=total;return {...x,unit_price:up,line_total:total,price_source:'company_price'};}); quote={id:id(),status:'DRAFT',customer:String(analysis.customer||payload.from||''),items:lines,subtotal,notes:'Automatisch aus Kundenanfrage berechnet. Vor Versand prüfen.',created:now(),updated:now()};db.quotes.push(quote); } const item={id:id(),created:now(),from:payload.from||'',subject:payload.subject||'',summary:analysis.summary||'',analysis,quote_id:quote?.id||'',attachments:(payload.attachments||[]).map(a=>({name:a.name||'',mimeType:a.mimeType||''}))}; db.inbox.push(item); if(payload.from||payload.subject) db.activities.push({id:id(),category:'auftrag',title:quote?'Vorab-Angebot erstellt':'Geschäftsanfrage analysiert',body:`${payload.subject||''} | ${analysis.summary||''}`,created:now()}); save(); res.json({ok:true,inbox_id:item.id,analysis,quote}); }catch(e){res.status(500).json({error:e.message||String(e)});} });
app.get('/api/inbox',(req,res)=>res.json(db.inbox.slice(-50).reverse()));
app.get('/api/price-rules',(req,res)=>res.json(db.priceRules.slice(-200)));
app.post('/api/price-rules',(req,res)=>{ const b=requireJsonBody(req); const r={id:id(),key:String(b.key||b.name||'').trim(),name:String(b.name||b.key||'').trim(),unit:String(b.unit||'Stk').trim(),unit_price:Number(b.unit_price||0),notes:String(b.notes||''),created:now(),updated:now()}; if(!r.key) return res.status(400).json({error:'key/name fehlt'}); const ix=db.priceRules.findIndex(x=>String(x.key).toLowerCase()===r.key.toLowerCase()); if(ix>=0){r.id=db.priceRules[ix].id;db.priceRules[ix]=r}else db.priceRules.push(r); save(); res.json(r);});
app.get('/api/quotes',(req,res)=>res.json(db.quotes.slice(-100).reverse()));

app.get('/api/health',(req,res)=>res.json({ok:true,service:'jarves-cloud',version:'4.0.0',firebase:false,model:MODEL,time:new Date().toISOString()}));
app.get('/api/dashboard',(req,res)=>res.json({customers:db.customers.length,tasksOpen:db.tasks.filter(x=>!x.done).length,memory:db.memory.length,priceRules:db.priceRules.length,quotes:db.quotes.length,inbox:db.inbox.length,activities:db.activities.slice(-12).reverse()}));
app.post('/api/chat',async(req,res)=>{
  try{
    const session=String(req.body.session||'default'); const message=String(req.body.message||'').trim();
    if(!message) return res.status(400).json({error:'message fehlt'});
    const history=Array.isArray(req.body.history)?req.body.history.slice(-10):[];
    const contents=[...history.filter(x=>x&&x.role&&Array.isArray(x.parts)),{role:'user',parts:[{text:message}]}];
    for(let round=0;round<8;round++){
      const resp=await gemini(contents); const calls=callsOf(resp);
      const candidate=resp?.candidates?.[0]?.content; if(candidate) contents.push(candidate);
      if(!calls.length){
        const answer=textOf(resp)||'Keine Antwort.';
        db.sessions[session]={history:contents.slice(-20),updated:now()}; save();
        return res.json({answer,status:'CLOUD • JARVES • WEB • AGENT',session});
      }
      const parts=[];
      for(const c of calls){
        const args=c.args||{};
        if(c.name==='device_action'){
          return res.json({device_action:{action:String(args.action||''),args:args.args||{}},answer:'Geräteaktion angefordert.',status:'CLOUD • GERÄTEAKTION',session});
        }
        const result=fnResult(c.name,args);
        parts.push({functionResponse:{name:c.name,response:{result}}});
      }
      contents.push({role:'user',parts});
    }
    res.json({answer:'Die Aufgabe hat das sichere Agentenlimit erreicht. Bitte gib mir den nächsten Schritt.',status:'CLOUD • LIMIT',session});
  }catch(e){res.status(500).json({error:e.message||String(e)});}
});

app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`Jarves Cloud läuft auf Port ${PORT}`));
