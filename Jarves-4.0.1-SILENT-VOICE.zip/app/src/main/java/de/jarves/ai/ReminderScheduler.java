package de.jarves.ai;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

public final class ReminderScheduler {
    private final Context c;
    public ReminderScheduler(Context c){this.c=c.getApplicationContext();}
    public String schedule(long delayMinutes,String channel,String to,String message){
        long mins=Math.max(1,Math.min(delayMinutes,60L*24L*30L));
        long when=System.currentTimeMillis()+mins*60000L;
        int id=(int)(System.currentTimeMillis()&0x7fffffff);
        Intent i=new Intent(c,JarvesAlarmReceiver.class).putExtra("channel",channel).putExtra("to",to).putExtra("message",message);
        PendingIntent pi=PendingIntent.getBroadcast(c,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(am==null)return "Alarmdienst nicht verfügbar.";
        try{
            if(android.os.Build.VERSION.SDK_INT>=31 && am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
            return "Follow-up in "+mins+" Minuten geplant.";
        }catch(Exception e){return "Follow-up konnte nicht geplant werden: "+e.getMessage();}
    }
}
