package de.jarves.ai;

import android.app.Notification;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.os.Bundle;

public final class JarvesNotificationListener extends NotificationListenerService {
    @Override public void onNotificationPosted(StatusBarNotification sbn){
        String pkg=sbn.getPackageName(); if(pkg==null)return;
        if(pkg.contains("whatsapp") || pkg.contains("messaging") || pkg.contains("sms") || pkg.contains("com.google.android.gm") || pkg.contains("gmail") || pkg.contains("outlook") || pkg.contains("office.outlook")){
            Notification n=sbn.getNotification(); Bundle e=n.extras;
            String title=e==null?"":String.valueOf(e.getCharSequence(Notification.EXTRA_TITLE,""));
            String text=e==null?"":String.valueOf(e.getCharSequence(Notification.EXTRA_TEXT,""));
            long now=System.currentTimeMillis();
            getSharedPreferences("jarves_runtime",MODE_PRIVATE).edit()
                    .putString("last_message_sender",title).putString("last_message_text",text)
                    .putLong("last_message_time",now).apply();
            String dedupe=pkg+"|"+title+"|"+text+"|"+sbn.getPostTime();
            android.content.SharedPreferences rt=getSharedPreferences("jarves_runtime",MODE_PRIVATE);
            if(!dedupe.equals(rt.getString("last_activity_key",""))){
                String category=(pkg.contains("gmail")||pkg.contains("google.android.gm")||pkg.contains("outlook"))?"email":"nachricht";
                String email=""; java.util.regex.Matcher em=java.util.regex.Pattern.compile("[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}",java.util.regex.Pattern.CASE_INSENSITIVE).matcher((title+" "+text)); if(em.find()) email=em.group();
                String lower=(title+" "+text).toLowerCase(java.util.Locale.GERMANY);
                if(category.equals("email")){
                    boolean order=lower.matches(".*\b(auftrag|bestellung|bestelle|bestellt|order|angebot|verkauf|kauf|lieferung)\b.*");
                    if(order) category="auftrag";
                    getSharedPreferences("jarves_email_runtime",MODE_PRIVATE).edit().putString("last_email_sender",title).putString("last_email_address",email).putString("last_email_subject",title).putString("last_email_text",text).putLong("last_email_time",now).apply();
                }
                // If Jarves has direct Gmail OAuth access, the Gmail API is the source of truth.
                // Do not create a second activity from the Gmail notification itself.
                boolean directGmail = category.equals("email") || category.equals("auftrag");
                if(!directGmail || !new GmailConnector(this).hasConnectedAccounts()){
                    new JarvesDataStore(this).logActivity(category,category.equals("email")?"Neue E-Mail":(category.equals("auftrag")?"Neuer Auftrag":"Neue Nachricht"),(title.isEmpty()?"":title+": ")+text,pkg);
                }
                rt.edit().putString("last_activity_key",dedupe).apply();
            }
        }
    }
}
