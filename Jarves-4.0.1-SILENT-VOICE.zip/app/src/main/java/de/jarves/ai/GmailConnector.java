package de.jarves.ai;

import android.accounts.Account;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.util.Base64;

import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.auth.api.identity.AuthorizationClient;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.tasks.Tasks;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Direct Gmail API access using Google's current Android authorization flow.
 * The same Gmail mailbox can therefore be used from the tablet and phone;
 * Jarves reads the cloud mailbox, not a copy of the phone's local mail store.
 * No password is stored by Jarves.
 */
public final class GmailConnector {
    public interface Callback { void done(String message, boolean success); }
    public interface SyncCallback { void done(int newMessages, String message); }

    public static final String GMAIL_READONLY = "https://www.googleapis.com/auth/gmail.readonly";
    public static final String GMAIL_SEND = "https://www.googleapis.com/auth/gmail.send";
    public static final int REQUEST_AUTH = 9401;

    private static final String PREF = "jarves_gmail";
    private static final String ACCOUNTS = "accounts";
    private static final String SEEN_PREFIX = "seen_";
    private final Context context;
    private final SecretStore secrets;
    private final ExecutorService pool = Executors.newSingleThreadExecutor();

    public GmailConnector(Context c) {
        context = c.getApplicationContext();
        secrets = new SecretStore(context);
    }

    /** Starts an interactive account authorization. The caller handles the pending intent result. */
    public void connect(Activity activity, Callback callback) {
        try {
            List<Scope> scopes = Arrays.asList(new Scope(GMAIL_READONLY));
            AuthorizationRequest request = new AuthorizationRequest.Builder()
                    .setRequestedScopes(scopes)
                    .build();
            Identity.getAuthorizationClient(activity).authorize(request)
                    .addOnSuccessListener(result -> handleAuthorization(activity, result, callback))
                    .addOnFailureListener(e -> callback.done("Gmail-Autorisierung fehlgeschlagen: " + friendly(e), false));
        } catch (Exception e) {
            callback.done("Gmail konnte nicht verbunden werden: " + friendly(e), false);
        }
    }

    public void onAuthorizationResult(Activity activity, Intent data, Callback callback) {
        try {
            AuthorizationResult result = Identity.getAuthorizationClient(activity).getAuthorizationResultFromIntent(data);
            handleAuthorization(activity, result, callback);
        } catch (Exception e) {
            callback.done("Gmail-Freigabe konnte nicht abgeschlossen werden: " + friendly(e), false);
        }
    }

    private void handleAuthorization(Activity activity, AuthorizationResult result, Callback callback) {
        try {
            if (result.hasResolution()) {
                PendingIntent pending = result.getPendingIntent();
                if (pending == null) { callback.done("Google benötigt eine Freigabe, konnte aber keinen Freigabedialog öffnen.", false); return; }
                activity.startIntentSenderForResult(pending.getIntentSender(), REQUEST_AUTH, null, 0, 0, 0, null);
                return;
            }
            String token = result.getAccessToken();
            if (token == null || token.trim().isEmpty()) {
                callback.done("Google hat keinen Gmail-Zugriffstoken geliefert.", false);
                return;
            }
            pool.execute(() -> {
                try {
                    String account = profileEmail(token);
                    if (account.isEmpty()) {
                        try {
                            com.google.android.gms.auth.api.signin.GoogleSignInAccount a = result.toGoogleSignInAccount();
                            if (a != null && a.getEmail() != null) account = a.getEmail();
                        } catch (Exception ignored) {}
                    }
                    if (account.isEmpty()) throw new IllegalStateException("Gmail-Konto konnte nicht ermittelt werden.");
                    addAccount(account);
                    syncAccount(account, token, true);
                    final String finalAccount = account;
                    activity.runOnUiThread(() -> callback.done("Gmail verbunden: " + finalAccount + ". Jarves greift jetzt auf dasselbe Postfach zu, das auch auf deinem Handy synchronisiert ist.", true));
                } catch (Exception e) {
                    activity.runOnUiThread(() -> callback.done("Gmail konnte nicht synchronisiert werden: " + friendly(e), false));
                }
            });
        } catch (Exception e) {
            callback.done("Gmail-Autorisierung konnte nicht verarbeitet werden: " + friendly(e), false);
        }
    }

    /** Background-safe sync: requests a fresh access token silently for every previously connected account. */
    public void syncStoredAccounts(SyncCallback callback) {
        pool.execute(() -> {
            int total = 0;
            StringBuilder detail = new StringBuilder();
            try {
                for (String account : getAccounts()) {
                    try {
                        String token = authorizeSilently(account);
                        if (token == null || token.isEmpty()) continue;
                        int n = syncAccount(account, token, false);
                        total += n;
                        if (n > 0) {
                            if (detail.length() > 0) detail.append(" ");
                            detail.append(account).append(": ").append(n).append(" neue E-Mail").append(n == 1 ? "" : "s").append(".");
                        }
                    } catch (Exception ignored) {
                        // A background run must never break Jarves' other activity checks.
                    }
                }
            } finally {
                String msg = total == 0 ? "Keine neuen Gmail-Nachrichten erkannt." : detail.toString();
                callback.done(total, msg);
            }
        });
    }

    private String authorizeSilently(String email) throws Exception {
        AuthorizationClient client = Identity.getAuthorizationClient(context);
        AuthorizationRequest request = new AuthorizationRequest.Builder()
                .setAccount(new Account(email, "com.google"))
                .setRequestedScopes(Arrays.asList(new Scope(GMAIL_READONLY)))
                .build();
        AuthorizationResult result = Tasks.await(client.authorize(request));
        if (result == null || result.hasResolution()) return "";
        return result.getAccessToken() == null ? "" : result.getAccessToken();
    }

    private int syncAccount(String email, String token, boolean initialConnect) throws Exception {
        JSONArray messages = listMessages(token, 25);
        Set<String> seen = loadSeen(email);
        int fresh = 0;
        JSONArray idsNow = new JSONArray();
        for (int i = 0; i < messages.length(); i++) {
            JSONObject m = messages.getJSONObject(i);
            String id = m.optString("id", "");
            if (id.isEmpty()) continue;
            idsNow.put(id);
            if (seen.contains(id)) continue;
            JSONObject full = getMessage(token, id);
            lastMessageId=id;
            String from = header(full, "From");
            String subject = header(full, "Subject");
            String date = header(full, "Date");
            String body = extractBody(full);
            if (body.isEmpty()) body = full.optString("snippet", "");
            String combined = (subject + " " + from + " " + body).trim();
            String lower = combined.toLowerCase(Locale.GERMANY);
            String category = "email";
            if (lower.matches(".*\\b(auftrag|bestellung|bestellt|order|angebot|verkauf|kauf|lieferung|bestellnummer|bestellnr)\\b.*")) category = "auftrag";
            else if (lower.matches(".*\\b(termin|besuch|vorbeikommen|verfügbar|verfuegbar|treffen|meeting)\\b.*")) category = "eingang";
            if (!initialConnect) {
                // Geschäftsanfragen werden zusätzlich an den eigenen Jarves-Cloud-Agenten übergeben.
                // Passwörter werden nie übertragen; nur die E-Mail-Daten und optional die Anhänge.
                if (category.equals("auftrag") || hasUsefulAttachment(full)) {
                    try { pushEmailToCloud(from, subject, body, full, token); } catch (Exception ignored) {}
                }
                String title = category.equals("auftrag") ? "Neuer Auftrag per Gmail" : "Neue E-Mail per Gmail";
                String compact = "Konto: " + email + " | Von: " + from + " | Betreff: " + subject + (date.isEmpty() ? "" : " | " + date) + " | " + trim(body, 1400);
                new JarvesDataStore(context).logActivity(category, title, compact, "gmail:" + email);
                context.getSharedPreferences("jarves_email_runtime", Context.MODE_PRIVATE).edit()
                        .putString("last_email_sender", from)
                        .putString("last_email_address", extractEmail(from))
                        .putString("last_email_subject", subject)
                        .putString("last_email_text", trim(body, 1800))
                        .putString("last_email_account", email)
                        .putLong("last_email_time", System.currentTimeMillis()).apply();
                fresh++;
            }
        }
        // First connection is intentionally baselined: existing mail is not announced as new.
        if (initialConnect) fresh = 0;
        seen.addAll(jsonArrayToSet(idsNow));
        saveSeen(email, seen);
        return fresh;
    }

    public String readRecentEmails(int limit) throws Exception {
        StringBuilder out = new StringBuilder();
        int remaining = Math.max(1, Math.min(limit, 20));
        for (String account : getAccounts()) {
            String token = authorizeSilently(account);
            if (token == null || token.isEmpty()) continue;
            JSONArray messages = listMessages(token, Math.min(remaining, 10), "newer_than:14d");
            for (int i = 0; i < messages.length() && remaining > 0; i++) {
                JSONObject full = getMessage(token, messages.getJSONObject(i).optString("id", ""));
                String from = header(full, "From");
                String subject = header(full, "Subject");
                String date = header(full, "Date");
                String body = extractBody(full);
                if (body.isEmpty()) body = full.optString("snippet", "");
                if (out.length() > 0) out.append("\n\n");
                out.append("Konto: ").append(account).append("\nVon: ").append(from).append("\nBetreff: ").append(subject).append("\nDatum: ").append(date).append("\nText: ").append(trim(body, 1800));
                remaining--;
            }
            if (remaining <= 0) break;
        }
        return out.length() == 0 ? "Keine direkt verbundenen Gmail-Konten oder keine abrufbaren Nachrichten." : out.toString();
    }


    private String lastMessageId="";
    private boolean hasUsefulAttachment(JSONObject full) throws Exception { JSONObject p=full.optJSONObject("payload"); return p!=null && hasUsefulAttachmentPart(p); }
    private boolean hasUsefulAttachmentPart(JSONObject part) throws Exception { String fn=part.optString("filename",""); String mime=part.optString("mimeType","").toLowerCase(Locale.GERMANY); if(!fn.isEmpty()&&(mime.startsWith("image/")||mime.equals("application/pdf")||mime.contains("document"))) return true; JSONArray ch=part.optJSONArray("parts"); if(ch!=null) for(int i=0;i<ch.length();i++) if(hasUsefulAttachmentPart(ch.getJSONObject(i))) return true; return false; }
    private void pushEmailToCloud(String from,String subject,String body,JSONObject full,String token) throws Exception {
        String cloud=context.getSharedPreferences("jarves_workspace",Context.MODE_PRIVATE).getString("cloud_url","").trim(); if(cloud.isEmpty())return;
        JSONArray at=collectAttachments(full,token); JSONObject payload=new JSONObject().put("from",from).put("subject",subject).put("text",trim(body,20000)).put("attachments",at);
        URL u=new URL(cloud.replaceAll("/$","")+"/api/inbox/analyze"); HttpURLConnection c=(HttpURLConnection)u.openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(12000); c.setReadTimeout(90000); c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json; charset=UTF-8"); try(OutputStream os=c.getOutputStream()){os.write(payload.toString().getBytes(StandardCharsets.UTF_8));} int code=c.getResponseCode(); if(code<200||code>=300)throw new IllegalStateException("Cloud HTTP "+code);
    }
    private JSONArray collectAttachments(JSONObject full,String token) throws Exception { JSONArray out=new JSONArray(); JSONObject p=full.optJSONObject("payload"); if(p!=null)collectAttachmentParts(p,token,out,0); return out; }
    private void collectAttachmentParts(JSONObject part,String token,JSONArray out,int depth) throws Exception { if(out.length()>=3||depth>8)return; String fn=part.optString("filename",""); String mime=part.optString("mimeType",""); JSONObject b=part.optJSONObject("body"); if(!fn.isEmpty()&&b!=null&&(mime.toLowerCase(Locale.GERMANY).startsWith("image/")||mime.equalsIgnoreCase("application/pdf"))){ String data=b.optString("data",""); String aid=b.optString("attachmentId",""); if(data.isEmpty()&&!aid.isEmpty())data=getAttachmentData(token,aid); if(!data.isEmpty()){ byte[] decoded=Base64.decode(data,Base64.URL_SAFE|Base64.NO_WRAP); if(decoded.length>0&&decoded.length<=6*1024*1024)out.put(new JSONObject().put("name",fn).put("mimeType",mime).put("base64",Base64.encodeToString(decoded,Base64.NO_WRAP))); }} JSONArray ch=part.optJSONArray("parts"); if(ch!=null)for(int i=0;i<ch.length()&&out.length()<3;i++)collectAttachmentParts(ch.getJSONObject(i),token,out,depth+1); }
    private String getAttachmentData(String token,String attachmentId) throws Exception { if(lastMessageId.isEmpty()||attachmentId.isEmpty())return ""; String url="https://gmail.googleapis.com/gmail/v1/users/me/messages/"+lastMessageId+"/attachments/"+attachmentId; JSONObject root=new JSONObject(httpGet(url,token)); return root.optString("data",""); }

    private JSONArray listMessages(String token, int max) throws Exception {
        return listMessages(token, max, "newer_than:14d");
    }

    private JSONArray listMessages(String token, int max, String query) throws Exception {
        String url = "https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=" + Math.max(1, Math.min(max, 50)) + "&q=" + java.net.URLEncoder.encode(query, "UTF-8");
        JSONObject root = new JSONObject(httpGet(url, token));
        JSONArray messages = root.optJSONArray("messages");
        return messages == null ? new JSONArray() : messages;
    }

    private JSONObject getMessage(String token, String id) throws Exception {
        String url = "https://gmail.googleapis.com/gmail/v1/users/me/messages/" + id + "?format=full";
        return new JSONObject(httpGet(url, token));
    }

    private String profileEmail(String token) throws Exception {
        JSONObject o = new JSONObject(httpGet("https://gmail.googleapis.com/gmail/v1/users/me/profile", token));
        return o.optString("emailAddress", "").trim();
    }

    private String httpGet(String url, String token) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("GET"); c.setConnectTimeout(12000); c.setReadTimeout(20000);
        c.setRequestProperty("Authorization", "Bearer " + token);
        c.setRequestProperty("Accept", "application/json");
        int code = c.getResponseCode();
        BufferedReader br = new BufferedReader(new InputStreamReader(code >= 400 ? c.getErrorStream() : c.getInputStream(), StandardCharsets.UTF_8));
        StringBuilder b = new StringBuilder(); String line; while ((line = br.readLine()) != null) b.append(line);
        String body = b.toString();
        if (code >= 400) throw new IllegalStateException("Gmail API HTTP " + code + ": " + trim(body, 240));
        return body;
    }

    private String header(JSONObject full, String wanted) throws Exception {
        JSONObject payload = full.optJSONObject("payload");
        JSONArray headers = payload == null ? null : payload.optJSONArray("headers");
        if (headers == null) return "";
        for (int i = 0; i < headers.length(); i++) {
            JSONObject h = headers.getJSONObject(i);
            if (wanted.equalsIgnoreCase(h.optString("name", ""))) return h.optString("value", "");
        }
        return "";
    }

    private String extractBody(JSONObject full) throws Exception {
        JSONObject payload = full.optJSONObject("payload");
        if (payload == null) return "";
        return findTextPart(payload);
    }

    private String findTextPart(JSONObject part) throws Exception {
        String mime = part.optString("mimeType", "");
        JSONObject body = part.optJSONObject("body");
        if ("text/plain".equalsIgnoreCase(mime) && body != null && body.has("data")) return decode(body.optString("data", ""));
        JSONArray parts = part.optJSONArray("parts");
        if (parts != null) {
            for (int i = 0; i < parts.length(); i++) {
                String s = findTextPart(parts.getJSONObject(i));
                if (!s.isEmpty()) return s;
            }
        }
        if (body != null && body.has("data")) return decode(body.optString("data", ""));
        return "";
    }

    private String decode(String s) {
        try { return new String(Base64.decode(s, Base64.URL_SAFE | Base64.NO_WRAP), StandardCharsets.UTF_8).trim(); }
        catch (Exception e) { return ""; }
    }

    private Set<String> loadSeen(String email) {
        String raw = secrets.get(SEEN_PREFIX + safeKey(email), "");
        Set<String> out = new LinkedHashSet<>();
        try { JSONArray a = new JSONArray(raw); for (int i = 0; i < a.length(); i++) out.add(a.getString(i)); } catch (Exception ignored) {}
        return out;
    }

    private void saveSeen(String email, Set<String> seen) {
        JSONArray a = new JSONArray(); int skip = Math.max(0, seen.size() - 120); int i = 0;
        for (String id : seen) { if (i++ < skip) continue; a.put(id); }
        secrets.put(SEEN_PREFIX + safeKey(email), a.toString());
    }

    private void addAccount(String email) {
        Set<String> accounts = getAccounts(); accounts.add(email); JSONArray a = new JSONArray(); for (String s : accounts) a.put(s); secrets.put(ACCOUNTS, a.toString());
    }

    private Set<String> getAccounts() {
        Set<String> out = new LinkedHashSet<>(); String raw = secrets.get(ACCOUNTS, "");
        try { JSONArray a = new JSONArray(raw); for (int i = 0; i < a.length(); i++) out.add(a.getString(i)); } catch (Exception ignored) {}
        return out;
    }

    public boolean hasConnectedAccounts() { return !getAccounts().isEmpty(); }

    public String connectedAccountsText() {
        Set<String> a = getAccounts(); if (a.isEmpty()) return "Kein Gmail-Konto direkt mit Jarves verbunden.";
        StringBuilder b = new StringBuilder("Gmail direkt verbunden:\n"); for (String s : a) b.append("• ").append(s).append('\n'); return b.toString().trim();
    }

    private static Set<String> jsonArrayToSet(JSONArray a) throws Exception { Set<String> s = new LinkedHashSet<>(); for (int i = 0; i < a.length(); i++) s.add(a.getString(i)); return s; }
    private static String safeKey(String s) { return s.toLowerCase(Locale.US).replaceAll("[^a-z0-9]", "_"); }
    private static String extractEmail(String s) { java.util.regex.Matcher m = java.util.regex.Pattern.compile("[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(s == null ? "" : s); return m.find() ? m.group() : ""; }
    private static String trim(String s, int n) { if (s == null) return ""; s = s.replaceAll("\\s+", " ").trim(); return s.length() > n ? s.substring(0, n) + "…" : s; }
    private static String friendly(Throwable e) { String m = e == null ? "unbekannter Fehler" : e.getMessage(); return m == null || m.trim().isEmpty() ? "unbekannter Fehler" : m; }
}
