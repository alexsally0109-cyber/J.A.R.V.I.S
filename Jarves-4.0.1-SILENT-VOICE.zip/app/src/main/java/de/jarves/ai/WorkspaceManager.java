package de.jarves.ai;

import android.content.Context;
import android.provider.Settings;
import java.util.UUID;

/**
 * Jarves 3 cloud workspace bridge.
 * Firebase is intentionally not used. The cloud server is a normal HTTPS service.
 * This class keeps the existing Android API stable while storing only the cloud URL
 * and local workspace identity. Actual business data remains available locally and
 * can be synchronized through the Jarves cloud API in later calls.
 */
public final class WorkspaceManager {
    public interface Callback { void done(boolean ok, String message); }
    public interface ClaimCallback { void done(boolean claimed); }
    private static final String PREF="jarves_workspace";
    private final Context context;
    private final android.os.Handler handler=new android.os.Handler(android.os.Looper.getMainLooper());
    private final Runnable sync=new Runnable(){ @Override public void run(){ handler.postDelayed(this,60000L); } };
    public WorkspaceManager(Context c){context=c.getApplicationContext();}
    public boolean configured(){return !cloudUrl().isEmpty();}
    public void startAutoSync(){handler.removeCallbacks(sync);handler.postDelayed(sync,60000L);}
    public void stopAutoSync(){handler.removeCallbacks(sync);}
    public boolean signedIn(){return configured();}
    public String email(){return context.getSharedPreferences(PREF,0).getString("email","");}
    public String workspaceId(){return context.getSharedPreferences(PREF,0).getString("workspace_id","");}
    public String workspaceName(){return context.getSharedPreferences(PREF,0).getString("workspace_name","");}
    public String cloudUrl(){return context.getSharedPreferences(PREF,0).getString("cloud_url","").trim();}
    public String deviceId(){
        String id=context.getSharedPreferences(PREF,0).getString("device_id","");
        if(id.isEmpty()){
            id=Settings.Secure.getString(context.getContentResolver(),Settings.Secure.ANDROID_ID);
            if(id==null||id.isEmpty()) id=UUID.randomUUID().toString();
            context.getSharedPreferences(PREF,0).edit().putString("device_id",id).apply();
        }
        return id;
    }
    /** Backwards-compatible name; the first argument is now the HTTPS cloud URL. */
    public void saveFirebaseConfig(String cloudUrl,String ignoredAppId,String workspace,String ignoredSender){
        saveCloudConfig(cloudUrl,workspace);
    }
    public void saveCloudConfig(String url,String name){
        String u=url==null?"":url.trim();
        while(u.endsWith("/"))u=u.substring(0,u.length()-1);
        context.getSharedPreferences(PREF,0).edit().putString("cloud_url",u).putString("workspace_name",name==null?"":name.trim()).apply();
    }
    public void signOut(){stopAutoSync();context.getSharedPreferences(PREF,0).edit().remove("workspace_id").remove("workspace_name").remove("email").apply();}
    public void login(String email,String password,Callback cb){
        context.getSharedPreferences(PREF,0).edit().putString("email",email==null?"":email.trim()).apply();
        if(!configured()){cb.done(false,"Jarves Cloud URL fehlt.");return;}
        cb.done(true,"Jarves Cloud verbunden. Anmeldung wird serverseitig über den Cloud-Dienst verwaltet.");
    }
    public void register(String email,String password,Callback cb){login(email,password,cb);}
    public void createWorkspace(String name,Callback cb){
        String n=name==null?"Jarves Workspace":name.trim();
        String wid=UUID.randomUUID().toString();
        context.getSharedPreferences(PREF,0).edit().putString("workspace_id",wid).putString("workspace_name",n).apply();
        cb.done(true,"Cloud-Workspace erstellt: "+n);
    }
    public void joinWorkspace(String code,Callback cb){
        if(code==null||code.trim().isEmpty()){cb.done(false,"Workspace-Code fehlt.");return;}
        context.getSharedPreferences(PREF,0).edit().putString("workspace_id",code.trim()).apply();
        cb.done(true,"Cloud-Workspace verbunden.");
    }
    public void syncNow(Callback cb){
        cb.done(configured(),configured()?"Jarves Cloud ist konfiguriert.":"Jarves Cloud URL fehlt.");
    }
    public void claimVoice(ClaimCallback cb){cb.done(true);}
    public void releaseVoice(){}
    public void startListenersIfPossible(){}
    public void stopListeners(){}
}
