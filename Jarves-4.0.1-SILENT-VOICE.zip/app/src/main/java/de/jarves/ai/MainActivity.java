package de.jarves.ai;

import android.Manifest;
import android.app.AlertDialog;
import android.app.role.RoleManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.ComponentName;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.net.Uri;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;
import android.provider.ContactsContract;
import android.database.Cursor;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class MainActivity extends AppCompatActivity {
    private JarvesDataStore db;
    private HudTouchView hud;
    private AgentClient agentClient;
    private OcrManager ocr;
    private GmailConnector gmail;
    private WorkspaceManager workspace;
    private final BroadcastReceiver receiver=new BroadcastReceiver(){
        @Override public void onReceive(Context c,Intent i){
            if(JarvesVoiceService.ACTION_UPDATE.equals(i.getAction())){
                String s=i.getStringExtra("status");
                if(s!=null){ hud.setStatus(s); if(s.startsWith("ANTWORT")){String a=s.substring(9).trim();hud.setAnswer(a);} }
            }
        }
    };

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        if(Intent.ACTION_ASSIST.equals(getIntent().getAction())) {
            new android.os.Handler().postDelayed(this::listenOnce, 250);
        }
        db=new JarvesDataStore(this);
        ActivityScheduler.ensureDefaults(this);
        ActivityScheduler.configure(this);
        agentClient=new AgentClient(this);
        ocr=new OcrManager(this);
        gmail=new GmailConnector(this);
        workspace=new WorkspaceManager(this);
        workspace.startAutoSync();
        hud=findViewById(R.id.hudTouch);
        refreshHudData();
        wireHud(); startTabletServer(); requestPermissions();
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED){ new android.os.Handler().postDelayed(this::startJarves,400); }
        tick();
    }

    private void startTabletServer(){ Intent i=new Intent(this,JarvesLocalServerService.class); if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i); }

    private void wireHud(){
        ((HudTouchView)findViewById(R.id.hudTouch)).setListener(action->{
            switch(action){
                // Radial HUD controls
                case "search": showSearch(); break;
                case "messages": showMessages(); break;
                case "weather": ask("Wie ist das aktuelle Wetter und die Prognose für meinen Standort? Wenn mein genauer Standort nicht verfügbar ist, frage mich nach der Stadt."); break;
                case "music": openCategory(Intent.CATEGORY_APP_MUSIC,new String[]{"spotify","musik","music","youtube"}); break;
                case "apps": showApps(); break;
                case "calendar": showCalendarPanel(); break;
                case "notes": showNotes(); break;
                case "smarthome": showSmartHome(); break;
                case "youtube": openUrl("https://www.youtube.com"); break;
                case "settings": showSettings(); break;

                // Top status controls
                case "voice_panel": listenOnce(); break;
                case "wifi": openSettings(Settings.ACTION_WIFI_SETTINGS); break;
                case "bluetooth": openSettings(Settings.ACTION_BLUETOOTH_SETTINGS); break;
                case "assistant_status": showDiagnostics(); break;
                case "top_settings": showSettings(); break;
                case "battery": openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS); break;

                // System-status rows
                case "system": showSystem(); break;
                case "system_jarves": showSystem(); break;
                case "system_mic": testJarvesVoice(); break;
                case "system_internet": showInternetStatus(); break;
                case "system_ai": showSettings(); break;
                case "system_storage": openSettings(Settings.ACTION_INTERNAL_STORAGE_SETTINGS); break;

                // News: each visible story is independently actionable
                case "news": ask("Suche die wichtigsten aktuellen Nachrichten für mich und nenne die wichtigsten Quellen kurz."); break;
                case "news_1": ask("Suche aktuelle Nachrichten zur KI-Forschung. Nenne mir die wichtigsten Entwicklungen und Quellen."); break;
                case "news_2": ask("Suche die wichtigsten aktuellen Ereignisse des Tages und fasse sie auf Deutsch zusammen."); break;
                case "news_3": ask("Welche aktuellen Technologietrends sind heute relevant? Recherchiere und nenne Quellen."); break;

                // Calendar card and every visible appointment row
                case "clock": showCalendarPanel(); break;
                case "right_calendar": showCalendarPanel(); break;
                case "calendar_1": ask("Was ist mein erster heutiger Kalendertermin? Nenne Uhrzeit, Titel und Ort, wenn vorhanden."); break;
                case "calendar_2": ask("Was ist mein zweiter heutiger Kalendertermin? Nenne Uhrzeit, Titel und Ort, wenn vorhanden."); break;
                case "calendar_3": ask("Was ist mein dritter heutiger Kalendertermin? Nenne Uhrzeit, Titel und Ort, wenn vorhanden."); break;
                case "calendar_4": ask("Was ist mein vierter heutiger Kalendertermin? Nenne Uhrzeit, Titel und Ort, wenn vorhanden."); break;

                // Every quick-access button is independent
                case "quick": showQuickAccess(); break;
                case "quick_messages": openCategory(Intent.CATEGORY_APP_MESSAGING,new String[]{"whatsapp","nachricht","message","messaging","sms"}); break;
                case "quick_youtube": openUrl("https://www.youtube.com"); break;
                case "quick_maps": openUrl("https://maps.google.com"); break;
                case "quick_chatgpt": openUrl("https://chatgpt.com"); break;
                case "quick_translate": openUrl("https://translate.google.com"); break;
                case "quick_playlist": openCategory(Intent.CATEGORY_APP_MUSIC,new String[]{"spotify","musik","music"}); break;

                // Main dashboard: customer-focused left rail and clickable overview
                case "customer_data": showCustomers(); break;
                case "customer_messages": showMessages(); break;
                case "overview_calendar": showCalendarPanel(); break;
                case "overview_tasks": showTasks(); break;
                case "overview_customers": showCustomers(); break;
                case "overview_messages": showMessages(); break;
                case "overview_reminders": ask("Zeige mir meine offenen Erinnerungen und geplanten Follow-ups. Nenne nur echte Einträge aus meinem Jarves-System und Kalender."); break;
                case "overview_memory": showMemory(); break;

                case "daily_today": ask("Gib mir ein kurzes Tagesbriefing: heutige Termine, offene Aufgaben, wichtige Erinnerungen und was heute zuerst erledigt werden sollte."); break;
                case "daily_tasks": showTasks(); break;
                case "daily_customers": showCustomers(); break;
                case "daily_memory": showMemory(); break;
                case "answer": listenOnce(); break;
                case "core": case "mic": listenOnce(); break;
            }
        });
    }

    private void refreshHudData(){
        if(hud==null || db==null) return;
        int customers=db.customerCount();
        int tasks=db.taskCount();
        int memory=db.memoryCount();
        android.content.SharedPreferences sp=getSharedPreferences("jarves_runtime",0);
        String sender=sp.getString("last_message_sender","").trim();
        String msg=sp.getString("last_message_text","").trim();
        if(msg.length()>72) msg=msg.substring(0,72)+"…";
        String customerLine=customers==0?"Noch keine Kunden gespeichert.":customers+" Kunden gespeichert • antippen für Kundendaten";
        String messageLine=msg.isEmpty()?"Keine neue Kundennachricht erkannt.":(""+(sender.isEmpty()?"Nachricht":sender)+": "+msg);
        hud.setDashboardData(customerLine,messageLine,customers,tasks,memory);
    }

    private void tick(){
        new android.os.Handler().postDelayed(this::tick,1000);
        hud.invalidate();
    }

    private void requestPermissions(){
        java.util.ArrayList<String> p=new java.util.ArrayList<>();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.POST_NOTIFICATIONS);
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.RECORD_AUDIO);
        if(!p.isEmpty())requestPermissions(p.toArray(new String[0]),50);
    }

    private void listenOnce(){
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions();return;}
        Intent i=new Intent(this,JarvesVoiceService.class);i.putExtra("listen_once",false);i.putExtra("direct_listen",true);i.putExtra("interrupt",true);
        if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);
        hud.setStatus("HÖREN • AKTIV");
    }
    private void startJarves(){listenOnce();}
    private void stopJarves(){stopService(new Intent(this,JarvesVoiceService.class));hud.setStatus("JARVES • BEREIT");}

    private void ask(String text){
        hud.setStatus("DENKEN • JARVES ARBEITET");
        agentClient.ask(text,(answer,status)->{
            hud.setStatus(status==null?"ANTWORT • BEREIT":status);
            hud.setAnswer(answer);
            speakUiAnswer(answer);
        });
    }

    private void speakUiAnswer(String answer){
        if(answer==null || answer.trim().isEmpty()) return;
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) return;
        Intent i=new Intent(this,JarvesVoiceService.class);
        i.putExtra("speak_text",answer);
        if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
    }

    private void showCustomers(){
        String json=db.customersJson();
        new AlertDialog.Builder(this).setTitle("KUNDEN").setMessage(json==null||json.trim().isEmpty()?"Noch keine Kunden gespeichert.":json)
            .setNeutralButton("KONTAKT IMPORTIEREN",(d,w)->importContact())
            .setPositiveButton("KUNDE HINZUFÜGEN",(d,w)->ask("Führe mich durch das Anlegen eines neuen Kunden und frage nur die noch fehlenden Angaben ab."))
            .setNegativeButton("SCHLIESSEN",null).show();
    }

    private void showTasks(){
        String json=db.tasksJson();
        new AlertDialog.Builder(this).setTitle("AUFGABEN").setMessage(json==null||json.trim().isEmpty()?"Keine offenen Aufgaben.":json)
            .setPositiveButton("NEUE AUFGABE",(d,w)->ask("Erstelle eine neue Aufgabe. Frage nach Titel und Fälligkeit, falls sie fehlen."))
            .setNegativeButton("SCHLIESSEN",null).show();
    }

    private void showMemory(){
        String json=db.memoryJson("");
        new AlertDialog.Builder(this).setTitle("MEMORY").setMessage(json==null||json.trim().isEmpty()?"Memory ist noch leer.":json)
            .setPositiveButton("JARVES FRAGEN",(d,w)->listenOnce()).setNegativeButton("SCHLIESSEN",null).show();
    }

    private void showSearch(){
        EditText e=new EditText(this);e.setHint("Was soll Jarves suchen?");
        new AlertDialog.Builder(this).setTitle("JARVES • WEB / WEBSITE")
                .setView(e)
                .setNegativeButton("ABBRECHEN",null)
                .setNeutralButton("WEBSITE OPTIMIEREN",(d,w)->showWebsiteAgent())
                .setPositiveButton("SUCHEN",(d,w)->{String q=e.getText().toString().trim();if(!q.isEmpty())ask("Suche im Web nach: "+q+". Gib mir die beste aktuelle Antwort auf Deutsch und nenne wichtige Quellen.");})
                .show();
    }

    private void showWebsiteAgent(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(24,8,24,8);
        EditText url=new EditText(this);url.setHint("https://deine-website.de");box.addView(url);
        EditText goal=new EditText(this);goal.setHint("Ziel, z. B. mehr Kunden / SEO / schneller / moderner");box.addView(goal);
        new AlertDialog.Builder(this).setTitle("JARVES • WEBSITE-AGENT").setMessage("Jarves analysiert die öffentlich erreichbare Website und erstellt konkrete, priorisierte Verbesserungen. Für echte Änderungen braucht er später einen autorisierten Schreibzugang zu deinem CMS, Repository oder Hosting.").setView(box).setNegativeButton("ABBRECHEN",null).setPositiveButton("ANALYSIEREN",(d,w)->{
            String u=url.getText().toString().trim(); String g=goal.getText().toString().trim();
            if(!u.isEmpty())ask("Analysiere meine Website "+u+" mit dem Website-Agent. Ziel: "+(g.isEmpty()?"allgemeine maximale Verbesserung":g)+". Prüfe Inhalt, SEO, Struktur, Barrierefreiheit, Conversion und offensichtliche technische Probleme. Liefere danach die wichtigsten Änderungen in Prioritätsreihenfolge und erkläre, welche Änderungen ich konkret umsetzen sollte.");
        }).show();
    }

    private void showMessages(){
        String s=getSharedPreferences("jarves_runtime",0).getString("last_message_text","");
        String sender=getSharedPreferences("jarves_runtime",0).getString("last_message_sender","");
        String body=s.isEmpty()?"Keine erkannte Nachricht vorhanden.":"Von "+sender+": "+s;
        new AlertDialog.Builder(this).setTitle("NACHRICHTEN").setMessage(body).setPositiveButton("MESSAGING ÖFFNEN",(d,w)->openCategory(Intent.CATEGORY_APP_MESSAGING,new String[]{"whatsapp","nachricht","message","messaging","sms"})).setNeutralButton("BENACHRICHTIGUNGEN",(d,w)->{try{startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));}catch(Exception ignored){}}).setNegativeButton("SCHLIESSEN",null).show();
    }

    private void showQuickAccess(){
        final String[] items={"Heute / Tagesbriefing","Aufgaben","Kunden","Memory","Nachrichten","YouTube","Karten","ChatGPT","Übersetzen","Playlist"};
        new AlertDialog.Builder(this).setTitle("SCHNELLZUGRIFF • ALLTAG").setItems(items,(d,w)->{
            if(w==0) ask("Gib mir ein kurzes Tagesbriefing: heutige Termine, offene Aufgaben, wichtige Erinnerungen und was heute zuerst erledigt werden sollte. Nenne nur Informationen, die du wirklich aus dem Tablet oder der aktuellen Websuche hast.");
            else if(w==1) showTasks();
            else if(w==2) showCustomers();
            else if(w==3) showMemory();
            else if(w==4)openCategory(Intent.CATEGORY_APP_MESSAGING,new String[]{"whatsapp","nachricht","message","messaging","sms"});
            else if(w==5)openUrl("https://www.youtube.com");
            else if(w==6)openUrl("https://maps.google.com");
            else if(w==7)openUrl("https://chatgpt.com");
            else if(w==8)openUrl("https://translate.google.com");
            else openCategory(Intent.CATEGORY_APP_MUSIC,new String[]{"spotify","musik","music"});
        }).show();
    }

    private void showSystem(){
        SecretStore s=new SecretStore(this);boolean key=!s.get("gemini_key","").isEmpty();
        String msg="Jarves: aktiv\nAndroid-Assistent: "+(isDefaultAssistant()?"aktiv":"nicht gesetzt")+"\nAndroid-Steuerung: "+(JarvesAccessibilityService.isEnabled()?"aktiv":"nicht aktiviert")+"\nGemini API + Web: "+(key?"verbunden":"API-Key fehlt")+"\nKontakte: "+(checkSelfPermission(Manifest.permission.READ_CONTACTS)==PackageManager.PERMISSION_GRANTED?"OK":"optional")+"\nKalender: "+(checkSelfPermission(Manifest.permission.READ_CALENDAR)==PackageManager.PERMISSION_GRANTED?"aktiv":"aus")+"\nKunden: "+db.customerCount()+"\nAufgaben: "+db.taskCount()+"\nMemory: "+db.memoryCount();
        new AlertDialog.Builder(this).setTitle("SYSTEMSTATUS").setMessage(msg).setPositiveButton("EINSTELLUNGEN",(d,w)->showSettings()).setNegativeButton("SCHLIESSEN",null).show();
    }

    private void showApps(){
        final android.content.pm.PackageManager pm=getPackageManager();java.util.List<android.content.pm.ResolveInfo> list=pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),0);
        String[] names=new String[list.size()];for(int i=0;i<list.size();i++)names[i]=list.get(i).loadLabel(pm).toString();
        new AlertDialog.Builder(this).setTitle("APPS").setItems(names,(d,w)->{Intent in=pm.getLaunchIntentForPackage(list.get(w).activityInfo.packageName);if(in!=null)startActivity(in);}).show();
    }

    private void openCategory(String category,String[] fallbacks){
        Intent in=new Intent(Intent.ACTION_MAIN).addCategory(category);try{startActivity(in);return;}catch(Exception ignored){}
        android.content.pm.PackageManager pm=getPackageManager();for(android.content.pm.ResolveInfo r:pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),0)){
            String p=r.activityInfo.packageName.toLowerCase(Locale.GERMANY);for(String f:fallbacks)if(p.contains(f)){Intent x=pm.getLaunchIntentForPackage(r.activityInfo.packageName);if(x!=null){startActivity(x);return;}}
        }
        showToast("Keine passende App gefunden.");
    }
    private void openUrl(String url){try{startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(url)));}catch(Exception e){showToast("Konnte Link nicht öffnen.");}}
    private void showToast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    private void showCalendarPanel(){
        ask("Zeige mir meine heutigen und nächsten Kalendereinträge. Nenne die echten Termine vom Tablet-Kalender und biete danach an, einen neuen Termin anzulegen.");
    }

    private void showNotes(){
        String json=db.memoryJson("");
        EditText note=new EditText(this);
        note.setHint("Neue Notiz für Jarves …");
        note.setMinLines(3);
        note.setGravity(android.view.Gravity.TOP);
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(24,8,24,8);
        TextView existing=new TextView(this);
        existing.setText(json==null||json.trim().isEmpty()?"Noch keine gespeicherten Notizen.":"Gespeicherte Notizen:\n"+json);
        existing.setTextSize(14);
        existing.setPadding(0,0,0,14);
        box.addView(existing);
        box.addView(note);
        new AlertDialog.Builder(this).setTitle("JARVES • NOTIZEN").setView(box)
                .setPositiveButton("NOTIZ SPEICHERN",(d,w)->{
                    String text=note.getText().toString().trim();
                    if(text.isEmpty()){showToast("Keine Notiz eingegeben.");return;}
                    db.remember(text);
                    hud.setStatus("NOTIZ • GESPEICHERT");
                    hud.setAnswer(text);
                })
                .setNeutralButton("JARVES FRAGEN",(d,w)->listenOnce())
                .setNegativeButton("SCHLIESSEN",null).show();
    }

    private void showSmartHome(){
        final String[] items={"Home Assistant öffnen","Google Home öffnen","Jarves Smart-Home-Befehl"};
        new AlertDialog.Builder(this).setTitle("JARVES • SMART HOME").setItems(items,(d,w)->{
            if(w==0) openCategory(Intent.CATEGORY_LAUNCHER,new String[]{"homeassistant","home.assistant"});
            else if(w==1) openCategory(Intent.CATEGORY_LAUNCHER,new String[]{"googlehome","google.home"});
            else ask("Steuere mein Smart Home. Prüfe zuerst, welche Smart-Home-Verbindung auf diesem Tablet verfügbar ist, und führe nur eine tatsächlich unterstützte Aktion aus.");
        }).setNegativeButton("SCHLIESSEN",null).show();
    }

    private void showInternetStatus(){
        android.net.ConnectivityManager cm=(android.net.ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        boolean connected=false;
        try{connected=cm!=null&&cm.getActiveNetwork()!=null;}catch(Exception ignored){}
        String text=connected?"Internetverbindung ist aktiv.":"Keine aktive Internetverbindung erkannt.";
        new AlertDialog.Builder(this).setTitle("JARVES • INTERNET").setMessage(text).setPositiveButton("WEBTEST",(d,w)->ask("Prüfe, ob eine aktuelle Internetverbindung vorhanden ist, und beantworte danach: Was ist heute bei mir online aktuell wichtig?"))
                .setNegativeButton("SCHLIESSEN",null).show();
    }

    private void showSettings(){
        SecretStore old=new SecretStore(this);
        ScrollView scroll=new ScrollView(this);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(28,18,28,18);scroll.addView(box);
        TextView intro=new TextView(this);intro.setText("TABLET-VERBINDUNG\nJarves richtet die wichtigen Android-Schnittstellen ein. Die Oberfläche bleibt bewusst schlank; jede Schaltfläche führt direkt zu einer echten Android-Funktion oder Berechtigung. Erteile nur die Freigaben, die du verwenden möchtest.");intro.setTextSize(16);intro.setPadding(0,0,0,18);box.addView(intro);
        addSettingsButton(box,"MIKROFON • Sprachsteuerung",v->requestPermissions());
        addSettingsButton(box,"BENACHRICHTIGUNGEN • WhatsApp/SMS/E-Mails lesen",v->openSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
        TextView emailInfo=new TextView(this);emailInfo.setText("E-MAILS • DIREKTER GMAIL-ZUGRIFF\nWenn dasselbe Gmail-Konto auf Handy und Tablet verwendet wird, liegen die Mails in derselben Google-Mailbox. Jarves greift nach deiner OAuth-Freigabe direkt auf dieses Online-Postfach zu – nicht auf eine lokale Kopie des Handys. Du kannst mehrere Gmail-Konten verbinden. Passwörter speichert Jarves nicht. Der erste Abruf wird als Bestand erkannt; nur danach neu eingehende Mails werden als neue Aktivitäten gemeldet.");emailInfo.setTextSize(13);emailInfo.setPadding(0,0,0,12);box.addView(emailInfo);
        addSettingsButton(box,"GMAIL • KONTO VERBINDEN / WECHSELN",v->connectGmail());
        TextView gmailStatus=new TextView(this);gmailStatus.setText(gmail==null?"":gmail.connectedAccountsText());gmailStatus.setTextSize(13);gmailStatus.setPadding(0,0,0,12);box.addView(gmailStatus);
        addSettingsButton(box,"GMAIL • JETZT SYNCHRONISIEREN",v->syncGmailNow());
        addSettingsButton(box,"JARVES TEAM • GEMEINSAMEN WORKSPACE EINRICHTEN",v->showWorkspaceSettings());
        addSettingsButton(box,"KALENDER • Termine verbinden",v->{requestCalendarPermissions();});
        addSettingsButton(box,"KALENDER • Gemeinsamen Teamkalender auswählen",v->chooseTeamCalendar());
        addSettingsButton(box,"KONTAKTE • Kunden aus Android-Kontakten übernehmen",v->importContact());
        addSettingsButton(box,"SMS • Versandberechtigung",v->{requestPermissions(new String[]{Manifest.permission.SEND_SMS},51);});
        addSettingsButton(box,"JARVES • Android-Steuerung aktivieren",v->openSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        addSettingsButton(box,"JARVES • Als Android-Assistent festlegen",v->requestAssistantRole());
        addSettingsButton(box,"JARVES • Über anderen Apps anzeigen (optional)",v->openOverlaySettings());
        addSettingsButton(box,"JARVES • Vollständige Systemdiagnose",v->showDiagnostics());
        addSettingsButton(box,"SPRACHE • Stimme auswählen",v->openSettings("android.settings.TTS_SETTINGS"));
        addSettingsButton(box,"SPRACHE • Jarves Stimme testen",v->testJarvesVoice());
        box.addView(section("AKTIVITÄTSWACHE • 30–60 MINUTEN & TAGESABSCHLUSS"));
        android.content.SharedPreferences ap=getSharedPreferences("jarves_activity",0);
        CheckBox activityWatch=new CheckBox(this); activityWatch.setText("Neue Nachrichten / Eingänge überwachen und nur bei neuen Aktivitäten nachfragen"); activityWatch.setChecked(ap.getBoolean("monitor_enabled",true)); box.addView(activityWatch);
        Spinner activityInterval=new Spinner(this); String[] intervals={"30 Minuten","60 Minuten"}; ArrayAdapter<String> ia=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,intervals); activityInterval.setAdapter(ia); activityInterval.setSelection(ap.getInt("interval_minutes",30)>=60?1:0); box.addView(activityInterval);
        CheckBox dailyDigest=new CheckBox(this); dailyDigest.setText("Tagesabschluss vorlesen"); dailyDigest.setChecked(ap.getBoolean("daily_enabled",true)); box.addView(dailyDigest);
        LinearLayout digestRow=new LinearLayout(this); digestRow.setOrientation(LinearLayout.HORIZONTAL);
        EditText digestHour=new EditText(this); digestHour.setHint("18"); digestHour.setText(String.valueOf(ap.getInt("digest_hour",18))); digestHour.setInputType(2); digestRow.addView(digestHour,new LinearLayout.LayoutParams(0,60,1));
        TextView colon=new TextView(this); colon.setText(":"); colon.setTextSize(20); colon.setGravity(android.view.Gravity.CENTER); digestRow.addView(colon,new LinearLayout.LayoutParams(40,60));
        EditText digestMinute=new EditText(this); digestMinute.setHint("00"); digestMinute.setText(String.format(Locale.GERMANY,"%02d",ap.getInt("digest_minute",0))); digestMinute.setInputType(2); digestRow.addView(digestMinute,new LinearLayout.LayoutParams(0,60,1));
        box.addView(digestRow);
        TextView activityInfo=new TextView(this); activityInfo.setText("Jarves fragt z. B. „Bist du da?“ nur wenn seit der letzten Prüfung neue Nachrichten, Kundeneingänge, Aufträge oder Verkäufe erfasst wurden. Am Tagesende liest Jarves die gesammelten Aktivitäten einmal zusammengefasst vor."); activityInfo.setTextSize(13); activityInfo.setPadding(0,6,0,14); box.addView(activityInfo);
        addSettingsButton(box,"AKTIVITÄTSWACHE • jetzt prüfen",v->{ new JarvesAlarmReceiver().onReceive(this,new Intent(ActivityScheduler.ACTION_CHECK)); });
        addSettingsButton(box,"AKKU • Hintergrundbetrieb prüfen",v->openSettings(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        addSettingsButton(box,"APP-BERECHTIGUNGEN • Jarves verwalten",v->openSettings(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));
        box.addView(section("KI / AGENT"));
        EditText key=new EditText(this);key.setHint("Gemini API Key (Google AI Studio)");key.setInputType(0x81);key.setText(old.get("gemini_key",""));box.addView(key);
        EditText model=new EditText(this);model.setHint("Gemini-Modell");model.setText(old.get("gemini_model","gemini-2.5-flash-lite"));box.addView(model);
        box.addView(section("KI-MODUS"));
        CheckBox localFirst=new CheckBox(this);localFirst.setText("Kostenlose Gerätefunktionen bevorzugt lokal ausführen");localFirst.setChecked("true".equals(old.get("local_first","true")));box.addView(localFirst);
        TextView freeInfo=new TextView(this);freeInfo.setText("Kostenloser Modus: lokale Gerätefunktionen ohne API. Für KI und automatische Google-Websuche wird ein persönlicher Gemini API-Key benötigt. Google kann Quoten, Preise und Bedingungen ändern; Jarves hinterlegt keine Zahlungsdaten und löst keine Zahlungsfreigabe aus. Prüfe die Abrechnung deines Google-Kontos selbst.");freeInfo.setTextSize(13);freeInfo.setPadding(0,4,0,14);box.addView(freeInfo);
        box.addView(section("NACHRICHTEN"));
        CheckBox sms=new CheckBox(this);sms.setText("SMS automatisch senden");sms.setChecked("true".equals(old.get("auto_sms","false")));box.addView(sms);
        CheckBox wa=new CheckBox(this);wa.setText("WhatsApp automatisch senden");wa.setChecked("true".equals(old.get("auto_whatsapp","false")));box.addView(wa);
        EditText waId=new EditText(this);waId.setHint("WhatsApp Business Phone Number ID");waId.setText(old.get("wa_phone_id",""));box.addView(waId);
        EditText waToken=new EditText(this);waToken.setHint("WhatsApp Cloud API Access Token");waToken.setInputType(0x81);waToken.setText(old.get("wa_token",""));box.addView(waToken);
        box.addView(section("STATUS"));
        TextView status=new TextView(this);status.setText(connectionStatus());status.setTextSize(15);status.setPadding(0,8,0,16);box.addView(status);
        new AlertDialog.Builder(this).setTitle("JARVES • TABLET VERBINDEN").setView(scroll).setPositiveButton("SPEICHERN",(d,w)->{SecretStore s=new SecretStore(this);s.put("gemini_key",key.getText().toString().trim());s.put("gemini_model",model.getText().toString().trim());s.put("openai_key","");s.put("model","");s.put("auto_sms",Boolean.toString(sms.isChecked()));s.put("auto_whatsapp",Boolean.toString(wa.isChecked()));s.put("wa_phone_id",waId.getText().toString().trim());s.put("wa_token",waToken.getText().toString().trim());s.put("local_first",Boolean.toString(localFirst.isChecked()));s.put("previous_response_id","");
            android.content.SharedPreferences ap2=getSharedPreferences("jarves_activity",0);
            int interval=activityInterval.getSelectedItemPosition()==1?60:30;
            int dh=parseSafeInt(digestHour.getText().toString(),18,0,23);
            int dm=parseSafeInt(digestMinute.getText().toString(),0,0,59);
            ap2.edit().putBoolean("monitor_enabled",activityWatch.isChecked()).putInt("interval_minutes",interval).putBoolean("daily_enabled",dailyDigest.isChecked()).putInt("digest_hour",dh).putInt("digest_minute",dm).apply();
            ActivityScheduler.configure(this);
            hud.setStatus("SYSTEM • VERBUNDEN");}).setNegativeButton("SCHLIESSEN",null).show();
    }


    private void showWorkspaceSettings(){
        if(workspace==null) workspace=new WorkspaceManager(this);
        android.content.SharedPreferences p=getSharedPreferences("jarves_workspace",0);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(24,12,24,12);
        TextView info=new TextView(this);info.setText("JARVES TEAM • GEMEINSAMER ARBEITSRAUM\n\nAlle Geräte deines Teams können Kunden, Aufgaben und Aktivitäten gemeinsam sehen. Kalender bleiben über Google Kalender synchron. Wenn mehrere Jarves-Geräte gleichzeitig im selben Raum aktiv sind, übernimmt nur ein Gerät die Sprachsitzung.\n\nFür eine echte Mehrgeräte-Nutzung braucht ihr ein gemeinsames Jarves Cloud. Die vier Projektwerte werden nur lokal für die Verbindung gespeichert; Passwörter werden nicht in Jarves abgelegt.");info.setTextSize(13);info.setPadding(0,0,0,14);box.addView(info);
        EditText api=new EditText(this);api.setHint("Jarves Cloud URL (https://...)");api.setText(p.getString("firebase_api_key",""));box.addView(api);
        EditText appId=new EditText(this);appId.setHint("Workspace-Name");appId.setText(p.getString("firebase_app_id",""));box.addView(appId);
        EditText project=new EditText(this);project.setHint("Cloud-Projekt (optional)");project.setText(p.getString("firebase_project_id",""));box.addView(project);
        EditText sender=new EditText(this);sender.setHint("Geräte-ID (optional)");sender.setText(p.getString("firebase_sender_id",""));box.addView(sender);
        EditText email=new EditText(this);email.setHint("Team-Konto E-Mail");email.setInputType(33);box.addView(email);
        EditText pass=new EditText(this);pass.setHint("Passwort");pass.setInputType(0x81);box.addView(pass);
        TextView state=new TextView(this);state.setText(workspace.signedIn()?"Verbunden: "+workspace.workspaceName()+" • "+workspace.email():"Noch nicht verbunden");state.setTextSize(14);state.setPadding(0,12,0,12);box.addView(state);
        EditText workspaceName=new EditText(this);workspaceName.setHint("Name für neuen Workspace, z. B. Müller & Partner");box.addView(workspaceName);
        EditText invite=new EditText(this);invite.setHint("Einladungscode des Partners");box.addView(invite);
        new AlertDialog.Builder(this).setTitle("JARVES TEAM").setView(box)
            .setNeutralButton("SPEICHERN",(d,w)->{workspace.saveFirebaseConfig(api.getText().toString(),appId.getText().toString(),project.getText().toString(),sender.getText().toString());hud.setStatus("TEAM • KONFIGURIERT");})
            .setNegativeButton("SCHLIESSEN",null)
            .setPositiveButton("WEITER",(d,w)->{workspace.saveFirebaseConfig(api.getText().toString(),appId.getText().toString(),project.getText().toString(),sender.getText().toString());
                String e=email.getText().toString().trim(),pw=pass.getText().toString();
                if(!workspace.configured()){showToast("Jarves Cloudwerte fehlen.");return;}
                workspace.login(e,pw,(ok,msg)->runOnUiThread(()->{hud.setStatus(ok?"TEAM • ANGEMELDET":"TEAM • FEHLER");showToast(msg);if(ok)showWorkspaceActions(workspaceName.getText().toString().trim(),invite.getText().toString().trim());}));
            }).show();
    }

    private void showWorkspaceActions(String name,String code){
        final String[] items={"Neuen Workspace erstellen","Mit Einladungscode beitreten","Jetzt synchronisieren","Abmelden"};
        new AlertDialog.Builder(this).setTitle("JARVES TEAM • "+workspace.workspaceName()).setItems(items,(d,w)->{
            if(w==0){ if(name.isEmpty()){showToast("Bitte zuerst einen Workspace-Namen eingeben.");return;} workspace.createWorkspace(name,(ok,msg)->runOnUiThread(()->showToast(msg))); }
            else if(w==1){ if(code.isEmpty()){showToast("Bitte Einladungscode eingeben.");return;} workspace.joinWorkspace(code,(ok,msg)->runOnUiThread(()->showToast(msg))); }
            else if(w==2){workspace.syncNow((ok,msg)->runOnUiThread(()->showToast(msg)));}
            else {workspace.signOut();showToast("Jarves Team abgemeldet.");}
        }).setNegativeButton("SCHLIESSEN",null).show();
    }


    private void chooseTeamCalendar(){
        requestCalendarPermissions();
        try{
            org.json.JSONArray a=new org.json.JSONArray(new CalendarManager(this).visibleCalendarsJson());
            if(a.length()==0){showToast("Kein sichtbarer Kalender gefunden.");return;}
            String[] labels=new String[a.length()];String[] ids=new String[a.length()];
            for(int i=0;i<a.length();i++){org.json.JSONObject o=a.getJSONObject(i);ids[i]=String.valueOf(o.optLong("id"));labels[i]=o.optString("name","Kalender")+" • "+o.optString("account","");}
            new AlertDialog.Builder(this).setTitle("TEAMKALENDER").setItems(labels,(d,w)->{new CalendarManager(this).setPreferredCalendar(ids[w]);hud.setStatus("KALENDER • TEAM GEWÄHLT");showToast("Jarves verwendet künftig diesen Kalender für neue Termine.");}).setNegativeButton("SCHLIESSEN",null).show();
        }catch(Exception e){showToast("Kalender konnten nicht geladen werden.");}
    }

    private void connectGmail(){
        if(gmail==null) gmail=new GmailConnector(this);
        hud.setStatus("GMAIL • FREIGABE");
        gmail.connect(this,(message,success)->{
            hud.setStatus(success?"GMAIL • VERBUNDEN":"GMAIL • FEHLER");
            refreshHudData();
            new AlertDialog.Builder(this).setTitle(success?"GMAIL • VERBUNDEN":"GMAIL • FEHLER").setMessage(message).setPositiveButton("OK",null).show();
        });
    }

    private void syncGmailNow(){
        if(gmail==null) gmail=new GmailConnector(this);
        hud.setStatus("GMAIL • SYNCHRONISIERE");
        gmail.syncStoredAccounts((count,message)->runOnUiThread(()->{
            hud.setStatus(count>0?"GMAIL • NEUE MAILS":"GMAIL • AKTUELL");
            refreshHudData();
            new AlertDialog.Builder(this).setTitle("GMAIL • SYNCHRONISIERUNG").setMessage(message).setPositiveButton("OK",null).show();
        }));
    }

    private void testJarvesVoice(){
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions();
            return;
        }
        Intent i=new Intent(this,JarvesVoiceService.class);
        i.putExtra("listen_once",false);
        i.putExtra("test_tts",true);
        i.putExtra("interrupt",true);
        if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
        hud.setStatus("SPRACHE • TEST");
    }

    private int parseSafeInt(String raw,int fallback,int min,int max){try{int v=Integer.parseInt(raw.trim());return Math.max(min,Math.min(max,v));}catch(Exception e){return fallback;}}
    private TextView section(String t){TextView v=new TextView(this);v.setText(t);v.setTextSize(13);v.setTypeface(null,android.graphics.Typeface.BOLD);v.setPadding(0,20,0,8);return v;}
    private void addSettingsButton(LinearLayout box,String text,View.OnClickListener l){Button b=new Button(this);b.setText(text);b.setAllCaps(false);b.setOnClickListener(l);box.addView(b,new LinearLayout.LayoutParams(-1,60));}
    private String connectionStatus(){return "Mikrofon: "+(checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED?"OK":"fehlt")+"\nKontakte: "+(checkSelfPermission(Manifest.permission.READ_CONTACTS)==PackageManager.PERMISSION_GRANTED?"OK":"optional")+"\nKalender: "+(checkSelfPermission(Manifest.permission.READ_CALENDAR)==PackageManager.PERMISSION_GRANTED?"OK":"fehlt")+"\nSMS: "+(checkSelfPermission(Manifest.permission.SEND_SMS)==PackageManager.PERMISSION_GRANTED?"OK":"fehlt")+"\nGemini: "+(!new SecretStore(this).get("gemini_key","").isEmpty()?"konfiguriert":"fehlt")+"\nAndroid-Assistent: "+(isDefaultAssistant()?"OK":"nicht gesetzt")+"\nBedienungshilfe: "+(JarvesAccessibilityService.isEnabled()?"OK":"fehlt")+"\nOverlay: "+(android.provider.Settings.canDrawOverlays(this)?"OK":"optional")+"\nKunden: "+db.customerCount()+"  Aufgaben: "+db.taskCount()+"  Memory: "+db.memoryCount();}
    private void showStudyCenter(){
        final String[] items={"Thema erklären","Lernzettel erstellen","Text zusammenfassen","Karteikarten erstellen","Quiz erstellen","Hausaufgabe prüfen","Lernplan erstellen","Deutsch / Englisch üben","Foto / Arbeitsblatt lesen","Notiz speichern"};
        new AlertDialog.Builder(this).setTitle("JARVES • LERNEN & SCHULE").setItems(items,(d,w)->{
            switch(w){
                case 0: ask("Erkläre mir das Thema so, dass ich es wirklich verstehe. Beginne einfach, nenne danach ein konkretes Beispiel und stelle mir am Ende zwei kurze Verständnisfragen."); break;
                case 1: ask("Erstelle mir aus meinem nächsten Inhalt einen klaren Lernzettel mit Definitionen, Kernaussagen, Beispielen und typischen Prüfungsfragen. Wenn noch kein Inhalt genannt wurde, frage danach."); break;
                case 2: ask("Fasse den von mir genannten Text oder Stoff verständlich zusammen. Trenne Kernaussagen, wichtige Details und Begriffe. Wenn kein Text vorliegt, frage danach."); break;
                case 3: ask("Erstelle Karteikarten aus dem Stoff. Vorderseite Frage, Rückseite kurze korrekte Antwort. Priorisiere prüfungsrelevante Inhalte."); break;
                case 4: ask("Erstelle ein kurzes Quiz zum zuletzt besprochenen Stoff. Stelle eine Frage nach der anderen und korrigiere meine Antwort mit kurzer Erklärung."); break;
                case 5: ask("Prüfe meine Hausaufgabe fachlich. Zeige Fehler und erkläre sie, ohne einfach die Lösung vorwegzunehmen. Wenn die Aufgabe noch fehlt, frage danach."); break;
                case 6: ask("Erstelle mir einen realistischen Lernplan mit kleinen Einheiten, Wiederholungen und Pausen. Nutze Termine und Fristen aus dem Kontext, wenn vorhanden."); break;
                case 7: ask("Übe mit mir Deutsch oder Englisch als persönlicher Sprachtrainer. Starte mit einer kurzen Aufgabe und passe die Schwierigkeit an meine Antworten an."); break;
                case 8: scanStudyImage(); break;
                default: ask("Speichere meine nächste Information als dauerhafte Jarves-Notiz. Frage nur nach, wenn nicht klar ist, was gespeichert werden soll."); break;
            }
        }).setNegativeButton("SCHLIESSEN",null).show();
    }

    private void scanStudyImage(){
        try{
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            startActivityForResult(i,92);
        }catch(Exception e){showToast("Bildauswahl ist auf diesem Tablet nicht verfügbar.");}
    }

    private void showOcrResult(String text){
        if(text==null||text.trim().isEmpty()){showToast("Kein Text erkannt.");return;}
        final String clean=text.trim();
        new AlertDialog.Builder(this).setTitle("JARVES • TEXT ERKANNT").setMessage(clean.length()>5000?clean.substring(0,5000)+"…":clean)
                .setPositiveButton("ERKLÄREN",(d,w)->ask("Erkläre mir diesen erkannten Text verständlich und nenne die wichtigsten Lernpunkte:\n"+clean))
                .setNeutralButton("LERNZETTEL",(d,w)->ask("Erstelle aus diesem erkannten Text einen Lernzettel mit Kernaussagen, Begriffen, Beispielen und Prüfungsfragen:\n"+clean))
                .setNegativeButton("SCHLIESSEN",null).show();
    }

    private boolean isDefaultAssistant(){
        if(Build.VERSION.SDK_INT<29)return false;
        try{
            RoleManager rm=(RoleManager)getSystemService(RoleManager.class);
            return rm!=null && rm.isRoleHeld(RoleManager.ROLE_ASSISTANT);
        }catch(Exception e){return false;}
    }

    private void requestAssistantRole(){
        if(Build.VERSION.SDK_INT<29){showToast("Diese Android-Version unterstützt die Assistant-Rolle nicht.");return;}
        try{
            RoleManager rm=(RoleManager)getSystemService(RoleManager.class);
            if(rm!=null && rm.isRoleAvailable(RoleManager.ROLE_ASSISTANT)){
                if(rm.isRoleHeld(RoleManager.ROLE_ASSISTANT)){showToast("Jarves ist bereits der Android-Assistent.");return;}
                startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_ASSISTANT),90);
            }else showToast("Die Assistant-Rolle ist auf diesem Tablet nicht verfügbar.");
        }catch(Exception e){showToast("Android konnte die Assistant-Rolle nicht öffnen.");}
    }

    private void openOverlaySettings(){
        try{
            if(Build.VERSION.SDK_INT>=23 && !Settings.canDrawOverlays(this)){
                Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()));startActivity(i);
            }else showToast("Overlay-Berechtigung ist bereits aktiv.");
        }catch(Exception e){showToast("Overlay-Einstellung ist auf diesem Tablet nicht verfügbar.");}
    }

    private void showDiagnostics(){
        SecretStore s=new SecretStore(this);
        StringBuilder b=new StringBuilder();
        b.append("JARVES SELBSTTEST\n\n");
        b.append("Mikrofon: ").append(checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED?"OK":"FEHLT").append('\n');
        b.append("TTS: ").append(android.speech.tts.TextToSpeech.getMaxSpeechInputLength()>0?"API OK":"PRÜFEN").append('\n');
        b.append("SpeechRecognizer: ").append(android.speech.SpeechRecognizer.isRecognitionAvailable(this)?"OK":"FEHLT").append('\n');
        if(Build.VERSION.SDK_INT>=31)b.append("On-Device Speech: ").append(android.speech.SpeechRecognizer.isOnDeviceRecognitionAvailable(this)?"VERFÜGBAR":"NICHT VERFÜGBAR").append('\n');
        b.append("Kontakte: ").append(checkSelfPermission(Manifest.permission.READ_CONTACTS)==PackageManager.PERMISSION_GRANTED?"OK":"OPTIONAL").append('\n');
        b.append("Kalender: ").append(checkSelfPermission(Manifest.permission.READ_CALENDAR)==PackageManager.PERMISSION_GRANTED?"OK":"FEHLT").append('\n');
        b.append("SMS: ").append(checkSelfPermission(Manifest.permission.SEND_SMS)==PackageManager.PERMISSION_GRANTED?"OK":"FEHLT").append('\n');
        b.append("Assistant-Rolle: ").append(isDefaultAssistant()?"OK":"NICHT GESETZT").append('\n');
        b.append("Bedienungshilfe: ").append(JarvesAccessibilityService.isEnabled()?"OK":"NICHT AKTIV").append('\n');
        b.append("Benachrichtigungszugriff: ").append(isNotificationListenerEnabled()?"OK":"NICHT AKTIV").append('\n');
        b.append("Overlay: ").append(Settings.canDrawOverlays(this)?"OK":"OPTIONAL").append('\n');
        b.append("Gemini: ").append(s.get("gemini_key","").isEmpty()?"FEHLT":"KONFIGURIERT").append('\n');
        b.append("Gmail: ").append(gmail==null?"PRÜFEN":gmail.connectedAccountsText()).append('\n');
        b.append("Jarves Team: ").append(workspace==null?"NICHT KONFIGURIERT":(workspace.signedIn()?"VERBUNDEN • "+workspace.workspaceName():"NICHT ANGEMELDET")).append('\n');
        b.append("Kunden: ").append(db.customerCount()).append(" | Aufgaben: ").append(db.taskCount()).append(" | Memory: ").append(db.memoryCount());
        new AlertDialog.Builder(this).setTitle("JARVES • DIAGNOSE").setMessage(b.toString()).setPositiveButton("SCHLIESSEN",null).show();
    }

    private boolean isNotificationListenerEnabled(){
        try{
            String enabled=Settings.Secure.getString(getContentResolver(),"enabled_notification_listeners");
            return enabled!=null && enabled.contains(new ComponentName(this,JarvesNotificationListener.class).flattenToString());
        }catch(Exception e){return false;}
    }

    private void importContact(){
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS},53);
            return;
        }
        try{
            Intent i=new Intent(Intent.ACTION_PICK,ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
            startActivityForResult(i,91);
        }catch(Exception e){showToast("Kontakt-Auswahl ist auf diesem Tablet nicht verfügbar.");}
    }

    private void requestCalendarPermissions(){requestPermissions(new String[]{Manifest.permission.READ_CALENDAR,Manifest.permission.WRITE_CALENDAR},52);}
    private void openSettings(String action){openSettings(action,null);}
    private void openSettings(String action,Uri data){try{Intent i=new Intent(action);if(data!=null)i.setData(data);startActivity(i);}catch(Exception e){showToast("Diese Android-Einstellung ist auf dem Tablet nicht verfügbar.");}}

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==50 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED){
            new android.os.Handler().postDelayed(this::startJarves,350);
        }
        if(requestCode==53 && checkSelfPermission(Manifest.permission.READ_CONTACTS)==PackageManager.PERMISSION_GRANTED){
            new android.os.Handler().postDelayed(this::importContact,200);
        }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==GmailConnector.REQUEST_AUTH){
            if(resultCode==RESULT_OK && data!=null){
                if(gmail==null) gmail=new GmailConnector(this);
                gmail.onAuthorizationResult(this,data,(message,success)->{
                    hud.setStatus(success?"GMAIL • VERBUNDEN":"GMAIL • FEHLER");
                    refreshHudData();
                    new AlertDialog.Builder(this).setTitle(success?"GMAIL • VERBUNDEN":"GMAIL • FEHLER").setMessage(message).setPositiveButton("OK",null).show();
                });
            } else {
                hud.setStatus("GMAIL • FREIGABE ABGEBROCHEN");
            }
            return;
        }
        if(requestCode==90){ hud.setStatus(isDefaultAssistant()?"SYSTEM • ASSISTENT AKTIV":"SYSTEM • ASSISTENT NICHT GESETZT"); return; }
        if(requestCode==92 && resultCode==RESULT_OK && data!=null && data.getData()!=null){
            hud.setStatus("OCR • VERARBEITUNG");
            if(ocr!=null)ocr.recognize(data.getData(),(text,error)->runOnUiThread(()->{
                if(error!=null && !error.isEmpty()){hud.setStatus("OCR • FEHLER");showToast(error);return;}
                hud.setStatus("OCR • FERTIG");showOcrResult(text);
            }));
            return;
        }
        if(requestCode==91 && resultCode==RESULT_OK && data!=null && data.getData()!=null){
            Cursor c=null;
            try{
                c=getContentResolver().query(data.getData(),new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER},null,null,null);
                if(c!=null && c.moveToFirst()){
                    String name=c.getString(0), phone=c.getString(1);
                    long id=db.saveCustomer(name,phone,"","Aus Android-Kontakten importiert.");
                    hud.setStatus(id>0?"KUNDE • IMPORTIERT":"KUNDE • FEHLER");
                    refreshHudData();
                }
            }catch(Exception e){showToast("Kontakt konnte nicht importiert werden.");}
            finally{if(c!=null)c.close();}
        }
    }

    @Override protected void onDestroy(){if(ocr!=null)ocr.close();super.onDestroy();}

    @Override protected void onResume(){super.onResume();
        refreshHudData();IntentFilter f=new IntentFilter(JarvesVoiceService.ACTION_UPDATE);if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(receiver,f);}
    @Override protected void onPause(){super.onPause();try{unregisterReceiver(receiver);}catch(Exception ignored){}}
}
