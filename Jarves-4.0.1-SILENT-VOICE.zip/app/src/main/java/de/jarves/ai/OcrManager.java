package de.jarves.ai;

import android.content.Context;
import android.net.Uri;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

/** Local/on-device OCR helper for school, documents and notes. */
public final class OcrManager {
    public interface Callback { void done(String text, String error); }
    private final Context context;
    private final TextRecognizer recognizer;
    public OcrManager(Context c){context=c.getApplicationContext();recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);}
    public void recognize(Uri uri, Callback cb){
        try{
            InputImage image=InputImage.fromFilePath(context,uri);
            recognizer.process(image).addOnSuccessListener(r->{String text=r==null?"":r.getText();cb.done(text==null?"":text,"");})
                    .addOnFailureListener(e->cb.done("",e==null?"OCR fehlgeschlagen.":e.getMessage()));
        }catch(Exception e){cb.done("",e.getMessage()==null?"Bild konnte nicht gelesen werden.":e.getMessage());}
    }
    public void close(){try{recognizer.close();}catch(Exception ignored){}}
}
