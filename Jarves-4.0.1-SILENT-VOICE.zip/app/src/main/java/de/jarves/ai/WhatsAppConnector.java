package de.jarves.ai;

import android.content.Context;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

public final class WhatsAppConnector {
    private final Context c; private final SecretStore s; private final JarvesDataStore db;
    public WhatsAppConnector(Context c,SecretStore s,JarvesDataStore db){this.c=c;this.s=s;this.db=db;}
    public String send(String target,String message){
        if(!"true".equals(s.get("auto_whatsapp","false"))) return "WHATSAPP NICHT GESENDET: automatische WhatsApp-Kommunikation ist deaktiviert.";
        String token=s.get("wa_token",""), phoneId=s.get("wa_phone_id","");
        if(token.isEmpty()||phoneId.isEmpty())return "WHATSAPP NICHT GESENDET: WhatsApp Business Cloud API ist noch nicht konfiguriert.";
        String to=target;
        if(!to.matches("[+0-9][+0-9 ()-]{5,}")){String p=db.findCustomerPhone(target);if(p!=null)to=p;}
        try{
            JSONObject body=new JSONObject().put("messaging_product","whatsapp").put("to",to.replaceAll("[ ()-]",""))
                    .put("type","text").put("text",new JSONObject().put("body",message));
            HttpURLConnection x=(HttpURLConnection)new URL("https://graph.facebook.com/v23.0/"+phoneId+"/messages").openConnection();
            x.setRequestMethod("POST");x.setRequestProperty("Authorization","Bearer "+token);
            x.setRequestProperty("Content-Type","application/json");x.setDoOutput(true);
            try(OutputStream o=x.getOutputStream()){o.write(body.toString().getBytes(StandardCharsets.UTF_8));}
            int code=x.getResponseCode();
            if(code>=200&&code<300)return "WhatsApp-Nachricht gesendet.";
            InputStream is=x.getErrorStream();byte[] b=is==null?new byte[0]:is.readAllBytes();
            return "WhatsApp API Fehler "+code+": "+new String(b,StandardCharsets.UTF_8);
        }catch(Exception e){return "WhatsApp fehlgeschlagen: "+e.getMessage();}
    }
}
