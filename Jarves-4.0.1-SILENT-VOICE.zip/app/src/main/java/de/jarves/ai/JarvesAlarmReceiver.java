package de.jarves.ai;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.core.app.NotificationCompat;
import java.util.Calendar;

public final class JarvesAlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent){
        String action=intent==null?"":intent.getAction();
        if(ActivityScheduler.ACTION_CHECK.equals(action)) { runActivityCheck(context); return; }
        if(ActivityScheduler.ACTION_DAILY.equals(action)) { runDailyDigest(context); return; }

        SecretStore s=new SecretStore(context); JarvesDataStore db=new JarvesDataStore(context);
        String channel=intent==null?"":intent.getStringExtra("channel"); String to=intent==null?"":intent.getStringExtra("to"); String message=intent==null?"":intent.getStringExtra("message");
        if("sms".equalsIgnoreCase(channel)){
            if("true".equals(s.get("auto_sms","false"))) new SmsConnector(context,s,db).send(to,message);
        } else if("whatsapp".equalsIgnoreCase(channel)){
            if("true".equals(s.get("auto_whatsapp","false"))) new WhatsAppConnector(context,s,db).send(to,message);
        }
    }

    private void runActivityCheck(Context context){
        ActivityScheduler.ensureDefaults(context);
        android.content.SharedPreferences p=context.getSharedPreferences("jarves_activity",Context.MODE_PRIVATE);
        if(!p.getBoolean("monitor_enabled",true)){ActivityScheduler.configure(context);return;}
        long now=System.currentTimeMillis();
        long since=p.getLong("last_check",now);
        // Direct Gmail sync happens first so a new customer/order email can enter
        // the same activity pipeline as WhatsApp/SMS notifications.
        new GmailConnector(context).syncStoredAccounts((newMailCount,gmailMessage)->{
            JarvesDataStore db=new JarvesDataStore(context);
            long checkNow=System.currentTimeMillis();
            String prompt=db.buildNewActivityPrompt(since,checkNow);
            p.edit().putLong("last_check",checkNow).apply();
            if(!prompt.isEmpty()){
                boolean hasPlanningSignal=prompt.toLowerCase(java.util.Locale.GERMANY).contains("email") || prompt.toLowerCase(java.util.Locale.GERMANY).contains("auftrag") || prompt.toLowerCase(java.util.Locale.GERMANY).contains("termin");
                if(hasPlanningSignal && !new SecretStore(context).get("gemini_key","").isEmpty()){
                    new AgentClient(context).reviewIncomingActivities((answer,status)->{
                        boolean spoken=JarvesVoiceService.speakIfRunning(context,answer);
                        if(!spoken) showActivityNotification(context,answer);
                    });
                }else{
                    boolean spoken=JarvesVoiceService.speakIfRunning(context,prompt);
                    if(!spoken) showActivityNotification(context,prompt);
                }
            }
            ActivityScheduler.configure(context);
        });
    }

    private void runDailyDigest(Context context){
        ActivityScheduler.ensureDefaults(context);
        android.content.SharedPreferences p=context.getSharedPreferences("jarves_activity",Context.MODE_PRIVATE);
        if(!p.getBoolean("daily_enabled",true)){ActivityScheduler.configure(context);return;}
        Calendar start=Calendar.getInstance(); start.set(Calendar.HOUR_OF_DAY,0); start.set(Calendar.MINUTE,0); start.set(Calendar.SECOND,0); start.set(Calendar.MILLISECOND,0);
        long now=System.currentTimeMillis();
        JarvesDataStore db=new JarvesDataStore(context);
        String digest=db.buildDailyDigest(start.getTimeInMillis(),now);
        p.edit().putLong("last_digest",now).apply();
        if(!digest.startsWith("Tagesabschluss: Heute gab es keine neuen")){
            JarvesVoiceService.speakIfRunning(context,digest);
            showDigestNotification(context,digest);
        }
        ActivityScheduler.configure(context);
    }

    private void showActivityNotification(Context c,String text){
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE); if(nm==null)return;
        if(android.os.Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel("jarves_activity","Jarves Aktivitätswache",NotificationManager.IMPORTANCE_DEFAULT));
        Intent open=new Intent(c,MainActivity.class); open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi=PendingIntent.getActivity(c,73005,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b=new NotificationCompat.Builder(c,"jarves_activity").setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("Jarves • Neue Aktivität").setContentText(text.length()>120?text.substring(0,120)+"…":text).setStyle(new NotificationCompat.BigTextStyle().bigText(text)).setAutoCancel(true).setContentIntent(pi);
        nm.notify(73006,b.build());
    }

    private void showDigestNotification(Context c,String text){
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE); if(nm==null)return;
        if(android.os.Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel("jarves_digest","Jarves Tagesbriefing",NotificationManager.IMPORTANCE_DEFAULT));
        Intent open=new Intent(c,MainActivity.class); open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi=PendingIntent.getActivity(c,73003,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b=new NotificationCompat.Builder(c,"jarves_digest").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Jarves • Tagesabschluss").setContentText(text.length()>120?text.substring(0,120)+"…":text).setStyle(new NotificationCompat.BigTextStyle().bigText(text)).setAutoCancel(true).setContentIntent(pi);
        nm.notify(73004,b.build());
    }
}
