package de.jarves.ai;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

public final class EmailConnector {
    private static final String PREF="jarves_email_draft";
    private final Context context;
    public EmailConnector(Context c){context=c.getApplicationContext();}
    public String prepare(String to,String subject,String body){
        context.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString("to",to==null?"":to).putString("subject",subject==null?"":subject).putString("body",body==null?"":body).apply();
        return "E-Mail-Entwurf vorbereitet. Empfänger: "+(to==null?"":to)+". Betreff: "+(subject==null?"":subject)+". Ich habe noch nichts gesendet. Wenn du 'Ja, senden' sagst, öffne ich den vorbereiteten Versand.";
    }
    public String openPending(){
        android.content.SharedPreferences p=context.getSharedPreferences(PREF,Context.MODE_PRIVATE); String to=p.getString("to","");String subject=p.getString("subject","");String body=p.getString("body","");
        if(to.isEmpty()&&subject.isEmpty()&&body.isEmpty())return "Kein offener E-Mail-Entwurf.";
        Intent i=new Intent(Intent.ACTION_SENDTO); i.setData(Uri.parse("mailto:"+(to.isEmpty()?"":to))); i.putExtra(Intent.EXTRA_SUBJECT,subject); i.putExtra(Intent.EXTRA_TEXT,body); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try{context.startActivity(i); return "Der vorbereitete E-Mail-Entwurf ist geöffnet. Bitte prüfe ihn und drücke selbst auf Senden.";}catch(Exception e){return "Keine E-Mail-App zum Öffnen gefunden.";}
    }
    public boolean hasPending(){ android.content.SharedPreferences p=context.getSharedPreferences(PREF,Context.MODE_PRIVATE); return !p.getString("subject","").isEmpty() || !p.getString("body","").isEmpty(); }
    public String pending(){android.content.SharedPreferences p=context.getSharedPreferences(PREF,Context.MODE_PRIVATE);return "An: "+p.getString("to","")+"\nBetreff: "+p.getString("subject","")+"\nText: "+p.getString("body","");}
}
