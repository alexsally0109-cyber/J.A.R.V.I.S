package de.jarves.ai;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.provider.CalendarContract;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public final class CalendarManager {
    private final Context context;
    public CalendarManager(Context c){context=c.getApplicationContext();}

    public String today(){
        Calendar start=Calendar.getInstance(); start.set(Calendar.HOUR_OF_DAY,0);start.set(Calendar.MINUTE,0);start.set(Calendar.SECOND,0);start.set(Calendar.MILLISECOND,0);
        Calendar end=(Calendar)start.clone();end.add(Calendar.DAY_OF_MONTH,1);
        return queryRange(start.getTimeInMillis(),end.getTimeInMillis());
    }

    public String queryDays(int days){
        int d=Math.max(1,Math.min(days,31));
        long now=System.currentTimeMillis();
        return queryRange(now-2*3600000L,now+d*86400000L);
    }

    private String queryRange(long from,long to){
        ContentResolver r=context.getContentResolver();
        Cursor c=r.query(CalendarContract.Instances.CONTENT_URI.buildUpon()
                .appendPath(String.valueOf(from)).appendPath(String.valueOf(to)).build(),
                new String[]{CalendarContract.Instances.TITLE,CalendarContract.Instances.BEGIN,CalendarContract.Instances.END,CalendarContract.Instances.EVENT_LOCATION},
                null,null,CalendarContract.Instances.BEGIN+" ASC");
        StringBuilder out=new StringBuilder();
        if(c!=null){while(c.moveToNext()){
            out.append(new SimpleDateFormat("dd.MM. HH:mm",Locale.GERMANY).format(new Date(c.getLong(1))))
               .append(" – ").append(c.getString(0));
            if(c.getString(3)!=null&&!c.getString(3).trim().isEmpty())out.append(" @ ").append(c.getString(3));
            out.append("\n");
        }c.close();}
        return out.length()==0?"Keine Termine im Zeitraum.":out.toString().trim();
    }

    public org.json.JSONArray eventsDetailed(int days){
        Calendar start=Calendar.getInstance(); start.set(Calendar.HOUR_OF_DAY,0);start.set(Calendar.MINUTE,0);start.set(Calendar.SECOND,0);start.set(Calendar.MILLISECOND,0);
        Calendar end=(Calendar)start.clone(); end.add(Calendar.DAY_OF_MONTH,Math.max(1,Math.min(days,31)));
        org.json.JSONArray out=new org.json.JSONArray();
        Cursor c=context.getContentResolver().query(CalendarContract.Instances.CONTENT_URI.buildUpon().appendPath(String.valueOf(start.getTimeInMillis())).appendPath(String.valueOf(end.getTimeInMillis())).build(),
                new String[]{CalendarContract.Instances.EVENT_ID,CalendarContract.Instances.TITLE,CalendarContract.Instances.BEGIN,CalendarContract.Instances.END,CalendarContract.Instances.EVENT_LOCATION,CalendarContract.Instances.DESCRIPTION},null,null,CalendarContract.Instances.BEGIN+" ASC");
        try{if(c!=null){while(c.moveToNext()){org.json.JSONObject o=new org.json.JSONObject();o.put("id",c.getLong(0));o.put("title",c.getString(1));o.put("start",c.getLong(2));o.put("end",c.getLong(3));o.put("location",c.getString(4)==null?"":c.getString(4));o.put("description",c.getString(5)==null?"":c.getString(5));out.put(o);}}}catch(Exception ignored){}finally{if(c!=null)c.close();}
        return out;
    }

    public String visibleCalendarsJson(){
        org.json.JSONArray out=new org.json.JSONArray();
        Cursor c=context.getContentResolver().query(CalendarContract.Calendars.CONTENT_URI,new String[]{CalendarContract.Calendars._ID,CalendarContract.Calendars.CALENDAR_DISPLAY_NAME,CalendarContract.Calendars.ACCOUNT_NAME},CalendarContract.Calendars.VISIBLE+"=1",null,CalendarContract.Calendars._ID+" ASC");
        try{if(c!=null)while(c.moveToNext()){org.json.JSONObject o=new org.json.JSONObject();o.put("id",c.getLong(0));o.put("name",c.getString(1)==null?"Kalender":c.getString(1));o.put("account",c.getString(2)==null?"":c.getString(2));out.put(o);}}catch(Exception ignored){}finally{if(c!=null)c.close();}
        return out.toString();
    }
    public void setPreferredCalendar(String id){context.getSharedPreferences("jarves_calendar",0).edit().putString("preferred_id",id==null?"":id).apply();}

    public String create(String title,long start,long end,String location,String description){
        if(end<=start)return "Der Endzeitpunkt muss nach dem Startzeitpunkt liegen.";
        ContentResolver r=context.getContentResolver();
        long id=-1;
        String preferred=context.getSharedPreferences("jarves_calendar",0).getString("preferred_id","");
        Cursor c=r.query(CalendarContract.Calendars.CONTENT_URI,
                new String[]{CalendarContract.Calendars._ID},CalendarContract.Calendars.VISIBLE+"=1 AND _id=?",preferred.isEmpty()?null:new String[]{preferred},null);
        if(c!=null && c.moveToFirst()) id=c.getLong(0);
        if(c!=null)c.close();
        if(id<0){
            c=r.query(CalendarContract.Calendars.CONTENT_URI,new String[]{CalendarContract.Calendars._ID},CalendarContract.Calendars.VISIBLE+"=1",null,CalendarContract.Calendars._ID+" ASC");
            if(c==null||!c.moveToFirst()){if(c!=null)c.close();return "Kein sichtbarer Kalender gefunden.";}
            id=c.getLong(0);c.close();
        }
        ContentValues v=new ContentValues();
        v.put(CalendarContract.Events.CALENDAR_ID,id);v.put(CalendarContract.Events.TITLE,title);
        v.put(CalendarContract.Events.DTSTART,start);v.put(CalendarContract.Events.DTEND,end);
        v.put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().getID());
        v.put(CalendarContract.Events.EVENT_LOCATION,location==null?"":location);
        v.put(CalendarContract.Events.DESCRIPTION,description==null?"":description);
        android.net.Uri u=r.insert(CalendarContract.Events.CONTENT_URI,v);
        return u==null?"Kalendereintrag konnte nicht erstellt werden.":"Termin erstellt: "+new SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.GERMANY).format(new Date(start))+" – "+title;
    }
}
