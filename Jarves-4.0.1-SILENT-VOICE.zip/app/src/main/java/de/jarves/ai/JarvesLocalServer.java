package de.jarves.ai;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Enumeration;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Small dependency-free HTTP server running directly on the Android tablet.
 * It exposes Jarves' local data and agent over the LAN. No PC, Firebase or
 * third-party server runtime is required.
 */
public final class JarvesLocalServer {
    public static final int PORT = 8787;
    private final Context context;
    private final JarvesDataStore db;
    private final SecretStore secrets;
    private volatile boolean running;
    private ServerSocket server;
    private Thread acceptThread;

    public JarvesLocalServer(Context c){
        context=c.getApplicationContext(); db=new JarvesDataStore(context); secrets=new SecretStore(context);
    }

    public synchronized void start(){
        if(running) return;
        try{
            server=new ServerSocket(PORT,32,InetAddress.getByName("0.0.0.0"));
            running=true;
            acceptThread=new Thread(()->{
                while(running){
                    try{ final Socket s=server.accept(); new Thread(()->handle(s),"jarves-http").start(); }
                    catch(Exception ignored){ if(running){} }
                }
            },"jarves-http-accept");
            acceptThread.start();
        }catch(Exception e){ running=false; closeServer(); }
    }

    public synchronized void stop(){ running=false; closeServer(); }
    private void closeServer(){ try{if(server!=null)server.close();}catch(Exception ignored){} server=null; }
    public boolean isRunning(){return running;}

    public String infoJson(){
        try{
            JSONObject o=new JSONObject(); o.put("running",running); o.put("port",PORT); o.put("token",token());
            JSONArray ips=new JSONArray(); Enumeration<NetworkInterface> ns=NetworkInterface.getNetworkInterfaces();
            while(ns!=null && ns.hasMoreElements()){
                NetworkInterface n=ns.nextElement(); Enumeration<InetAddress> as=n.getInetAddresses();
                while(as.hasMoreElements()){
                    InetAddress a=as.nextElement(); if(!a.isLoopbackAddress() && a instanceof java.net.Inet4Address) ips.put(a.getHostAddress());
                }
            }
            o.put("addresses",ips); return o.toString();
        }catch(Exception e){return "{\"running\":"+running+",\"port\":"+PORT+"}";}
    }

    private String token(){
        String t=secrets.get("local_server_token","");
        if(t.isEmpty()){
            t=java.util.UUID.randomUUID().toString().replace("-","");
            secrets.put("local_server_token",t);
        }
        return t;
    }

    private void handle(Socket socket){
        try(Socket s=socket){
            s.setSoTimeout(20000);
            BufferedReader r=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8));
            String first=r.readLine(); if(first==null)return;
            String[] p=first.split(" ",3); if(p.length<2){send(s,400,"bad request");return;}
            String method=p[0].toUpperCase(Locale.US); String target=p[1];
            java.util.HashMap<String,String> headers=new java.util.HashMap<>(); String line;
            while((line=r.readLine())!=null && !line.isEmpty()){
                int ix=line.indexOf(':'); if(ix>0)headers.put(line.substring(0,ix).trim().toLowerCase(Locale.US),line.substring(ix+1).trim());
            }
            int len=0; try{len=Integer.parseInt(headers.getOrDefault("content-length","0"));}catch(Exception ignored){}
            String body=""; if(len>0 && len<2_000_000){char[] b=new char[len];int n=0,got;while(n<len&&(got=r.read(b,n,len-n))>0)n+=got;body=new String(b,0,n);}
            if(!target.equals("/api/health") && !authorized(headers)) { send(s,401,"{\"error\":\"authorization required\"}",true); return; }
            String path=target.split("\\?",2)[0];
            if("GET".equals(method) && "/".equals(path)){send(s,200,html(),false);return;}
            if("GET".equals(method) && "/api/health".equals(path)){send(s,200,health(),true);return;}
            if("GET".equals(method) && "/api/info".equals(path)){send(s,200,infoJson(),true);return;}
            if("GET".equals(method) && "/api/dashboard".equals(path)){send(s,200,dashboard(),true);return;}
            if("GET".equals(method) && "/api/customers".equals(path)){send(s,200,db.customersJson(),true);return;}
            if("GET".equals(method) && "/api/tasks".equals(path)){send(s,200,db.tasksJson(),true);return;}
            if("GET".equals(method) && "/api/memory".equals(path)){send(s,200,db.memoryJson(""),true);return;}
            if("GET".equals(method) && "/api/activities".equals(path)){send(s,200,db.activitiesJson(System.currentTimeMillis()-7L*86400000L,System.currentTimeMillis(),100),true);return;}
            if("POST".equals(method) && "/api/chat".equals(path)){send(s,200,chat(body),true);return;}
            if("POST".equals(method) && "/api/customer".equals(path)){send(s,200,customer(body),true);return;}
            if("POST".equals(method) && "/api/task".equals(path)){send(s,200,task(body),true);return;}
            if("POST".equals(method) && "/api/memory".equals(path)){send(s,200,memory(body),true);return;}
            send(s,404,"{\"error\":\"not found\"}",true);
        }catch(Exception ignored){}
    }

    private boolean authorized(java.util.Map<String,String> h){
        String got=h.getOrDefault("authorization",""); return got.equals("Bearer "+token());
    }
    private String health(){try{return new JSONObject().put("ok",true).put("service","jarves-tablet-server").put("version","4.0.0").put("firebase",false).put("device","android-tablet").put("port",PORT).toString();}catch(Exception e){return "{\"ok\":true}";}}
    private String dashboard(){try{return new JSONObject().put("customers",db.customerCount()).put("tasks_open",db.taskCount()).put("memory",db.memoryCount()).put("server",true).put("server_info",new JSONObject(infoJson())).toString();}catch(Exception e){return "{}";}}

    private String customer(String body){try{JSONObject b=new JSONObject(body);long id=db.saveCustomer(b.optString("name"),b.optString("phone"),b.optString("email"),b.optString("notes"),b.optString("address"));return new JSONObject().put("ok",id>0).put("id",id).toString();}catch(Exception e){return error(e);}}
    private String task(String body){try{JSONObject b=new JSONObject(body);long due=b.optLong("due",0);long id=db.addTask(b.optString("title"),due);return new JSONObject().put("ok",id>0).put("id",id).toString();}catch(Exception e){return error(e);}}
    private String memory(String body){try{JSONObject b=new JSONObject(body);db.remember(b.optString("note"));return "{\"ok\":true}";}catch(Exception e){return error(e);}}

    private String chat(String body){
        try{
            JSONObject b=new JSONObject(body); String msg=b.optString("message","").trim(); if(msg.isEmpty())return "{\"error\":\"message fehlt\"}";
            CountDownLatch latch=new CountDownLatch(1); final String[] answer={"Jarves konnte die Anfrage nicht abschließen."}; final String[] status={"SERVER"};
            new AgentClient(context,false).ask(msg,(a,st)->{answer[0]=a;status[0]=st;latch.countDown();});
            if(!latch.await(45,java.util.concurrent.TimeUnit.SECONDS)) return "{\"error\":\"agent timeout\"}";
            return new JSONObject().put("answer",answer[0]).put("status",status[0]).put("server","tablet").toString();
        }catch(Exception e){return error(e);}
    }
    private String error(Exception e){try{return new JSONObject().put("error",e.getMessage()==null?"unknown":e.getMessage()).toString();}catch(Exception x){return "{\"error\":\"unknown\"}";}}

    private void send(Socket s,int code,String text){send(s,code,text,false);}
    private void send(Socket s,int code,String text,boolean json){try{byte[] b=text.getBytes(StandardCharsets.UTF_8);OutputStream o=s.getOutputStream();String ct=json?"application/json; charset=utf-8":"text/html; charset=utf-8";String h="HTTP/1.1 "+code+" "+(code==200?"OK":code==401?"Unauthorized":code==404?"Not Found":"Bad Request")+"\r\nContent-Type: "+ct+"\r\nContent-Length: "+b.length+"\r\nConnection: close\r\nAccess-Control-Allow-Origin: *\r\n\r\n";o.write(h.getBytes(StandardCharsets.UTF_8));o.write(b);o.flush();}catch(Exception ignored){}}

    private String html(){return "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width'><title>Jarves Tablet Server</title><style>body{background:#07111d;color:#dff7ff;font-family:system-ui;margin:0;padding:28px}main{max-width:850px;margin:auto;border:1px solid #1f5367;border-radius:22px;padding:24px;background:#0b1825}h1{letter-spacing:.12em}pre{white-space:pre-wrap;background:#061019;padding:16px;border-radius:14px}button{padding:12px 18px;border-radius:12px;border:1px solid #36a9d0;background:#0c2735;color:#dff7ff;margin-right:8px}</style></head><body><main><h1>JARVES • TABLET SERVER</h1><p>Dieses Samsung/Android-Tablet ist die Jarves-Zentrale.</p><button onclick='load()'>STATUS AKTUALISIEREN</button><pre id='o'>Lade…</pre></main><script>async function load(){let r=await fetch('/api/health');let h=await r.json();document.getElementById('o').textContent=JSON.stringify(h,null,2)+'\\n\\nDer geschützte API-Zugriff benötigt den Jarves-Token aus der App.'}load()</script></body></html>";}
}
