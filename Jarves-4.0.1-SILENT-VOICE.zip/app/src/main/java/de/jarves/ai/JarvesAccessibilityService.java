package de.jarves.ai;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.view.accessibility.AccessibilityEvent;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.List;
import java.util.Locale;

/** Optional, user-enabled Android control bridge for Jarves. */
public final class JarvesAccessibilityService extends AccessibilityService {
    private static volatile JarvesAccessibilityService instance;
    public static boolean isEnabled(){ return instance!=null; }
    public static String action(String action,String target){
        JarvesAccessibilityService s=instance;
        if(s==null)return "Android-Steuerung ist nicht aktiviert. Öffne Einstellungen > Bedienungshilfen > Jarves.";
        return s.doAction(action,target);
    }
    @Override protected void onServiceConnected(){
        super.onServiceConnected();
        instance=this;
        AccessibilityServiceInfo info=new AccessibilityServiceInfo();
        info.eventTypes=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED|AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED;
        info.feedbackType=AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.flags=AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS|AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        setServiceInfo(info);
    }
    @Override public void onAccessibilityEvent(android.view.accessibility.AccessibilityEvent event){}
    @Override public void onInterrupt(){}
    @Override public void onDestroy(){ if(instance==this)instance=null; super.onDestroy(); }

    private String doAction(String action,String target){
        String a=action==null?"":action.toLowerCase(Locale.GERMANY).trim();
        try{
            if(a.equals("back")||a.equals("zurück")||a.equals("zurueck"))return performGlobalAction(GLOBAL_ACTION_BACK)?"Zurück ausgeführt.":"Zurück konnte nicht ausgeführt werden.";
            if(a.equals("home")||a.equals("startseite"))return performGlobalAction(GLOBAL_ACTION_HOME)?"Startseite geöffnet.":"Startseite konnte nicht geöffnet werden.";
            if(a.equals("recents")||a.equals("apps")||a.equals("zuletzt"))return performGlobalAction(GLOBAL_ACTION_RECENTS)?"Zuletzt verwendete Apps geöffnet.":"App-Übersicht konnte nicht geöffnet werden.";
            if(a.equals("notifications")||a.equals("benachrichtigungen"))return performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)?"Benachrichtigungen geöffnet.":"Benachrichtigungen konnten nicht geöffnet werden.";
            if(a.equals("quick_settings")||a.equals("schnelleinstellungen"))return performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)?"Schnelleinstellungen geöffnet.":"Schnelleinstellungen konnten nicht geöffnet werden.";
            if(a.equals("lock")||a.equals("sperren"))return performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)?"Display gesperrt.":"Display konnte nicht gesperrt werden.";
            if(a.equals("power")||a.equals("power_dialog"))return performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)?"Power-Menü geöffnet.":"Power-Menü konnte nicht geöffnet werden.";
            if(a.equals("screenshot")||a.equals("bildschirmfoto"))return performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)?"Screenshot ausgelöst.":"Screenshot konnte nicht ausgelöst werden.";
            if(a.equals("click")||a.equals("klick")||a.equals("öffnen")||a.equals("oeffnen")){
                String q=target==null?"":target.trim();
                if(q.isEmpty())return "Kein Ziel für den Klick angegeben.";
                AccessibilityNodeInfo root=getRootInActiveWindow();
                AccessibilityNodeInfo n=findNode(root,q.toLowerCase(Locale.GERMANY));
                if(n!=null && n.isClickable() && n.performAction(AccessibilityNodeInfo.ACTION_CLICK))return "„"+q+"“ geklickt.";
                if(n!=null){
                    AccessibilityNodeInfo p=n;
                    while(p!=null){if(p.isClickable()&&p.performAction(AccessibilityNodeInfo.ACTION_CLICK))return "„"+q+"“ geklickt.";p=p.getParent();}
                }
                return "Kein klickbares Element „"+q+"“ gefunden.";
            }
            return "Unbekannte Android-Aktion: "+action;
        }catch(Exception e){return "Android-Aktion fehlgeschlagen: "+e.getMessage();}
    }
    private AccessibilityNodeInfo findNode(AccessibilityNodeInfo node,String q){
        if(node==null)return null;
        CharSequence t=node.getText(), d=node.getContentDescription();
        if((t!=null&&t.toString().toLowerCase(Locale.GERMANY).contains(q))||(d!=null&&d.toString().toLowerCase(Locale.GERMANY).contains(q)))return node;
        for(int i=0;i<node.getChildCount();i++){AccessibilityNodeInfo r=findNode(node.getChild(i),q);if(r!=null)return r;}
        return null;
    }
}
