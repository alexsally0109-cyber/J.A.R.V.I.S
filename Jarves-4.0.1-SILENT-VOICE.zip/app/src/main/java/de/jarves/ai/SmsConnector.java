package de.jarves.ai;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;

public final class SmsConnector {
    private final Context c; private final SecretStore s; private final JarvesDataStore db;
    public SmsConnector(Context c,SecretStore s,JarvesDataStore db){this.c=c;this.s=s;this.db=db;}
    public String send(String target,String message){
        if(!s.get("auto_sms","false").equals("true")) return "SMS NICHT GESENDET: automatische SMS ist in Einstellungen deaktiviert. Bitte aktivieren oder Nachricht als Entwurf verwenden.";
        if(c.checkSelfPermission(Manifest.permission.SEND_SMS)!=PackageManager.PERMISSION_GRANTED) return "SMS NICHT GESENDET: SEND_SMS-Berechtigung fehlt.";
        String to=target;
        if(!to.matches("[+0-9][+0-9 ()-]{5,}")) {
            String p=db.findCustomerPhone(target); if(p!=null)to=p;
        }
        if(to==null||to.trim().isEmpty())return "Keine Telefonnummer gefunden.";
        try{
            SmsManager sm=SmsManager.getDefault();
            sm.sendTextMessage(to.replaceAll("[ ()-]",""),null,message,null,null);
            return "SMS gesendet an "+to+".";
        }catch(Exception e){return "SMS fehlgeschlagen: "+e.getMessage();}
    }
}
