package de.jarves.ai;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONArray;
import org.json.JSONObject;

public final class JarvesDataStore extends SQLiteOpenHelper {
    private static final String DB = "jarves20.db";
    public JarvesDataStore(Context c) { super(c, DB, null, 5); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,email TEXT,notes TEXT,address TEXT,created INTEGER NOT NULL,cloud_key TEXT,updated INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE memory(id INTEGER PRIMARY KEY AUTOINCREMENT,created INTEGER NOT NULL,note TEXT NOT NULL)");
        db.execSQL("CREATE TABLE tasks(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,due INTEGER,done INTEGER DEFAULT 0,cloud_key TEXT,updated INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE activities(id INTEGER PRIMARY KEY AUTOINCREMENT,created INTEGER NOT NULL,category TEXT NOT NULL,title TEXT NOT NULL,body TEXT NOT NULL,source TEXT,spoken INTEGER DEFAULT 0,cloud_key TEXT,updated INTEGER NOT NULL DEFAULT 0)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldV,int newV) {
        if(oldV<2) db.execSQL("ALTER TABLE customers ADD COLUMN created INTEGER NOT NULL DEFAULT 0");
        if(oldV<3) db.execSQL("CREATE TABLE IF NOT EXISTS activities(id INTEGER PRIMARY KEY AUTOINCREMENT,created INTEGER NOT NULL,category TEXT NOT NULL,title TEXT NOT NULL,body TEXT NOT NULL,source TEXT,spoken INTEGER DEFAULT 0)");
        if(oldV<4) db.execSQL("ALTER TABLE customers ADD COLUMN address TEXT NOT NULL DEFAULT ''");
        if(oldV<5){ db.execSQL("ALTER TABLE customers ADD COLUMN cloud_key TEXT"); db.execSQL("ALTER TABLE customers ADD COLUMN updated INTEGER NOT NULL DEFAULT 0"); db.execSQL("ALTER TABLE tasks ADD COLUMN cloud_key TEXT"); db.execSQL("ALTER TABLE tasks ADD COLUMN updated INTEGER NOT NULL DEFAULT 0"); db.execSQL("ALTER TABLE activities ADD COLUMN cloud_key TEXT"); db.execSQL("ALTER TABLE activities ADD COLUMN updated INTEGER NOT NULL DEFAULT 0"); }
    }

    public long saveCustomer(String name,String phone,String email,String notes){ return saveCustomer(name,phone,email,notes,""); }

    public long saveCustomer(String name,String phone,String email,String notes,String address){
        ContentValues v=new ContentValues();
        v.put("name",name.trim()); v.put("phone",phone==null?"":phone.trim()); v.put("email",email==null?"":email.trim());
        v.put("notes",notes==null?"":notes.trim()); v.put("address",address==null?"":address.trim()); v.put("created",System.currentTimeMillis()); v.put("updated",System.currentTimeMillis());
        long id=getWritableDatabase().insert("customers",null,v);
        if(id>0) logActivity("kunde","Neuer Kunde",name+(notes==null||notes.trim().isEmpty()?"":" – "+notes),"kundendaten");
        return id;
    }

    public String searchCustomers(String q){
        String query=q==null?"":q.trim();
        Cursor c=getReadableDatabase().rawQuery(
                "SELECT id,name,phone,email,notes,address,created FROM customers WHERE name LIKE ? OR phone LIKE ? OR email LIKE ? OR notes LIKE ? ORDER BY id DESC LIMIT 20",
                new String[]{"%"+query+"%","%"+query+"%","%"+query+"%","%"+query+"%"});
        JSONArray a=new JSONArray();
        try{while(c.moveToNext()){
            JSONObject o=new JSONObject();
            o.put("id",c.getLong(0));o.put("name",c.getString(1));o.put("phone",c.getString(2));
            o.put("email",c.getString(3));o.put("notes",c.getString(4));o.put("address",c.getString(5));o.put("created",c.getLong(6));a.put(o);
        }}catch(Exception ignored){}finally{c.close();}
        return a.toString();
    }

    public String customersJson(){
        Cursor c=getReadableDatabase().rawQuery("SELECT id,name,phone,email,notes,address,created FROM customers ORDER BY name",null);
        JSONArray a=new JSONArray();
        try{while(c.moveToNext()){
            JSONObject o=new JSONObject();
            o.put("id",c.getLong(0)); o.put("name",c.getString(1)); o.put("phone",c.getString(2));
            o.put("email",c.getString(3)); o.put("notes",c.getString(4)); o.put("address",c.getString(5)); o.put("created",c.getLong(6)); a.put(o);
        }}catch(Exception ignored){} finally{c.close();}
        return a.toString();
    }


    public String findCustomerByEmail(String email){
        Cursor c=getReadableDatabase().rawQuery("SELECT id,name,phone,email,notes,address,created FROM customers WHERE lower(email)=lower(?) ORDER BY id DESC LIMIT 1",new String[]{email==null?"":email.trim()});
        try{ if(c.moveToFirst()){ JSONObject o=new JSONObject(); o.put("id",c.getLong(0));o.put("name",c.getString(1));o.put("phone",c.getString(2));o.put("email",c.getString(3));o.put("notes",c.getString(4));o.put("address",c.getString(5));o.put("created",c.getLong(6)); return o.toString(); } }catch(Exception ignored){} finally{c.close();} return "";
    }

    public String customerLocationsJson(){
        Cursor c=getReadableDatabase().rawQuery("SELECT id,name,address FROM customers WHERE address IS NOT NULL AND trim(address)<>'' ORDER BY name",null);
        JSONArray a=new JSONArray();
        try{while(c.moveToNext()){ JSONObject o=new JSONObject();o.put("id",c.getLong(0));o.put("name",c.getString(1));o.put("address",c.getString(2));a.put(o); }}catch(Exception ignored){}finally{c.close();}
        return a.toString();
    }

    public String findCustomerPhone(String name){
        Cursor c=getReadableDatabase().rawQuery("SELECT phone FROM customers WHERE lower(name)=lower(?) OR lower(name) LIKE lower(?) ORDER BY id DESC LIMIT 1",
                new String[]{name,"%"+name+"%"});
        String r=c.moveToFirst()?c.getString(0):null; c.close(); return r==null||r.trim().isEmpty()?null:r;
    }

    public void remember(String note){
        ContentValues v=new ContentValues(); v.put("created",System.currentTimeMillis()); v.put("note",note);
        getWritableDatabase().insert("memory",null,v);
        logActivity("memory","Neue Erinnerung",note,"jarves");
    }
    public String memoryJson(String q){
        Cursor c=getReadableDatabase().rawQuery("SELECT created,note FROM memory WHERE note LIKE ? ORDER BY created DESC LIMIT 20",new String[]{"%"+q+"%"});
        JSONArray a=new JSONArray();
        try{while(c.moveToNext()){JSONObject o=new JSONObject();o.put("created",c.getLong(0));o.put("note",c.getString(1));a.put(o);}}catch(Exception ignored){}finally{c.close();}
        return a.toString();
    }

    public long addTask(String title,long due){
        ContentValues v=new ContentValues();v.put("title",title);if(due>0)v.put("due",due);v.put("updated",System.currentTimeMillis());
        long id=getWritableDatabase().insert("tasks",null,v);
        if(id>0) logActivity("aufgabe","Neue Aufgabe",title,"jarves");
        return id;
    }
    public String tasksJson(){
        Cursor c=getReadableDatabase().rawQuery("SELECT id,title,due,done FROM tasks WHERE done=0 ORDER BY CASE WHEN due IS NULL THEN 1 ELSE 0 END,due",null);
        JSONArray a=new JSONArray();
        try{while(c.moveToNext()){JSONObject o=new JSONObject();o.put("id",c.getLong(0));o.put("title",c.getString(1));o.put("due",c.isNull(2)?JSONObject.NULL:c.getLong(2));o.put("done",c.getInt(3));a.put(o);}}catch(Exception ignored){}finally{c.close();}
        return a.toString();
    }
    public boolean completeTask(long id){
        ContentValues v=new ContentValues();v.put("done",1);return getWritableDatabase().update("tasks",v,"id=?",new String[]{String.valueOf(id)})>0;
    }

    public long logActivity(String category,String title,String body,String source){
        ContentValues v=new ContentValues();
        v.put("created",System.currentTimeMillis());
        v.put("category",category==null?"sonstiges":category.trim());
        v.put("title",title==null?"":title.trim());
        v.put("body",body==null?"":body.trim());
        v.put("source",source==null?"":source.trim());
        v.put("spoken",0); v.put("updated",System.currentTimeMillis());
        return getWritableDatabase().insert("activities",null,v);
    }

    public int activityCountSince(long since){
        Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM activities WHERE created>?",new String[]{String.valueOf(since)});
        c.moveToFirst(); int n=c.getInt(0); c.close(); return n;
    }

    public String activitiesJson(long since,long until,int limit){
        Cursor c=getReadableDatabase().rawQuery("SELECT id,created,category,title,body,source FROM activities WHERE created>? AND created<=? ORDER BY created ASC LIMIT ?",new String[]{String.valueOf(since),String.valueOf(until),String.valueOf(Math.max(1,limit))});
        JSONArray a=new JSONArray();
        try{while(c.moveToNext()){
            JSONObject o=new JSONObject(); o.put("id",c.getLong(0)); o.put("created",c.getLong(1)); o.put("category",c.getString(2)); o.put("title",c.getString(3)); o.put("body",c.getString(4)); o.put("source",c.getString(5)); a.put(o);
        }}catch(Exception ignored){}finally{c.close();}
        return a.toString();
    }

    public String buildDailyDigest(long since,long until){
        Cursor c=getReadableDatabase().rawQuery("SELECT category,title,body,created FROM activities WHERE created>? AND created<=? ORDER BY created ASC LIMIT 80",new String[]{String.valueOf(since),String.valueOf(until)});
        int messages=0,customers=0,orders=0,sales=0,tasks=0,other=0; StringBuilder details=new StringBuilder();
        try{while(c.moveToNext()){
            String cat=c.getString(0)==null?"sonstiges":c.getString(0).toLowerCase(java.util.Locale.GERMANY);
            String title=c.getString(1)==null?"":c.getString(1); String body=c.getString(2)==null?"":c.getString(2);
            if(cat.contains("nachricht")||cat.contains("message"))messages++; else if(cat.contains("kunde"))customers++; else if(cat.contains("auftrag")||cat.contains("order"))orders++; else if(cat.contains("verkauf")||cat.contains("sale"))sales++; else if(cat.contains("aufgabe")||cat.contains("task"))tasks++; else other++;
            if(details.length()<1700){ if(details.length()>0)details.append(". "); details.append(title); if(!body.isEmpty())details.append(": ").append(body.length()>150?body.substring(0,150)+"…":body); }
        }}catch(Exception ignored){}finally{c.close();}
        int total=messages+customers+orders+sales+tasks+other;
        if(total==0)return "Tagesabschluss: Heute gab es keine neuen gespeicherten Aktivitäten.";
        StringBuilder out=new StringBuilder("Tagesabschluss. Heute gab es ").append(total).append(" neue Aktivitäten.");
        if(messages>0)out.append(" ").append(messages).append(" Nachrichten.");
        if(customers>0)out.append(" ").append(customers).append(" neue Kundeneingänge.");
        if(orders>0)out.append(" ").append(orders).append(" Aufträge.");
        if(sales>0)out.append(" ").append(sales).append(" Verkäufe.");
        if(tasks>0)out.append(" ").append(tasks).append(" neue Aufgaben.");
        if(other>0)out.append(" ").append(other).append(" weitere Einträge.");
        if(details.length()>0)out.append(" Wichtigste Einträge: ").append(details).append(".");
        return out.toString();
    }

    public String buildNewActivityPrompt(long since,long until){
        Cursor c=getReadableDatabase().rawQuery("SELECT category,title,body FROM activities WHERE created>? AND created<=? ORDER BY created ASC LIMIT 20",new String[]{String.valueOf(since),String.valueOf(until)});
        int total=0; int messages=0,customers=0,orders=0,sales=0,tasks=0; StringBuilder detail=new StringBuilder();
        try{while(c.moveToNext()){
            total++; String cat=c.getString(0)==null?"":c.getString(0).toLowerCase(java.util.Locale.GERMANY); String title=c.getString(1)==null?"":c.getString(1); String body=c.getString(2)==null?"":c.getString(2);
            if(cat.contains("nachricht")||cat.contains("message"))messages++; else if(cat.contains("kunde"))customers++; else if(cat.contains("auftrag")||cat.contains("order"))orders++; else if(cat.contains("verkauf")||cat.contains("sale"))sales++; else if(cat.contains("aufgabe")||cat.contains("task"))tasks++;
            if(detail.length()<800){if(detail.length()>0)detail.append("; ");detail.append(title);if(!body.isEmpty())detail.append(" – ").append(body.length()>100?body.substring(0,100)+"…":body);}
        }}catch(Exception ignored){}finally{c.close();}
        if(total==0)return "";
        StringBuilder out=new StringBuilder("Jarves: Es gibt neue Aktivitäten. ");
        if(messages>0)out.append(messages).append(" neue Nachricht").append(messages==1?"":"en").append(". ");
        if(customers>0)out.append(customers).append(" neue Kundeneingänge. ");
        if(orders>0)out.append(orders).append(" neue Aufträge. ");
        if(sales>0)out.append(sales).append(" neue Verkäufe. ");
        if(tasks>0)out.append(tasks).append(" neue Aufgaben. ");
        out.append("Bist du da?");
        if(detail.length()>0)out.append(" Wichtig: ").append(detail).append(".");
        return out.toString();
    }


    public void mergeCloudCustomer(String cloudKey,String name,String phone,String email,String notes,String address,long updated){
        if(cloudKey==null||cloudKey.trim().isEmpty())return;
        android.database.sqlite.SQLiteDatabase d=getWritableDatabase();
        Cursor c=d.rawQuery("SELECT id,updated FROM customers WHERE cloud_key=? LIMIT 1",new String[]{cloudKey});
        try{
            ContentValues v=new ContentValues(); v.put("name",name==null?"":name);v.put("phone",phone==null?"":phone);v.put("email",email==null?"":email);v.put("notes",notes==null?"":notes);v.put("address",address==null?"":address);v.put("updated",updated);v.put("cloud_key",cloudKey);
            if(c.moveToFirst()){long localUpdated=c.getLong(1); if(updated>=localUpdated)d.update("customers",v,"id=?",new String[]{String.valueOf(c.getLong(0))});}
            else {v.put("created",updated>0?updated:System.currentTimeMillis());d.insert("customers",null,v);}
        }finally{c.close();}
    }
    public void mergeCloudTask(String cloudKey,String title,long due,boolean done,long updated){
        if(cloudKey==null||cloudKey.trim().isEmpty())return; android.database.sqlite.SQLiteDatabase d=getWritableDatabase(); Cursor c=d.rawQuery("SELECT id,updated FROM tasks WHERE cloud_key=? LIMIT 1",new String[]{cloudKey});
        try{ContentValues v=new ContentValues();v.put("title",title==null?"":title);if(due>0)v.put("due",due);else v.putNull("due");v.put("done",done?1:0);v.put("updated",updated);v.put("cloud_key",cloudKey);if(c.moveToFirst()){if(updated>=c.getLong(1))d.update("tasks",v,"id=?",new String[]{String.valueOf(c.getLong(0))});}else d.insert("tasks",null,v);}finally{c.close();}
    }
    public void mergeCloudActivity(String cloudKey,String category,String title,String body,String source,long created){
        if(cloudKey==null||cloudKey.trim().isEmpty())return; android.database.sqlite.SQLiteDatabase d=getWritableDatabase(); Cursor c=d.rawQuery("SELECT id FROM activities WHERE cloud_key=? LIMIT 1",new String[]{cloudKey});
        try{if(c.moveToFirst())return;ContentValues v=new ContentValues();v.put("created",created>0?created:System.currentTimeMillis());v.put("category",category==null?"sonstiges":category);v.put("title",title==null?"":title);v.put("body",body==null?"":body);v.put("source",source==null?"":source);v.put("spoken",0);v.put("cloud_key",cloudKey);v.put("updated",created>0?created:System.currentTimeMillis());d.insert("activities",null,v);}finally{c.close();}
    }

    public org.json.JSONArray customersForCloud(){
        Cursor c=getReadableDatabase().rawQuery("SELECT id,name,phone,email,notes,address,created,cloud_key,updated FROM customers",null);org.json.JSONArray a=new org.json.JSONArray();
        try{while(c.moveToNext()){org.json.JSONObject o=new org.json.JSONObject();o.put("localId",c.getLong(0));o.put("name",c.getString(1));o.put("phone",c.getString(2));o.put("email",c.getString(3));o.put("notes",c.getString(4));o.put("address",c.getString(5));o.put("created",c.getLong(6));o.put("cloudKey",c.getString(7)==null?"":c.getString(7));o.put("updated",c.getLong(8));a.put(o);}}catch(Exception ignored){}finally{c.close();}return a;
    }
    public org.json.JSONArray tasksForCloud(){
        Cursor c=getReadableDatabase().rawQuery("SELECT id,title,due,done,cloud_key,updated FROM tasks",null);org.json.JSONArray a=new org.json.JSONArray();
        try{while(c.moveToNext()){org.json.JSONObject o=new org.json.JSONObject();o.put("localId",c.getLong(0));o.put("title",c.getString(1));o.put("due",c.isNull(2)?0:c.getLong(2));o.put("done",c.getInt(3)==1);o.put("cloudKey",c.getString(4)==null?"":c.getString(4));o.put("updated",c.getLong(5));a.put(o);}}catch(Exception ignored){}finally{c.close();}return a;
    }
    public org.json.JSONArray activitiesForCloud(int limit){
        Cursor c=getReadableDatabase().rawQuery("SELECT id,created,category,title,body,source,cloud_key,updated FROM activities ORDER BY created DESC LIMIT ?",new String[]{String.valueOf(Math.max(1,limit))});org.json.JSONArray a=new org.json.JSONArray();
        try{while(c.moveToNext()){org.json.JSONObject o=new org.json.JSONObject();o.put("localId",c.getLong(0));o.put("created",c.getLong(1));o.put("category",c.getString(2));o.put("title",c.getString(3));o.put("body",c.getString(4));o.put("source",c.getString(5));o.put("cloudKey",c.getString(6)==null?"":c.getString(6));o.put("updated",c.getLong(7));a.put(o);}}catch(Exception ignored){}finally{c.close();}return a;
    }
    public void setCustomerCloudKey(long id,String key){ContentValues v=new ContentValues();v.put("cloud_key",key);v.put("updated",System.currentTimeMillis());getWritableDatabase().update("customers",v,"id=?",new String[]{String.valueOf(id)});}
    public void setTaskCloudKey(long id,String key){ContentValues v=new ContentValues();v.put("cloud_key",key);v.put("updated",System.currentTimeMillis());getWritableDatabase().update("tasks",v,"id=?",new String[]{String.valueOf(id)});}
    public void setActivityCloudKey(long id,String key){ContentValues v=new ContentValues();v.put("cloud_key",key);v.put("updated",System.currentTimeMillis());getWritableDatabase().update("activities",v,"id=?",new String[]{String.valueOf(id)});}

    public int customerCount(){return count("customers");}
    public int memoryCount(){return count("memory");}
    public int taskCount(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM tasks WHERE done=0",null);c.moveToFirst();int n=c.getInt(0);c.close();return n;}
    private int count(String t){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+t,null);c.moveToFirst();int n=c.getInt(0);c.close();return n;}
}
