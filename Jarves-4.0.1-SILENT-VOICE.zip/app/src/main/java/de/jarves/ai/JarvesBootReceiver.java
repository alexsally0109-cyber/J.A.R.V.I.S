package de.jarves.ai;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public final class JarvesBootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()) || "android.intent.action.MY_PACKAGE_REPLACED".equals(intent.getAction())) {
            ActivityScheduler.configure(context);
            Intent server=new Intent(context,JarvesLocalServerService.class);
            try { if(android.os.Build.VERSION.SDK_INT>=26) context.startForegroundService(server); else context.startService(server); } catch(Exception ignored) {}
        }
    }
}
