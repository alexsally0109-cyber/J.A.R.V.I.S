package de.jarves.ai;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.util.AttributeSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Jarves HUD interaction/animation layer.
 *
 * The original artwork is 1586x992. Touch geometry follows that artwork exactly.
 * The lower-left information area and lower-right quick access area are covered
 * with clean, native-looking Jarves glass panels so the baked demo labels do not
 * remain visible underneath.
 */
public final class HudTouchView extends View {
    public interface Listener { void onHudAction(String action); }
    private static final float IW=1586f, IH=992f;
    private Listener listener;
    private String status="JARVES • ONLINE";
    private String answer="Bereit. Sag: „Jarves …“";
    private String customerLine="Noch keine Kunden gespeichert.";
    private String messageLine="Keine neue Kundennachricht erkannt.";
    private int customerCount=0, taskCount=0, memoryCount=0;
    private String pressedAction=null;
    private long pressedAt=0L;
    private long animationStart=System.currentTimeMillis();
    private String phase="READY";

    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glass=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring=new Paint(Paint.ANTI_ALIAS_FLAG);

    public HudTouchView(Context c){super(c);init();}
    public HudTouchView(Context c, AttributeSet a){super(c,a);init();}
    public HudTouchView(Context c, AttributeSet a, int style){super(c,a,style);init();}
    private void init(){
        setBackgroundColor(Color.TRANSPARENT);
        setClickable(true); setFocusable(true);
        glow.setStyle(Paint.Style.STROKE);
        stroke.setStyle(Paint.Style.STROKE);
        ring.setStyle(Paint.Style.STROKE);
    }
    public void setListener(Listener l){listener=l;}
    public void setStatus(String s){
        status=s==null?"":s;
        String u=status.toUpperCase(Locale.GERMANY);
        if(u.contains("DENKEN")||u.contains("ARBEITET")||u.contains("AUSWERTUNG")||u.contains("VERARBEITUNG")) phase="THINKING";
        else if(u.contains("SPRICH")||u.contains("AUSGABE")||u.contains("ANTWORT")||u.contains("SPRECH")) phase="SPEAKING";
        else if(u.contains("HÖREN")||u.contains("AKTIVIERT")||u.contains("AKTIV")) phase="LISTENING";
        else if(u.contains("FEHLER")||u.contains("FEHLT")) phase="ERROR";
        else phase="READY";
        animationStart=System.currentTimeMillis();
        invalidate();
    }
    public void setAnswer(String s){answer=s==null?"":s;invalidate();}
    public void setDashboardData(String customers,String messages,int customersCount,int tasks,int memory){
        customerLine=customers==null?"":customers;
        messageLine=messages==null?"":messages;
        customerCount=customersCount; taskCount=tasks; memoryCount=memory;
        invalidate();
    }
    private float sx(){return getWidth()/IW;}
    private float sy(){return getHeight()/IH;}
    private Path poly(float... pts){
        Path q=new Path(); if(pts.length<4)return q;
        q.moveTo(pts[0]*sx(),pts[1]*sy());
        for(int i=2;i+1<pts.length;i+=2)q.lineTo(pts[i]*sx(),pts[i+1]*sy());
        q.close(); return q;
    }
    private RectF rect(float l,float t,float r,float b){return new RectF(l*sx(),t*sy(),r*sx(),b*sy());}
    private boolean inCircle(float x,float y,float cx,float cy,float rr){float dx=x-cx,dy=y-cy;return dx*dx+dy*dy<=rr*rr;}
    private boolean inPath(float x,float y,Path q){
        float[] a=q.approximate(0.5f); if(a==null||a.length<6)return false;
        float px=x*sx(),py=y*sy(); boolean inside=false;
        float firstX=a[1],firstY=a[2],x0=firstX,y0=firstY;
        for(int i=4;i+2<a.length;i+=3){
            float x1=a[i+1],y1=a[i+2];
            if(((y0>py)!=(y1>py)) && px<(x1-x0)*(py-y0)/(y1-y0+0.00001f)+x0)inside=!inside;
            x0=x1;y0=y1;
        }
        if(((y0>py)!=(firstY>py)) && px<(firstX-x0)*(py-y0)/(firstY-y0+0.00001f)+x0)inside=!inside;
        return inside;
    }

    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        float w=getWidth(),h=getHeight();
        long now=System.currentTimeMillis();
        float t=(now-animationStart)/1000f;

        drawStatusPill(c,w,h);
        drawCoreActivity(c,t);
        drawDynamicClock(c,w,h);
        drawCustomerPanels(c,w,h);
        drawCalendarOverlay(c,w,h);
        drawOverview(c,w,h);
        drawBottomAnswer(c,w,h);
        drawPressed(c,now);

        postInvalidateDelayed(("READY".equals(phase)||"ERROR".equals(phase))?1000:32);
    }

    private void drawStatusPill(Canvas c,float w,float h){
        glass.setStyle(Paint.Style.FILL); glass.setColor(Color.argb(132,3,14,26));
        c.drawRoundRect(rect(584,39,1005,125),22*sx(),22*sy(),glass);
        stroke.setStrokeWidth(Math.max(1.2f,1.5f*sx())); stroke.setColor(Color.argb(115,98,230,255));
        c.drawRoundRect(rect(584,39,1005,125),22*sx(),22*sy(),stroke);
        p.setTypeface(Typeface.create("sans",Typeface.BOLD));p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(Math.max(12,w*.010f));p.setColor(Color.rgb(120,232,255));
        c.drawText(status.length()>44?status.substring(0,44)+"…":status,w*.50f,h*.062f,p);
    }

    /** Draws the animated veil strictly around the Core, never across its face. */
    private void drawCoreActivity(Canvas c,float t){
        float cx=793*sx(),cy=421*sy();
        float base=187*sx();
        float speed="SPEAKING".equals(phase)?130f:("THINKING".equals(phase)?44f:24f);
        float pulse=(float)(0.5+0.5*Math.sin(t*("SPEAKING".equals(phase)?8.5:3.4)));

        c.save();
        // Three concentric orbital bands. No fill is drawn inside the Core.
        for(int i=0;i<3;i++){
            float r=base+(i*9+5*pulse)*sx();
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(Math.max(2.2f,(3.0f-i*0.45f)*sx()));
            ring.setShader(new SweepGradient(cx,cy,new int[]{
                    Color.argb(0,80,225,255),Color.argb(150,80,225,255),
                    Color.argb(210,255,170,70),Color.argb(0,80,225,255)},null));
            c.rotate((t*speed*(i==1?0.72f:1f)+i*95f)%360f,cx,cy);
            RectF rr=new RectF(cx-r,cy-r,cx+r,cy+r);
            c.drawArc(rr,18f,92f,false,ring);
            c.drawArc(rr,158f,64f,false,ring);
            c.drawArc(rr,286f,48f,false,ring);
            ring.setShader(null);
        }
        // Soft orbital "veil" made of short dashes, still outside the Core.
        int dashCount=24;
        for(int i=0;i<dashCount;i++){
            double a=(Math.PI*2*i/dashCount)+(t*speed/180.0);
            float inner=(201+4*pulse)*sx(), outer=(207+16*(float)(0.5+0.5*Math.sin(t*6+i)))*sx();
            float x1=cx+(float)Math.cos(a)*inner, y1=cy+(float)Math.sin(a)*inner;
            float x2=cx+(float)Math.cos(a)*outer, y2=cy+(float)Math.sin(a)*outer;
            ring.setShader(null);
            ring.setStrokeWidth(Math.max(1.8f,2.5f*sx()));
            ring.setColor(Color.argb((int)(65+120*pulse),100,235,255));
            c.drawLine(x1,y1,x2,y2,ring);
        }
        c.restore();
    }

    private void drawDynamicClock(Canvas c,float w,float h){
        p.setTypeface(Typeface.create("sans",Typeface.BOLD));p.setTextAlign(Paint.Align.LEFT);
        p.setTextSize(Math.max(28,w*.028f));p.setColor(Color.WHITE);
        c.drawText(new SimpleDateFormat("HH:mm",Locale.GERMANY).format(new Date()),w*.785f,h*.252f,p);
        p.setTextSize(Math.max(11,w*.010f));p.setColor(Color.rgb(190,225,240));
        c.drawText(new SimpleDateFormat("EEEE, dd.MM.yyyy",Locale.GERMANY).format(new Date()),w*.785f,h*.300f,p);
    }

    private void panel(Canvas c,float l,float t,float r,float b){
        glass.setStyle(Paint.Style.FILL);glass.setColor(Color.argb(232,2,13,24));
        c.drawRoundRect(rect(l,t,r,b),18*sx(),18*sy(),glass);
        stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeWidth(Math.max(1.2f,1.5f*sx()));
        stroke.setColor(Color.argb(150,73,211,246));c.drawRoundRect(rect(l,t,r,b),18*sx(),18*sy(),stroke);
    }

    private void title(Canvas c,String text,float x,float y,float size){
        p.setTypeface(Typeface.create("sans",Typeface.BOLD));p.setTextAlign(Paint.Align.LEFT);
        p.setTextSize(Math.max(size,getWidth()*.009f));p.setColor(Color.rgb(156,235,255));c.drawText(text,x*sx(),y*sy(),p);
    }

    private void body(Canvas c,String text,float x,float y,float size){
        p.setTypeface(Typeface.create("sans",Typeface.NORMAL));p.setTextAlign(Paint.Align.LEFT);
        p.setTextSize(Math.max(size,getWidth()*.0078f));p.setColor(Color.rgb(224,242,249));c.drawText(text,x*sx(),y*sy(),p);
    }

    private void drawCustomerPanels(Canvas c,float w,float h){
        // Covers the baked WEATHER and NEWS demo blocks with real customer content.
        panel(c,30,438,475,628);
        title(c,"KUNDENDATEN",54,474,18);
        body(c,customerLine,54,510,14);
        body(c,customerCount+" Kunden  •  antippen zum Öffnen",54,542,13);
        pill(c,54,562,218,604,"KUNDEN","customer_data");
        pill(c,230,562,451,604,"NEUER KUNDE","customer_data");

        panel(c,30,640,475,910);
        title(c,"KUNDENNACHRICHTEN",54,676,18);
        String msg=messageLine;
        if(msg.length()>52) msg=msg.substring(0,52)+"…";
        body(c,msg,54,718,14);
        body(c,"Letzte erkannte Nachricht aus SMS / WhatsApp-Benachrichtigungen",54,748,11);
        pill(c,54,780,250,824,"NACHRICHTEN","customer_messages");
        pill(c,262,780,451,824,"MESSAGING","messages");
        body(c,"Kundenbezogene Nachrichten werden hier gesammelt.",54,866,12);
    }

    private void drawCalendarOverlay(Canvas c,float w,float h){
        // Replace the baked calendar heading with a clearer interactive title.
        panel(c,1090,353,1490,595);
        title(c,"TERMINE HEUTE",1116,390,18);
        body(c,"Jeder Eintrag ist separat anklickbar.",1116,415,11);
        String[] rows={"08:00   Frühstück","12:00   Projektbesprechung","18:00   Sport","20:00   Freizeit"};
        String[] ids={"calendar_1","calendar_2","calendar_3","calendar_4"};
        for(int i=0;i<4;i++){
            float top=425+i*40;
            pill(c,1110,top,1470,top+34,rows[i],ids[i]);
        }
    }

    private void drawOverview(Canvas c,float w,float h){
        panel(c,1090,606,1490,901);
        title(c,"ÜBERSICHT",1116,641,18);
        body(c,"Termine, Aufgaben und Kundensachen – direkt erreichbar.",1116,664,11);
        pill(c,1110,681,1289,729,"TERMINE","overview_calendar");
        pill(c,1297,681,1470,729,"AUFGABEN","overview_tasks");
        pill(c,1110,739,1289,787,"KUNDEN","overview_customers");
        pill(c,1297,739,1470,787,"NACHRICHTEN","overview_messages");
        pill(c,1110,797,1289,845,"ERINNERUNGEN","overview_reminders");
        pill(c,1297,797,1470,845,"MEMORY","overview_memory");
        body(c,taskCount+" offene Aufgaben  •  "+memoryCount+" gespeicherte Erinnerungen",1116,875,11);
    }

    private void pill(Canvas c,float l,float t,float r,float b,String text,String action){
        boolean active=action.equals(pressedAction);
        glass.setStyle(Paint.Style.FILL);
        glass.setColor(active?Color.argb(165,20,74,92):Color.argb(116,4,23,37));
        c.drawRoundRect(rect(l,t,r,b),13*sx(),13*sy(),glass);
        stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeWidth(Math.max(1f,1.3f*sx()));
        stroke.setColor(active?Color.argb(230,125,239,255):Color.argb(105,79,207,235));
        c.drawRoundRect(rect(l,t,r,b),13*sx(),13*sy(),stroke);
        p.setTypeface(Typeface.create("sans",Typeface.BOLD));p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(Math.max(10,getWidth()*.0078f));p.setColor(Color.rgb(224,247,255));
        c.drawText(text,(l+r)*0.5f*sx(),(t+b)*0.5f*sy()+4*sy(),p);
    }

    private void drawBottomAnswer(Canvas c,float w,float h){
        panel(c,493,848,1060,925);
        p.setTypeface(Typeface.create("sans",Typeface.NORMAL));p.setTextAlign(Paint.Align.LEFT);
        p.setTextSize(Math.max(12,w*.0102f));p.setColor(Color.rgb(235,248,255));
        String a=answer.length()>96?answer.substring(0,96)+"…":answer;
        c.drawText(a,522*sx(),895*sy(),p);
    }

    private void drawPressed(Canvas c,long now){
        if(pressedAction==null)return;
        Path q=actionPath(pressedAction);
        if(q==null&&"core".equals(pressedAction)){q=new Path();q.addCircle(793*sx(),421*sy(),184*sx(),Path.Direction.CW);}
        if(q!=null){
            float age=Math.min(1f,(now-pressedAt)/220f);
            Paint fill=new Paint(Paint.ANTI_ALIAS_FLAG);fill.setStyle(Paint.Style.FILL);
            fill.setColor(Color.argb((int)(28+(1f-age)*96f),80,225,255));c.drawPath(q,fill);
            glow.setStrokeWidth(Math.max(2.5f,getWidth()*.0022f));glow.setColor(Color.argb((int)(220-age*90),90,235,255));c.drawPath(q,glow);
            if(age<1f)postInvalidateDelayed(16);
        }
    }

    private Path actionPath(String a){
        switch(a){
            case "search": return poly(455,235,572,196,646,244,617,300,454,283);
            case "messages": return poly(454,283,617,300,607,399,449,382);
            case "weather": return poly(449,382,607,399,604,489,444,474);
            case "music": return poly(444,474,604,489,611,576,449,550);
            case "apps": return poly(449,550,611,576,660,639,607,691,495,684);
            case "calendar": return poly(1010,197,1125,230,1127,304,1168,334,1013,301);
            case "notes": return poly(1013,301,1168,334,1157,422,1010,398);
            case "smarthome": return poly(1010,398,1157,422,1151,506,1005,491);
            case "youtube": return poly(1005,491,1151,506,1144,594,998,575);
            case "settings": return poly(998,575,1144,594,1108,664,1016,693,956,648);
            case "voice_panel": return rectPath(585,40,1004,125);
            case "wifi": return rectPath(1164,43,1220,99);
            case "bluetooth": return rectPath(1228,43,1284,99);
            case "assistant_status": return rectPath(1292,43,1348,99);
            case "top_settings": return rectPath(1352,43,1407,99);
            case "battery": return rectPath(1412,42,1530,101);
            case "system": return rectPath(30,125,447,425);
            case "system_jarves": return rectPath(45,177,432,227);
            case "system_mic": return rectPath(45,228,432,277);
            case "system_internet": return rectPath(45,278,432,326);
            case "system_ai": return rectPath(45,327,432,375);
            case "system_storage": return rectPath(45,376,432,420);
            case "customer_data": return rectPath(30,438,475,628);
            case "customer_messages": return rectPath(30,640,475,910);
            case "clock": return rectPath(1090,125,1538,340);
            case "right_calendar": return rectPath(1090,353,1490,595);
            case "calendar_1": return rectPath(1110,425,1470,459);
            case "calendar_2": return rectPath(1110,465,1470,499);
            case "calendar_3": return rectPath(1110,505,1470,539);
            case "calendar_4": return rectPath(1110,545,1470,579);
            case "quick": return rectPath(1090,606,1490,901);
            case "overview_calendar": return rectPath(1110,681,1289,729);
            case "overview_tasks": return rectPath(1297,681,1470,729);
            case "overview_customers": return rectPath(1110,739,1289,787);
            case "overview_messages": return rectPath(1297,739,1470,787);
            case "overview_reminders": return rectPath(1110,797,1289,845);
            case "overview_memory": return rectPath(1297,797,1470,845);
            case "mic": {Path q=new Path();q.addCircle(801*sx(),775*sy(),69*sx(),Path.Direction.CW);return q;}
            case "answer": return rectPath(493,848,1060,925);
            case "daily_today": return rectPath(520,936,651,982);
            case "daily_tasks": return rectPath(661,936,793,982);
            case "daily_customers": return rectPath(803,936,934,982);
            case "daily_memory": return rectPath(944,936,1065,982);
            default:return null;
        }
    }
    private Path rectPath(float l,float t,float r,float b){return poly(l,t,r,t,r,b);}

    private String hit(float x,float y){
        // Core and microphone take priority because they are circular targets.
        if(inCircle(x,y,793,421,184))return "core";
        if(inCircle(x,y,801,775,69))return "mic";
        String[] specific={
            "search","messages","weather","music","apps","calendar","notes","smarthome","youtube","settings",
            "wifi","bluetooth","assistant_status","top_settings","battery","voice_panel",
            "system_jarves","system_mic","system_internet","system_ai","system_storage",
            "customer_data","customer_messages","clock","calendar_1","calendar_2","calendar_3","calendar_4",
            "overview_calendar","overview_tasks","overview_customers","overview_messages","overview_reminders","overview_memory",
            "answer","daily_today","daily_tasks","daily_customers","daily_memory"
        };
        for(String s:specific){Path q=actionPath(s);if(q!=null&&inPath(x,y,q))return s;}
        String[] cards={"system","right_calendar","quick"};
        for(String s:cards){Path q=actionPath(s);if(q!=null&&inPath(x,y,q))return s;}
        return null;
    }
    @Override public boolean onTouchEvent(MotionEvent e){
        float x=e.getX()/Math.max(1f,sx()),y=e.getY()/Math.max(1f,sy());
        if(e.getAction()==MotionEvent.ACTION_DOWN){pressedAction=hit(x,y);pressedAt=System.currentTimeMillis();invalidate();return true;}
        if(e.getAction()==MotionEvent.ACTION_CANCEL){pressedAction=null;invalidate();return true;}
        if(e.getAction()==MotionEvent.ACTION_UP){String a=hit(x,y),down=pressedAction;pressedAction=null;invalidate();if(a!=null&&a.equals(down)&&listener!=null){performClick();listener.onHudAction(a);}return true;}
        return true;
    }
    @Override public boolean performClick(){super.performClick();return true;}
}
