package de.jarves.ai;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import java.util.Calendar;

/**
 * Schedules Jarves' everyday activity check and end-of-day briefing.
 * The monitor is local: it only reacts to activities Jarves has already
 * collected on the tablet. It never polls the internet by itself.
 */
public final class ActivityScheduler {
    public static final String ACTION_CHECK = "de.jarves.ai.ACTIVITY_CHECK";
    public static final String ACTION_DAILY = "de.jarves.ai.DAILY_DIGEST";
    private static final int REQ_CHECK = 73001;
    private static final int REQ_DAILY = 73002;
    private static final String PREFS = "jarves_activity";

    private ActivityScheduler() {}

    public static void ensureDefaults(Context context) {
        android.content.SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (!p.contains("monitor_enabled")) p.edit().putBoolean("monitor_enabled", true).apply();
        if (!p.contains("interval_minutes")) p.edit().putInt("interval_minutes", 30).apply();
        if (!p.contains("daily_enabled")) p.edit().putBoolean("daily_enabled", true).apply();
        if (!p.contains("digest_hour")) p.edit().putInt("digest_hour", 18).apply();
        if (!p.contains("digest_minute")) p.edit().putInt("digest_minute", 0).apply();
        if (!p.contains("last_check")) p.edit().putLong("last_check", System.currentTimeMillis()).apply();
    }

    public static void configure(Context context) {
        ensureDefaults(context);
        android.content.SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        cancel(context);
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        if (p.getBoolean("monitor_enabled", true)) scheduleCheck(context, am, Math.max(30, Math.min(60, p.getInt("interval_minutes", 30))));
        if (p.getBoolean("daily_enabled", true)) scheduleDaily(context, am, p.getInt("digest_hour", 18), p.getInt("digest_minute", 0));
    }

    private static void scheduleCheck(Context c, AlarmManager am, int minutes) {
        long when = System.currentTimeMillis() + minutes * 60_000L;
        Intent i = new Intent(c, JarvesAlarmReceiver.class).setAction(ACTION_CHECK);
        PendingIntent pi = PendingIntent.getBroadcast(c, REQ_CHECK, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        try {
            if (android.os.Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        } catch (Exception ignored) {}
    }

    private static void scheduleDaily(Context c, AlarmManager am, int hour, int minute) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, Math.max(0, Math.min(23, hour)));
        cal.set(Calendar.MINUTE, Math.max(0, Math.min(59, minute)));
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0);
        if (cal.getTimeInMillis() <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1);
        Intent i = new Intent(c, JarvesAlarmReceiver.class).setAction(ACTION_DAILY);
        PendingIntent pi = PendingIntent.getBroadcast(c, REQ_DAILY, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        try {
            if (android.os.Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
        } catch (Exception ignored) {}
    }

    public static void cancel(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        for (int req : new int[]{REQ_CHECK, REQ_DAILY}) {
            Intent i = new Intent(c, JarvesAlarmReceiver.class);
            i.setAction(req == REQ_CHECK ? ACTION_CHECK : ACTION_DAILY);
            PendingIntent pi = PendingIntent.getBroadcast(c, req, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            try { am.cancel(pi); } catch (Exception ignored) {}
        }
    }
}
