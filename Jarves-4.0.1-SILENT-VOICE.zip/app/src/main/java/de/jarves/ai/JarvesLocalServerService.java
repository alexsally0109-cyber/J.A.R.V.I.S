package de.jarves.ai;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

/** Keeps the Jarves LAN server alive without a PC. */
public final class JarvesLocalServerService extends Service {
    private JarvesLocalServer server;
    private static final String CHANNEL="jarves_server";
    @Override public void onCreate(){
        super.onCreate(); server=new JarvesLocalServer(this); createChannel();
        Notification n=new Notification.Builder(this,CHANNEL).setContentTitle("Jarves Server aktiv").setContentText("Das Tablet ist die Jarves-Zentrale im lokalen Netzwerk.").setSmallIcon(android.R.drawable.stat_sys_upload).setOngoing(true).build();
        if(Build.VERSION.SDK_INT>=29) startForeground(22,n,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC); else startForeground(22,n);
        server.start();
    }
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationManager n=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(n!=null)n.createNotificationChannel(new NotificationChannel(CHANNEL,"Jarves Server",NotificationManager.IMPORTANCE_LOW));}}
    @Override public int onStartCommand(Intent i,int flags,int id){if(server==null){server=new JarvesLocalServer(this);server.start();}return START_STICKY;}
    @Override public void onDestroy(){if(server!=null)server.stop();super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
