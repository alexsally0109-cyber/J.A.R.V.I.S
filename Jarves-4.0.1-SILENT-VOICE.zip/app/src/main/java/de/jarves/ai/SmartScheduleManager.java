package de.jarves.ai;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

/** Proposes customer visits by checking calendar gaps and clustering by geographic proximity. */
public final class SmartScheduleManager {
    private final Context context;
    private final CalendarManager calendar;
    private final JarvesDataStore db;
    public SmartScheduleManager(Context c){context=c.getApplicationContext();calendar=new CalendarManager(context);db=new JarvesDataStore(context);}

    public String propose(String customer,String address,int durationMin){
        int duration=Math.max(30,Math.min(durationMin,240));
        Geo target=geo(address); if(target==null)return "Adresse konnte nicht geografisch geprüft werden. Bitte eine vollständige Kundenadresse angeben.";
        JSONArray events=calendar.eventsDetailed(14);
        List<Candidate> candidates=new ArrayList<>();
        Calendar day=Calendar.getInstance(); day.set(Calendar.HOUR_OF_DAY,8);day.set(Calendar.MINUTE,0);day.set(Calendar.SECOND,0);day.set(Calendar.MILLISECOND,0);
        for(int d=0;d<14;d++){
            int dow=day.get(Calendar.DAY_OF_WEEK); if(dow!=Calendar.SATURDAY && dow!=Calendar.SUNDAY){
                for(int h=8;h<=16;h++){
                    Calendar st=(Calendar)day.clone(); st.set(Calendar.HOUR_OF_DAY,h); st.set(Calendar.MINUTE,0);
                    Calendar en=(Calendar)st.clone(); en.add(Calendar.MINUTE,duration);
                    if(st.getTimeInMillis()<=System.currentTimeMillis()) continue;
                    if(free(events,st.getTimeInMillis(),en.getTimeInMillis()) && travelOkay(events,st.getTimeInMillis(),en.getTimeInMillis(),target)){
                        double score=clusterScore(events,st.getTimeInMillis(),target); candidates.add(new Candidate(st.getTimeInMillis(),en.getTimeInMillis(),score));
                    }
                }
            }
            day.add(Calendar.DAY_OF_YEAR,1);
        }
        candidates.sort(Comparator.comparingDouble(c->c.score));
        if(candidates.isEmpty())return "Ich finde in den nächsten 14 Tagen keinen ausreichend freien Kundentermin. Ich habe bestehende Kalendertermine und die Kundenumgebung berücksichtigt.";
        Candidate best=candidates.get(0);
        context.getSharedPreferences("jarves_planning",Context.MODE_PRIVATE).edit().putString("pending_customer",customer).putString("pending_address",address).putLong("pending_start",best.start).putLong("pending_end",best.end).apply();
        String when=new java.text.SimpleDateFormat("EEEE, dd.MM. 'um' HH:mm 'Uhr'",Locale.GERMANY).format(new Date(best.start));
        return "Vorschlag für "+customer+": "+when+". Die Zeit liegt in einem freien Kalenderfenster und ist geografisch möglichst günstig zu bestehenden Terminen. Noch nichts wurde in den Kalender geschrieben. Wenn du bestätigst, trage ich den Termin ein.";
    }

    public String confirm(String title,String location,String description){
        android.content.SharedPreferences p=context.getSharedPreferences("jarves_planning",Context.MODE_PRIVATE);
        long start=p.getLong("pending_start",0),end=p.getLong("pending_end",0); String customer=p.getString("pending_customer",""); String address=p.getString("pending_address",location==null?"":location);
        if(start<=0||end<=start)return "Es gibt keinen offenen Terminvorschlag.";
        String t=title==null||title.trim().isEmpty()?"Kundentermin • "+customer:title;
        String result=calendar.create(t,start,end,address,description==null?"":description);
        if(result.startsWith("Termin erstellt"))p.edit().clear().apply();
        return result;
    }

    private boolean free(JSONArray events,long s,long e){try{for(int i=0;i<events.length();i++){JSONObject o=events.getJSONObject(i);long a=o.optLong("start"),b=o.optLong("end");if(s<b+15*60000L && e>a-15*60000L)return false;}}catch(Exception ignored){}return true;}
    private boolean travelOkay(JSONArray events,long s,long e,Geo target){try{for(int i=0;i<events.length();i++){JSONObject o=events.getJSONObject(i);long a=o.optLong("start"),b=o.optLong("end");String loc=o.optString("location","");if(loc.isEmpty())continue;Geo g=geo(loc);if(g==null)continue; if(Math.abs(b-s)<4*3600000L||Math.abs(a-e)<4*3600000L){double km=dist(target,g);if(km>45)return false;}}}catch(Exception ignored){}return true;}
    private double clusterScore(JSONArray events,long s,Geo target){double score=0;try{for(int i=0;i<events.length();i++){JSONObject o=events.getJSONObject(i);long a=o.optLong("start"),b=o.optLong("end");String loc=o.optString("location","");if(loc.isEmpty())continue;if(Math.abs(b-s)<6*3600000L||Math.abs(a-s)<6*3600000L){Geo g=geo(loc);if(g!=null)score+=dist(target,g);}}}catch(Exception ignored){}return score;}
    private Geo geo(String text){if(text==null||text.trim().isEmpty())return null;try{Geocoder geocoder=new Geocoder(context,Locale.GERMANY);List<Address> a=geocoder.getFromLocationName(text,1);if(a!=null&&!a.isEmpty())return new Geo(a.get(0).getLatitude(),a.get(0).getLongitude());}catch(Exception ignored){}return null;}
    private double dist(Geo a,Geo b){double R=6371.0,dLat=Math.toRadians(b.lat-a.lat),dLon=Math.toRadians(b.lon-a.lon);double x=Math.sin(dLat/2)*Math.sin(dLat/2)+Math.cos(Math.toRadians(a.lat))*Math.cos(Math.toRadians(b.lat))*Math.sin(dLon/2)*Math.sin(dLon/2);return 2*R*Math.asin(Math.sqrt(x));}
    private static final class Geo{final double lat,lon;Geo(double a,double b){lat=a;lon=b;}}
    private static final class Candidate{final long start,end;final double score;Candidate(long s,long e,double sc){start=s;end=e;score=sc;}}
}
