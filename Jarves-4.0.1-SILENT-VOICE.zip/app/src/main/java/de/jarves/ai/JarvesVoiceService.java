package de.jarves.ai;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import java.io.File;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import androidx.core.app.NotificationCompat;
import com.openwakeword.OpenWakeWord;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.lang.ref.WeakReference;

/**
 * Jarves voice engine.
 *
 * State machine:
 *   IDLE -> LISTENING -> THINKING -> SPEAKING -> LISTENING
 *
 * The recognizer is NEVER allowed to compete with TTS. Before Jarves answers,
 * the active recognizer is cancelled and the audio focus is handed to TTS.
 * Listening is restarted only after TTS reports onDone/onError.
 */
public final class JarvesVoiceService extends Service implements TextToSpeech.OnInitListener {
    private static WeakReference<JarvesVoiceService> INSTANCE=new WeakReference<>(null);
    public static final String ACTION_UPDATE="de.jarves.ai.UPDATE";

    private SpeechRecognizer recognizer;
    private OpenWakeWord wakeDetector;
    private boolean wakeDetectorStarting=false;
    private boolean directListen=false;
    private TextToSpeech tts;
    private AgentClient agent;
    private WorkspaceManager workspace;
    private AudioManager audioManager;
    private AudioFocusRequest ttsFocusRequest;
    private AudioFocusRequest recognitionFocusRequest;
    private final Handler h=new Handler(Looper.getMainLooper());

    private boolean running=false;
    private boolean speaking=false;
    private boolean ttsReady=false;
    private boolean recognitionStarting=false;
    private boolean listenOnce=false;
    private String queuedSpeech=null;
    private long conversationUntil=0L;
    private int recognitionGeneration=0;
    private String lastPartialResult="";
    private boolean speechEnded=false;
    private enum Phase { IDLE, STARTING, LISTENING, WAITING_RESULT, THINKING, SPEAKING }
    private Phase phase=Phase.IDLE;
    private String activeUtteranceId="";
    private String currentSpeechText="";
    private boolean fallbackSynthesis=false;
    private MediaPlayer fallbackPlayer=null;
    private File fallbackFile=null;
    private final Runnable ttsStartTimeout=()->{
        if(speaking && ttsReady && !fallbackSynthesis && currentSpeechText!=null && !currentSpeechText.isEmpty()){
            // Some OEM TTS engines queue speak() successfully but never start
            // audible playback. Give the user a second, deterministic path:
            // synthesize to a local audio file and play it with MediaPlayer.
            startFileTtsFallback(currentSpeechText);
        }
    };

    // Recognition services on some tablets emit their startup chime on different
    // system streams. Save and restore all candidate streams around startListening.
    private int prevMusic=-1;
    private int prevSystem=-1;
    private int prevNotification=-1;
    private int prevRing=-1;
    private int prevDtmf=-1;
    private int prevAccessibility=-1;
    private boolean startupAudioMuted=false;
    private boolean ttsFocusHeld=false;
    private boolean recognitionFocusHeld=false;

    private final Runnable recognitionAudioTimeout=this::restoreRecognitionAudio;
    private final Runnable restartRunnable=()->{
        if(running && !speaking) listen();
    };

    @Override public void onCreate(){
        super.onCreate();
        INSTANCE=new WeakReference<>(this);
        audioManager=(AudioManager)getSystemService(AUDIO_SERVICE);
        agent=new AgentClient(this);
        workspace=new WorkspaceManager(this);
        workspace.startAutoSync();
        tts=new TextToSpeech(this,this);
        createChannel();
    }

    public static boolean speakIfRunning(Context context,String text){
        JarvesVoiceService service=INSTANCE.get();
        if(service==null || !service.running || text==null || text.trim().isEmpty()) return false;
        service.h.post(()->{
            // Never interrupt a live answer or active reasoning. The activity
            // check will still appear as a notification, and the next check
            // will catch anything that remains new.
            if(service.speaking || service.phase==Phase.THINKING || service.phase==Phase.SPEAKING) return;
            service.speak(text,false);
        });
        return true;
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        Notification n=new NotificationCompat.Builder(this,"jarves_voice")
                .setContentTitle("Jarves 4.0.1")
                .setContentText("Sprachassistent aktiv – sag „Jarves …“")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true).build();
        if(Build.VERSION.SDK_INT>=29) startForeground(21,n,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        else startForeground(21,n);

        running=true;
        if(intent!=null && intent.getBooleanExtra("interrupt",false) && speaking){
            try{tts.stop();}catch(Exception ignored){}
            h.removeCallbacks(ttsStartTimeout);
            abandonTtsFocus();
            speaking=false;
            phase=Phase.LISTENING;
            broadcast("HÖREN • UNTERBROCHEN");
        }
        // MainActivity starts the service with this flag for an explicit microphone
        // interaction. A normal service start keeps the always-listening mode.
        if(intent!=null && intent.hasExtra("listen_once")){
            listenOnce=intent.getBooleanExtra("listen_once",false);
        }
        directListen = intent!=null && intent.getBooleanExtra("direct_listen",false);
        broadcast("VOICE • AKTIV");
        String externalSpeech=intent==null?null:intent.getStringExtra("speak_text");
        if(externalSpeech!=null && !externalSpeech.trim().isEmpty()){
            speak(externalSpeech,false);
            return START_STICKY;
        }
        if(intent!=null && intent.getBooleanExtra("test_tts",false)){
            speak("Hallo. Ich bin Jarves. Wenn du mich hörst, funktioniert die Sprachausgabe.",false);
            return START_STICKY;
        }
        if(!speaking && !recognitionStarting){
            if(directListen) startCommandListening();
            else listen();
        }
        return START_STICKY;
    }

    private boolean isCurrent(int generation){
        return running && generation==recognitionGeneration && recognizer!=null;
    }

    /**
     * Siri-style two-stage voice activation:
     * 1) a lightweight on-device wake-word detector listens continuously;
     * 2) only after "Hey Jarvis/Jarvis" is detected do we start Android
     *    SpeechRecognizer for the actual command.
     *
     * This prevents SpeechRecognizer from running continuously and removes
     * the repeated recognizer startup cycle while Jarves is idle.
     */
    private void listen(){
        if(!running || speaking || recognitionStarting || wakeDetectorStarting) return;
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            broadcast("VOICE • MIKROFON-BERECHTIGUNG FEHLT");
            return;
        }
        try{
            if(wakeDetector==null){
                wakeDetectorStarting=true;
                wakeDetector=new OpenWakeWord.Builder(this)
                        .setModel(OpenWakeWord.BuiltInModel.HEY_JARVIS)
                        .setThreshold(0.55f)
                        .setDebounceMs(2500L)
                        .build();
            }
            wakeDetector.start(score->{
                h.post(()->{
                    if(!running || speaking) return;
                    wakeDetectorStarting=false;
                    stopWakeDetector();
                    workspace.claimVoice(claimed->{
                        h.post(()->{
                            if(!running || speaking) return;
                            if(!claimed){
                                broadcast("JARVES • ANDERES GERÄT ANTWORTET");
                                h.postDelayed(()->{if(running&&!speaking)listen();},900);
                                return;
                            }
                            conversationUntil=System.currentTimeMillis()+45000L;
                            broadcast("JARVES • AKTIVIERT");
                            // Let the wake phrase finish crossing the microphone before
                            // handing the mic to Android STT. The next speech is the
                            // command, just like Siri's activated state.
                            h.postDelayed(()->{
                                if(running && !speaking) startCommandListening();
                            },140);
                        });
                    });
                });
            });
            wakeDetectorStarting=true;
            phase=Phase.IDLE;
            broadcast("JARVES • BEREIT • SAG „JARVES“");
        }catch(Throwable ex){
            wakeDetectorStarting=false;
            stopWakeDetector();
            // Do not break the assistant if the wake-word library/provider is
            // unavailable. Fall back to the existing Android recognizer path.
            broadcast("JARVES • WAKEWORD NICHT VERFÜGBAR • MIKROFON-TASTE NUTZEN");
            phase=Phase.IDLE;
        }
    }

    private void stopWakeDetector(){
        wakeDetectorStarting=false;
        if(wakeDetector!=null){
            try{wakeDetector.stop();}catch(Exception ignored){}
            try{wakeDetector.release();}catch(Exception ignored){}
            wakeDetector=null;
        }
    }

    private void startCommandListening(){
        if(!running || speaking || recognitionStarting) return;
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            broadcast("VOICE • MIKROFON-BERECHTIGUNG FEHLT");
            return;
        }
        if(!SpeechRecognizer.isRecognitionAvailable(this)){
            broadcast("VOICE • SPRACHERKENNUNG NICHT VERFÜGBAR");
            scheduleRestart(1500);
            return;
        }

        recognitionStarting=true;
        phase=Phase.STARTING;
        lastPartialResult="";
        speechEnded=false;
        stopRecognizerOnly();
        phase=Phase.STARTING;
        final int generation=++recognitionGeneration;

        try{
            // Use the standard Android recognition service first. This is the
            // compatibility path that works with the device's configured German
            // recognition provider and can use network recognition when available.
            // On-device recognition remains a fallback when the standard service
            // cannot be created.
            recognizer=SpeechRecognizer.createSpeechRecognizer(this);
        }catch(Exception ex){
            try{
                if(Build.VERSION.SDK_INT>=31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)){
                    recognizer=SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
                }else recognizer=null;
            }catch(Exception ignored){recognizer=null;}
        }

        if(recognizer==null){
            recognitionStarting=false;
            broadcast("VOICE • SPRACHERKENNUNG FEHLER");
            scheduleRestart(1200);
            return;
        }

        recognizer.setRecognitionListener(new RecognitionListener(){
            @Override public void onReadyForSpeech(Bundle b){
                if(!isCurrent(generation)) return;
                recognitionStarting=false;
                phase=Phase.LISTENING;
                speechEnded=false;
                // Keep the temporary startup mute/focus until the user actually
                // starts speaking. Some OEM recognition services emit their cue
                // just after onReadyForSpeech(). Restoring here is too early.
                broadcast("HÖREN • AKTIV");
            }
            @Override public void onBeginningOfSpeech(){
                if(!isCurrent(generation)) return;
                recognitionStarting=false;
                phase=Phase.LISTENING;
                speechEnded=false;
                restoreRecognitionAudio();
                abandonRecognitionFocus();
                broadcast("HÖREN • SPRICHT");
            }
            @Override public void onRmsChanged(float r){}
            @Override public void onBufferReceived(byte[] b){}
            @Override public void onEndOfSpeech(){
                if(!isCurrent(generation)) return;
                speechEnded=true;
                phase=Phase.WAITING_RESULT;
                restoreRecognitionAudio();
                abandonRecognitionFocus();
                broadcast("DENKEN • AUSWERTUNG");
            }
            @Override public void onError(int e){
                if(generation!=recognitionGeneration) return;
                recognitionStarting=false;
                restoreRecognitionAudio();
                abandonRecognitionFocus();
                if(speechEnded || phase==Phase.WAITING_RESULT){
                    // Android recognizers may report ERROR_NO_MATCH/ERROR_SPEECH_TIMEOUT
                    // immediately after onEndOfSpeech even though useful partial text
                    // exists. Never jump straight back to LISTENING here. If a partial
                    // transcript exists, treat it as the final command; otherwise give
                    // the recognizer a quiet retry window.
                    String fallback=lastPartialResult==null?"":lastPartialResult.trim();
                    if(!fallback.isEmpty() && fallback.length()>=2){
                        stopRecognizerOnly();
                        phase=Phase.THINKING;
                        handle(fallback);
                        return;
                    }
                    phase=Phase.IDLE;
                    if(running && !speaking) scheduleRestart(1200);
                    return;
                }
                phase=Phase.IDLE;
                if(running && !speaking) scheduleRestart(e==SpeechRecognizer.ERROR_NO_MATCH?500:800);
            }
            @Override public void onResults(Bundle b){
                if(generation!=recognitionGeneration) return;
                recognitionStarting=false;
                phase=Phase.THINKING;
                restoreRecognitionAudio();
                abandonRecognitionFocus();
                ArrayList<String> rs=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String result=(rs==null||rs.isEmpty())?"":rs.get(0);
                // Stop the recognizer BEFORE handing text to the agent. This is
                // the critical guard that prevents a new listen cycle from
                // stealing the microphone while Jarves is preparing its answer.
                stopRecognizerOnly();
                handle(result);
            }
            @Override public void onPartialResults(Bundle b){
                if(generation!=recognitionGeneration) return;
                ArrayList<String> ps=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if(ps!=null && !ps.isEmpty()){
                    String candidate=ps.get(0);
                    if(candidate!=null && candidate.trim().length()>0) lastPartialResult=candidate.trim();
                }
            }
            @Override public void onEvent(int t,Bundle b){}
        });

        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.GERMANY.toLanguageTag());
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,Locale.GERMANY.toLanguageTag());
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3);
        i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE,false);
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS,1200L);
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS,300L);

        // Suppress the recognizer's startup cue as far as Android permits. There
        // is no public SpeechRecognizer flag that disables this sound globally;
        // muting the system/notification/media streams around startListening is
        // the established workaround. Audio is restored on onReady/onError.
        requestRecognitionFocus();
        muteRecognitionStartupAudio();
        h.removeCallbacks(recognitionAudioTimeout);
        h.postDelayed(recognitionAudioTimeout,4000);

        h.postDelayed(()->{
            if(!isCurrent(generation) || speaking){
                restoreRecognitionAudio();
                abandonRecognitionFocus();
                recognitionStarting=false;
                return;
            }
            try{
                recognizer.startListening(i);
            }catch(Exception ex){
                restoreRecognitionAudio();
                abandonRecognitionFocus();
                recognitionStarting=false;
                scheduleRestart(800);
            }
        },120);
    }

    private void scheduleRestart(long delay){
        h.removeCallbacks(restartRunnable);
        if(running && !speaking && phase!=Phase.THINKING && phase!=Phase.SPEAKING) h.postDelayed(restartRunnable,delay);
    }

    private void stopRecognizerOnly(){
        recognitionGeneration++;
        recognitionStarting=false;
        h.removeCallbacks(recognitionAudioTimeout);
        restoreRecognitionAudio();
        abandonRecognitionFocus();
        if(recognizer!=null){
            try{recognizer.cancel();}catch(Exception ignored){}
            try{recognizer.destroy();}catch(Exception ignored){}
            recognizer=null;
        }
    }

    private void requestRecognitionFocus(){
        if(audioManager==null || recognitionFocusHeld) return;
        try{
            if(Build.VERSION.SDK_INT>=26){
                AudioAttributes attrs=new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build();
                recognitionFocusRequest=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                        .setAudioAttributes(attrs)
                        .setAcceptsDelayedFocusGain(false)
                        .build();
                int r=audioManager.requestAudioFocus(recognitionFocusRequest);
                recognitionFocusHeld=(r==AudioManager.AUDIOFOCUS_REQUEST_GRANTED);
            }else{
                recognitionFocusHeld=audioManager.requestAudioFocus(null,AudioManager.STREAM_MUSIC,AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                        ==AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
            }
        }catch(Exception ignored){ recognitionFocusHeld=false; }
    }

    private void abandonRecognitionFocus(){
        if(audioManager==null || !recognitionFocusHeld)return;
        try{
            if(Build.VERSION.SDK_INT>=26 && recognitionFocusRequest!=null) audioManager.abandonAudioFocusRequest(recognitionFocusRequest);
        }catch(Exception ignored){}
        recognitionFocusHeld=false;
    }

    private void requestTtsFocus(){
        if(audioManager==null || ttsFocusHeld)return;
        try{
            if(Build.VERSION.SDK_INT>=26){
                AudioAttributes attrs=new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build();
                ttsFocusRequest=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                        .setAudioAttributes(attrs)
                        .setAcceptsDelayedFocusGain(false)
                        .build();
                int r=audioManager.requestAudioFocus(ttsFocusRequest);
                ttsFocusHeld=(r==AudioManager.AUDIOFOCUS_REQUEST_GRANTED);
            }else{
                ttsFocusHeld=audioManager.requestAudioFocus(null,AudioManager.STREAM_MUSIC,AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                        ==AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
            }
        }catch(Exception ignored){ ttsFocusHeld=false; }
    }

    private void abandonTtsFocus(){
        if(audioManager==null || !ttsFocusHeld)return;
        try{
            if(Build.VERSION.SDK_INT>=26 && ttsFocusRequest!=null) audioManager.abandonAudioFocusRequest(ttsFocusRequest);
        }catch(Exception ignored){}
        ttsFocusHeld=false;
    }

    private void muteRecognitionStartupAudio(){
        if(audioManager==null || startupAudioMuted)return;
        try{
            prevMusic=audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
            prevSystem=audioManager.getStreamVolume(AudioManager.STREAM_SYSTEM);
            prevNotification=audioManager.getStreamVolume(AudioManager.STREAM_NOTIFICATION);
            prevRing=audioManager.getStreamVolume(AudioManager.STREAM_RING);
            prevDtmf=audioManager.getStreamVolume(AudioManager.STREAM_DTMF);
            if(Build.VERSION.SDK_INT>=26) prevAccessibility=audioManager.getStreamVolume(AudioManager.STREAM_ACCESSIBILITY);
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC,0,AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE);
            audioManager.setStreamVolume(AudioManager.STREAM_SYSTEM,0,AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE);
            audioManager.setStreamVolume(AudioManager.STREAM_NOTIFICATION,0,AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE);
            audioManager.setStreamVolume(AudioManager.STREAM_RING,0,AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE);
            audioManager.setStreamVolume(AudioManager.STREAM_DTMF,0,AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE);
            if(Build.VERSION.SDK_INT>=26) audioManager.setStreamVolume(AudioManager.STREAM_ACCESSIBILITY,0,AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE);
            startupAudioMuted=true;
        }catch(Exception ignored){}
    }

    private void restoreRecognitionAudio(){
        h.removeCallbacks(recognitionAudioTimeout);
        if(audioManager==null || !startupAudioMuted)return;
        try{
            if(prevMusic>=0) audioManager.setStreamVolume(AudioManager.STREAM_MUSIC,prevMusic,AudioManager.FLAG_ALLOW_RINGER_MODES);
            if(prevSystem>=0) audioManager.setStreamVolume(AudioManager.STREAM_SYSTEM,prevSystem,AudioManager.FLAG_ALLOW_RINGER_MODES);
            if(prevNotification>=0) audioManager.setStreamVolume(AudioManager.STREAM_NOTIFICATION,prevNotification,AudioManager.FLAG_ALLOW_RINGER_MODES);
            if(prevRing>=0) audioManager.setStreamVolume(AudioManager.STREAM_RING,prevRing,AudioManager.FLAG_ALLOW_RINGER_MODES);
            if(prevDtmf>=0) audioManager.setStreamVolume(AudioManager.STREAM_DTMF,prevDtmf,AudioManager.FLAG_ALLOW_RINGER_MODES);
            if(Build.VERSION.SDK_INT>=26 && prevAccessibility>=0) audioManager.setStreamVolume(AudioManager.STREAM_ACCESSIBILITY,prevAccessibility,AudioManager.FLAG_ALLOW_RINGER_MODES);
        }catch(Exception ignored){}
        prevMusic=-1;
        prevSystem=-1;
        prevNotification=-1;
        prevRing=-1;
        prevDtmf=-1;
        prevAccessibility=-1;
        startupAudioMuted=false;
    }

    private void handle(String text){
        if(text==null||text.trim().isEmpty()){
            phase=Phase.IDLE;
            if(running && !speaking) scheduleRestart(300);
            return;
        }
        String raw=text.trim();
        String l=raw.toLowerCase(Locale.GERMAN);
        if(l.equals("stopp")||l.equals("stop")||l.equals("beende dich")||l.equals("jarves stopp")||l.equals("jarvis stopp")){
            stopSelf();
            return;
        }

        int k=findWakeWord(l);
        String cmd;
        if(k>=0){
            String matched=l.substring(k);
            int end=k+(matched.startsWith("jervis")?6:matched.startsWith("jerves")?6:matched.startsWith("jarwez")?6:matched.startsWith("jarwees")?7:6);
            cmd=raw.substring(Math.min(raw.length(),end)).replaceFirst("^[,;: -]+","").trim();
            conversationUntil=System.currentTimeMillis()+45000L;
        }else if(System.currentTimeMillis()<conversationUntil){
            cmd=raw;
        }else{
            if(running && !speaking) scheduleRestart(200);
            return;
        }

        if(cmd.isEmpty()){
            speak("Ja?",true);
            return;
        }
        if(cmd.equalsIgnoreCase("stopp")||cmd.equalsIgnoreCase("stop")||cmd.equalsIgnoreCase("beende dich")){
            stopSelf();
            return;
        }
        conversationUntil=System.currentTimeMillis()+45000L;
        phase=Phase.THINKING;
        broadcast("DENKEN • "+cmd);
        // No recognizer is active here. The agent can take as long as needed;
        // Jarves will speak first and only then return to listening.
        agent.ask(cmd,(answer,status)->h.post(()->{ broadcast("AGENT • "+(status==null?"FERTIG":status)); speak(answer,false); }));
    }

    private int findWakeWord(String lower){
        String[] words={"jarves","jarvis","jervis","jerves","jarwez","jarwees"};
        int best=-1;
        for(String word:words){
            int i=lower.indexOf(word);
            if(i>=0&&(best<0||i<best))best=i;
        }
        return best;
    }

    private String speechSafeText(String text){
        String t=text==null?"":text.replaceAll("\\s+"," ").trim();
        if(t.isEmpty()) return "Ich habe dazu keine Antwort.";
        // Android TTS engines differ in maximum input size. Keep spoken answers
        // useful and stable; the full answer remains visible in the HUD/dialog.
        if(t.length()<=2400) return t;
        String cut=t.substring(0,2400);
        int dot=Math.max(cut.lastIndexOf('.'),Math.max(cut.lastIndexOf('!'),cut.lastIndexOf('?')));
        if(dot>900) cut=cut.substring(0,dot+1);
        return cut+" Wenn du mehr Details möchtest, frag mich einfach weiter.";
    }

    private void speak(String text,boolean resume){
        final String finalText=speechSafeText(text);
        h.removeCallbacks(restartRunnable);
        stopRecognizerOnly();
        speaking=true;
        phase=Phase.SPEAKING;
        broadcast("ANTWORT • "+finalText);

        if(tts==null || !ttsReady){
            queuedSpeech=finalText;
            broadcast("SPRACHE • WARTE AUF TTS");
            return;
        }
        doSpeak(finalText);
    }

    private void doSpeak(String text){
        if(tts==null || !ttsReady){queuedSpeech=text;return;}
        stopRecognizerOnly();
        restoreRecognitionAudio();
        requestTtsFocus();
        try{
            if(audioManager!=null && audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)<=0){
                int max=audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                if(max>0) audioManager.setStreamVolume(AudioManager.STREAM_MUSIC,Math.max(2,max/4),AudioManager.FLAG_ALLOW_RINGER_MODES);
            }
        }catch(Exception ignored){}

        try{tts.stop();}catch(Exception ignored){}
        stopFallbackPlayer();
        fallbackSynthesis=false;
        currentSpeechText=speechSafeText(text);
        h.removeCallbacks(ttsStartTimeout);

        // Split long answers into short utterances. Only the final utterance owns
        // activeUtteranceId, so the service cannot return to listening between chunks.
        List<String> chunks=new ArrayList<>();
        String remaining=currentSpeechText;
        while(remaining.length()>1100){
            int cut=remaining.substring(0,1100).lastIndexOf(' ');
            if(cut<600) cut=1100;
            chunks.add(remaining.substring(0,cut).trim());
            remaining=remaining.substring(cut).trim();
        }
        if(!remaining.isEmpty()) chunks.add(remaining);
        activeUtteranceId="jarves_final_"+System.currentTimeMillis();

        try{
            for(int idx=0;idx<chunks.size();idx++){
                String id=(idx==chunks.size()-1)?activeUtteranceId:"jarves_part_"+System.nanoTime();
                Bundle params=new Bundle();
                params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME,1.0f);
                params.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM,AudioManager.STREAM_MUSIC);
                int result;
                if(idx==0) result=tts.speak(chunks.get(idx),TextToSpeech.QUEUE_FLUSH,params,id);
                else result=tts.speak(chunks.get(idx),TextToSpeech.QUEUE_ADD,params,id);
                if(result!=TextToSpeech.SUCCESS){
                    if(idx==0){
                        int retry=tts.speak(chunks.get(idx),TextToSpeech.QUEUE_FLUSH,null,id);
                        if(retry!=TextToSpeech.SUCCESS){
                            startFileTtsFallback(currentSpeechText);
                            return;
                        }
                    }else{
                        startFileTtsFallback(currentSpeechText);
                        return;
                    }
                }
            }
            broadcast("SPRACHE • AUSGABE");
            h.postDelayed(ttsStartTimeout,12000);
        }catch(Exception ex){
            startFileTtsFallback(currentSpeechText);
        }
    }

    private void startFileTtsFallback(String text){
        if(!running || !ttsReady || text==null || text.trim().isEmpty()) return;
        h.removeCallbacks(ttsStartTimeout);
        fallbackSynthesis=true;
        try{ tts.stop(); }catch(Exception ignored){}
        stopFallbackPlayer();
        if(fallbackFile!=null) try{fallbackFile.delete();}catch(Exception ignored){}
        fallbackFile=new File(getCacheDir(),"jarves_tts_fallback.wav");
        String id="jarves_file_"+System.currentTimeMillis();
        activeUtteranceId=id;
        Bundle params=new Bundle();
        params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME,1.0f);
        params.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM,AudioManager.STREAM_MUSIC);
        int result=tts.synthesizeToFile(text,params,fallbackFile,id);
        if(result!=TextToSpeech.SUCCESS){
            fallbackSynthesis=false;
            abandonTtsFocus();
            speaking=false;
            phase=Phase.IDLE;
            broadcast("SPRACHE • WIEDERGABE NICHT VERFÜGBAR");
            if(running && !listenOnce) scheduleRestart(1000);
        }else{
            broadcast("SPRACHE • AUDIO-RESERVE");
        }
    }

    private void playFallbackFile(){
        if(fallbackFile==null || !fallbackFile.exists() || fallbackFile.length()==0){
            fallbackSynthesis=false;
            speaking=false;
            phase=Phase.IDLE;
            broadcast("SPRACHE • AUDIO-DATEI FEHLT");
            if(running && !listenOnce) scheduleRestart(1000);
            return;
        }
        try{
            stopFallbackPlayer();
            fallbackPlayer=new MediaPlayer();
            fallbackPlayer.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build());
            fallbackPlayer.setDataSource(fallbackFile.getAbsolutePath());
            fallbackPlayer.setOnPreparedListener(mp->{
                h.post(()->broadcast("SPRACHE • SPRICHT"));
                mp.start();
            });
            fallbackPlayer.setOnCompletionListener(mp->{
                h.post(()->{
                    stopFallbackPlayer();
                    fallbackSynthesis=false;
                    abandonTtsFocus();
                    speaking=false;
                    phase=Phase.IDLE;
                    broadcast("HÖREN • BEREIT");
                    if(running && !listenOnce) scheduleRestart(500);
                });
            });
            fallbackPlayer.setOnErrorListener((mp,what,extra)->{
                h.post(()->{
                    stopFallbackPlayer();
                    fallbackSynthesis=false;
                    abandonTtsFocus();
                    speaking=false;
                    phase=Phase.IDLE;
                    broadcast("SPRACHE • AUDIO FEHLER");
                    if(running && !listenOnce) scheduleRestart(1000);
                });
                return true;
            });
            fallbackPlayer.prepareAsync();
        }catch(Exception e){
            stopFallbackPlayer();
            fallbackSynthesis=false;
            abandonTtsFocus();
            speaking=false;
            phase=Phase.IDLE;
            broadcast("SPRACHE • AUDIO FEHLER");
            if(running && !listenOnce) scheduleRestart(1000);
        }
    }

    private void stopFallbackPlayer(){
        if(fallbackPlayer!=null){
            try{fallbackPlayer.setOnCompletionListener(null);}catch(Exception ignored){}
            try{fallbackPlayer.setOnErrorListener(null);}catch(Exception ignored){}
            try{fallbackPlayer.stop();}catch(Exception ignored){}
            try{fallbackPlayer.release();}catch(Exception ignored){}
            fallbackPlayer=null;
        }
    }

    private void broadcast(String s){sendBroadcast(new Intent(ACTION_UPDATE).putExtra("status",s));}

    private void createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel("jarves_voice","Jarves Voice",NotificationManager.IMPORTANCE_LOW);
            c.setSound(null,null);
            c.enableVibration(false);
            c.setShowBadge(false);
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    @Override public void onInit(int status){
        if(status!=TextToSpeech.SUCCESS || tts==null){
            ttsReady=false;
            broadcast("SPRACHE • TTS NICHT VERFÜGBAR");
            return;
        }

        ttsReady=false;
        try{
            int lang=tts.setLanguage(Locale.GERMANY);
            if(lang==TextToSpeech.LANG_MISSING_DATA || lang==TextToSpeech.LANG_NOT_SUPPORTED){
                lang=tts.setLanguage(Locale.GERMAN);
            }
            if(lang==TextToSpeech.LANG_MISSING_DATA || lang==TextToSpeech.LANG_NOT_SUPPORTED){
                broadcast("SPRACHE • DEUTSCH-STIMMDATEN FEHLEN");
            }

            // Prefer an installed German voice. If the engine exposes a voice
            // explicitly labelled male, use it; otherwise use the best de-DE
            // voice and lower pitch slightly rather than risking an unusable
            // uninstalled voice.
            if(Build.VERSION.SDK_INT>=21){
                List<Voice> voices=tts.getVoices()==null?new ArrayList<>():new ArrayList<>(tts.getVoices());
                Voice best=null;
                int bestScore=-1000;
                for(Voice v:voices){
                    Locale l=v.getLocale();
                    if(l==null || !"de".equalsIgnoreCase(l.getLanguage())) continue;
                    String n=v.getName()==null?"":v.getName().toLowerCase(Locale.GERMAN);
                    int score=0;
                    if("DE".equalsIgnoreCase(l.getCountry())) score+=10;
                    if(n.contains("male")||n.contains("männ")||n.contains("mann")||n.contains("m1")) score+=6;
                    if(n.contains("female")||n.contains("frau")||n.contains("f1")) score-=2;
                    if(v.getFeatures()!=null && v.getFeatures().contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)) score-=100;
                    if(v.isNetworkConnectionRequired()) score-=8; else score+=4;
                    if(score>bestScore){bestScore=score;best=v;}
                }
                if(best!=null) tts.setVoice(best);
            }

            if(Build.VERSION.SDK_INT>=21){
                tts.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build());
            }
            tts.setSpeechRate(0.96f);
            tts.setPitch(0.88f);
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener(){
                @Override public void onStart(String id){
                    if(!id.equals(activeUtteranceId))return;
                    h.removeCallbacks(ttsStartTimeout);
                    if(fallbackSynthesis)return;
                    h.post(()->{ phase=Phase.SPEAKING; broadcast("SPRACHE • SPRICHT"); });
                }
                @Override public void onDone(String id){
                    if(!id.equals(activeUtteranceId))return;
                    h.removeCallbacks(ttsStartTimeout);
                    if(fallbackSynthesis){
                        h.post(()->playFallbackFile());
                        return;
                    }
                    h.post(()->{
                        abandonTtsFocus();
                        speaking=false;
                        phase=Phase.IDLE;
                        broadcast("HÖREN • BEREIT");
                        if(running && !listenOnce) scheduleRestart(500);
                    });
                }
                @Override public void onError(String id){
                    if(!id.equals(activeUtteranceId))return;
                    h.removeCallbacks(ttsStartTimeout);
                    if(!fallbackSynthesis){
                        h.post(()->startFileTtsFallback(currentSpeechText));
                        return;
                    }
                    h.post(()->{
                        fallbackSynthesis=false;
                        abandonTtsFocus();
                        speaking=false;
                        phase=Phase.IDLE;
                        broadcast("SPRACHE • WIEDERGABE FEHLER");
                        if(running && !listenOnce) scheduleRestart(1000);
                    });
                }
                @Override public void onError(String id,int errorCode){onError(id);}
            });
            ttsReady=true;
            broadcast("SPRACHE • BEREIT");
            if(queuedSpeech!=null){
                phase=Phase.SPEAKING;
                String q=queuedSpeech;
                queuedSpeech=null;
                doSpeak(q);
            }
        }catch(Exception ex){
            ttsReady=false;
            broadcast("SPRACHE • INITIALISIERUNG FEHLER");
        }
    }

    @Override public void onDestroy(){
        running=false;
        h.removeCallbacksAndMessages(null);
        h.removeCallbacks(ttsStartTimeout);
        stopRecognizerOnly();
        if(workspace!=null){workspace.releaseVoice();workspace.stopAutoSync();}
        stopWakeDetector();
        abandonRecognitionFocus();
        abandonTtsFocus();
        restoreRecognitionAudio();
        if(tts!=null){try{tts.stop();}catch(Exception ignored){}try{tts.shutdown();}catch(Exception ignored){}}
        stopFallbackPlayer();
        if(fallbackFile!=null) try{fallbackFile.delete();}catch(Exception ignored){}
        ttsReady=false;
        speaking=false;
        phase=Phase.IDLE;
        broadcast("VOICE • AUS");
        INSTANCE.clear();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent){return null;}
}
